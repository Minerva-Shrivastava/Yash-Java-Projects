package com.yash.exception;

public class PojoNotAvailableException extends RuntimeException{

	public PojoNotAvailableException(String msg) {
		super(msg);
	}
}
