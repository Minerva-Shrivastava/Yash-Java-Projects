package com.yash.exception;

public class PojoNotRegisteredException extends RuntimeException{

	public PojoNotRegisteredException(String msg) {
		super(msg);
	}
}
