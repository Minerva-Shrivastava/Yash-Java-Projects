package com.yash;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import com.yash.controller.ApplicationController;
import com.yash.factory.LoadPojoXML;
import com.yash.factory.PojoFactory;
import com.yash.pojo.Application;
import com.yash.service.ApplicationService;

public class MainStartUp {

	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException, ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalArgumentException, InvocationTargetException {
		
		PojoFactory pf = new LoadPojoXML(new File("pojo.xml"));
		
		Application app = (Application) pf.getPojo("application");
		System.out.println(app);
		
		ApplicationService appService = (ApplicationService) pf.getPojo("appService");
		System.out.println(appService);
		
		ApplicationController appCtrl = (ApplicationController) pf.getPojo("appCtrl");
		System.out.println(appCtrl);
		
		//app.getDetails();
	}
}
