package com.yash.factory;

import java.io.File;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import com.yash.pojo.Pojo;

public class PojoFactory {

	private File file;

	public PojoFactory(File xmlFile) {
		this.file = xmlFile;
	}

	public Pojo getPojo(String givenName) throws ParserConfigurationException,  IOException,
			ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchFieldException,
			SecurityException, NoSuchMethodException, IllegalArgumentException, InvocationTargetException, SAXException {
		
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(file);
		NodeList nList = doc.getElementsByTagName("pojo");

		System.out.println("\n\nRoot element : " + doc.getDocumentElement().getNodeName());
		System.out.println("--------------------");

		for (int item = 0; item < nList.getLength(); item++) {
			Node nNode = nList.item(item);

			// System.out.println("Current element : "+nNode.getNodeName());

			if (nNode.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) nNode;

				if (eElement.getAttribute("id").equalsIgnoreCase(givenName)) {
					// System.out.println(" ID : "+eElement.getAttribute("id")+" Class
					// :"+eElement.getAttribute("class"));
					Class<?> classObtained = Class.forName(eElement.getAttribute("class"));
					Object obj = classObtained.newInstance();

					NodeList childList = nNode.getChildNodes();
					for (int i = 0; i < childList.getLength(); i++) {
						Node childNode = childList.item(i);
						if (childNode.getNodeType() == Node.ELEMENT_NODE) {
							Element eProperty = (Element) childNode;

							String name = eProperty.getAttribute("name");
							System.out.println("Name from XML is:" + name);
							int value = Integer.parseInt(eProperty.getAttribute("value"));
							System.out.println("Value from XML is:" + value);

							java.lang.reflect.Field fieldValue = classObtained.getDeclaredField("value");
							//System.out.println("Field Value " + fieldValue);
							java.lang.reflect.Field fieldName = classObtained.getDeclaredField("name");
							//System.out.println("Field Name " + fieldName);
							/*fieldName.setAccessible(true);
							fieldValue.setAccessible(true);
							fieldName.set(obj, name);
							fieldValue.setInt(obj, value);
*/
							Method method = classObtained.getMethod("setValue", Integer.TYPE);
							method.invoke(obj, value);

							Method method1 = classObtained.getMethod("setName", String.class);
							method1.invoke(obj, name);

						}
					}
					Pojo pojo = (Pojo) obj;
					return pojo;
				}
			}
		}
		return null;
	}
}

