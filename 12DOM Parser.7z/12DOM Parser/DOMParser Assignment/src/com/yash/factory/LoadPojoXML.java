package com.yash.factory;

import java.io.File;
import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;

public class LoadPojoXML extends PojoFactory{

	public LoadPojoXML(File xmlFile) throws ParserConfigurationException, SAXException, IOException {
		
		super(xmlFile);
	}
	
}
