package com.yash.controller;

import com.yash.pojo.Pojo;

public class ApplicationController implements Pojo{

	private int value;
	private String name;
	
	public ApplicationController() 
	{
		System.out.println("ApplicationController Object made");
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public String toString() {
		
		return "[ name:"+this.getName()+" value:"+this.getValue()+" ]";
	}

	
	public void getDetails() {
		// TODO Auto-generated method stub
		
	}
}
