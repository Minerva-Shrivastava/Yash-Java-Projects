package com.yash.pojo;

public class Application implements Pojo{

	private int value;
	private String name;
	
	public Application() {
		System.out.println("Application Object made");
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public void getDetails() {
		
		
	}
	
	@Override
	public String toString() {
		
		return "[ name:"+this.getName()+" value:"+this.getValue()+" ]";
	}

}
