package com.yash.cms.Test;

/**
 * This class tests the connection operation of DBUtil class
 * @author minerva.shrivastava
 *
 */
public class DBUtilDriverManagerConnectionOperationTest {

	public static void main(String[] args) {
		
		//Method is now a helper method for preparedStatement
		//Connection con = DBUtil.getConnection();
		//System.out.println(con);
		
	}
}
