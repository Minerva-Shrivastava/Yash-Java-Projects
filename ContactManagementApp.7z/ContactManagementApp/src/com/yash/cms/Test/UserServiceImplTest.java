package com.yash.cms.Test;

import com.yash.cms.model.User;
import com.yash.cms.service.UserService;
import com.yash.cms.serviceimpl.UserServiceImpl;

/**
 * This class tests the operations of UserServiceImpl class
 * @author minerva.shrivastava
 *
 */
public class UserServiceImplTest {

	public static void main(String[] args) {
		
		UserService uService = new UserServiceImpl();
		User user = new User();
		user.setName("Sakshi");
		user.setContact("123321");
		user.setAddress("Ujjain");
		user.setEmail("s@gmail.com");
		user.setUsername("sak");
		user.setPassword("sak123");
		uService.registerUser(user);
	}
}
