package com.yash.cms.Test;

import java.util.List;

import com.yash.cms.dao.userDAO;
import com.yash.cms.daoimpl.userDAOImpl;
import com.yash.cms.model.User;

/**
 * This class tests the operations of DAOImpl
 * @author minerva.shrivastava
 *
 */
public class DAOImplTest {

	public static void main(String[] args) {
		
		userDAO uDao = new userDAOImpl();
		
		User user = new User();
		user.setName("Riya");
		user.setContact("123321");
		user.setAddress("Indore");
		user.setEmail("R@gmail.com");
		user.setUsername("riya");
		user.setPassword("riya123");
		//uDao.insert(user);
		
		//uDao.delete(10);
		
		//user.setId(10);
		//uDao.update(user);
		
		List<User> users = uDao.list();
		for (User user2 : users) {
			System.out.println(user2);
		}
	}
}
