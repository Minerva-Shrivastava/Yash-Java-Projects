package com.yash.cms.Test;

/**
 * This class tests the driver load operation of DBUtil class
 * @author minerva.shrivastava
 *
 */
public class DBUtilDriverLoadOperationTest {

	public static void main(String[] args) {
		
		//The method is now a helper method (private)
		//DBUtil.loadDriver();
		
	}
}
