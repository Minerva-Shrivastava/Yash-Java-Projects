package com.yash.cms.Test;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.yash.cms.util.DBUtil;

/**
 * This class tests the createPreparedStatement operation of the DBUtil class
 * @author minerva.shrivastava
 *
 */
public class DBUtilPreparedStatementTest {

	public static void main(String[] args) {
		
		String sql = "INSERT INTO users(name,contact,username,password) VALUES ('Amit','123321','amit','amit123');";
		PreparedStatement pstsmt = DBUtil.createPreparedStatement(sql);
		boolean ex = true;
		try {
			ex = pstsmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if(ex == false)
			System.out.println("record inserted successfully");
	}
}
