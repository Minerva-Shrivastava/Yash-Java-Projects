package com.yash.cms.serviceimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.yash.cms.dao.userDAO;
import com.yash.cms.daoimpl.userDAOImpl;
import com.yash.cms.model.User;
import com.yash.cms.service.UserService;
import com.yash.cms.util.DBUtil;
/**
 * This is the implementation class of UserService interface
 * @author minerva.shrivastava
 *
 */
public class UserServiceImpl implements UserService{

	userDAO uDao = null;
	
	/**
	 * Custructor to initialize the userDAO 
	 */
	public UserServiceImpl() {

		uDao = new userDAOImpl();
		
	}
	
	/**
	 * This method registers the user
	 */
	@Override
	public boolean registerUser(User user) {
		
		return uDao.insert(user);
		
	}

	/**
	 * This method authenticates the user
	 */
	@Override
	public User userAuthentication(String username, String password) {

		User user = new User();
		String sql = "select * from users where username='"+username+"' and password='"+password+"' ;";
		PreparedStatement pstmt = DBUtil.createPreparedStatement(sql);
		try {
			ResultSet result = pstmt.executeQuery();
			if(result.next())
			{
				extractUserFromResultSet(user, result);
				System.out.println(user);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return user;
	}

	private void extractUserFromResultSet(User user, ResultSet result) throws SQLException {
		user.setId(result.getInt("id"));
		user.setName(result.getString("name"));
		user.setContact(result.getString("contact"));
		user.setAddress(result.getString("address"));
		user.setEmail(result.getString("email"));
		user.setStatus(Integer.parseInt(result.getString("status")));
		user.setRole(Integer.parseInt(result.getString("role")));
		user.setUsername(result.getString("username"));
		user.setPassword(result.getString("password"));
	}

	
}
