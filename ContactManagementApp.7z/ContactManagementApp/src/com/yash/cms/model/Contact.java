package com.yash.cms.model;

/**
 * This class will work as a model object.
 * It's use is to travel date from 1 layer to another layer
 * @author minerva.shrivastava
 *
 */
public class Contact extends Person{

	/**
	 * user_id of contact
	 * This is a foreign key referencing user id
	 */
	private Integer user_id;

	public Integer getUser_id() {
		return user_id;
	}

	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}
	 
}
