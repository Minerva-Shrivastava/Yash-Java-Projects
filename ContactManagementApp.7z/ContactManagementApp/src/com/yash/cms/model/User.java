package com.yash.cms.model;

/**
 * This class will work as a model object.
 * It's use is to travel date from 1 layer to another layer
 * @author minerva.shrivastava
 *
 */
public class User extends Person{
	
	/**
	 * status of user
	 */
	private Integer status;
	/**
	 * role of user
	 */
	private Integer role;
	/**
	 * username of user
	 */
	private String username;
	/**
	 * password of user
	 */
	private String password;
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Integer getRole() {
		return role;
	}
	public void setRole(Integer role) {
		this.role = role;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	@Override
	public String toString() {
		return "[ id="+this.getId()
				+"  name="+this.getContact()
				+"  contact="+this.getContact()
				+"  address="+this.getAddress()
				+"  email="+this.getEmail()
				+"  status="+this.getStatus()
				+"  role="+this.getRole()
				+"  username="+this.getUsername()
				+"  password="+this.getPassword()
				+" ]";
	}
}
