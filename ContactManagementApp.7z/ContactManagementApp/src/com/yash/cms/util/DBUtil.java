package com.yash.cms.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;

/**
 * This class performs operation on related to database like connection, disconnection
 * providing prepare statement object and resultSet object.
 * This class will be responsible to have transaction complete operation as well 
 * like closing connection, prepared statement object etc.
 * 
 * @author minerva.shrivastava
 *
 */
public class DBUtil {

	private static Connection con = null;
	private static PreparedStatement pstsmt = null;
	private static String url = "jdbc:mysql://localhost:3306/contact_management";
	private static String uname = "root";
	private static String pwd = "root";
	/**
	 * This method loads the driver of mysql
	 */
	static {
		try {
			Class<?> c = Class.forName("com.mysql.jdbc.Driver");
			System.out.println(c);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	
	/**
	 *This method establishes the connection to the database 
	 * @return Connection object
	 */
	private static Connection getConnection()
	{
		try {
			con = DriverManager.getConnection(url, uname, pwd);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
	
	/**
	 * This method will return the PreparedStatement object based on the sql provided,
	 * This method should have call for connection, because when you need transaction,
	 * that time you'll require connection object.
	 * @param sql is any DML query 
	 * @return PreparedStatement object
	 */
	public static PreparedStatement createPreparedStatement(String sql)
	{	
		getConnection();
		try {
			System.out.println(sql);
			pstsmt = con.prepareStatement(sql);
			//System.out.println(pstsmt);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return pstsmt;
	}
	
	/**
	 * This method will close the connection
	 */
	public static void closeConnection()
	{
		try {
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * This method will close the prepared statement 
	 */
	public void closePreparedStatement()
	{
		try {
			pstsmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
