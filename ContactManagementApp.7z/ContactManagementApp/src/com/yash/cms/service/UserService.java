package com.yash.cms.service;

import com.yash.cms.model.User;

/**
 * This interface will perform all service related task on user
 * @author minerva.shrivastava
 *
 */
public interface UserService {

	/**
	 * This method will register the user
	 * @param user object
	 * @return 
	 */
	public boolean registerUser(User user);
	
	/**
	 * This method will authenticate the user based on username and password
	 * @param username of user
	 * @param password of user
	 * @return
	 */
	public User userAuthentication(String username, String password);
	
}
