package com.yash.cms.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.cms.model.User;
import com.yash.cms.service.UserService;
import com.yash.cms.serviceimpl.UserServiceImpl;

/**
 * Servlet implementation class UserLoginController
 */
@WebServlet("/UserLoginController")
public class UserLoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       UserService uService = null;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserLoginController() {
    	uService = new UserServiceImpl();
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		User user = null;
		String uname=request.getParameter("username");
		String password=request.getParameter("password");
		user=uService.userAuthentication(uname,password);
		if(user != null) {
			response.sendRedirect("./welcome.jsp?msg=uname");
		}else {
			response.sendRedirect("./index.jsp?msg=Username/password invalid!");
		}
	}

}
