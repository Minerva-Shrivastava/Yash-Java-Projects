package com.yash.cms.dao;

import java.util.List;
import com.yash.cms.model.User;

/**
 * This interface will perform the operation related to users(CRUD operations)
 * @author minerva.shrivastava
 *
 */
public interface userDAO {
	/**
	 * This will add user object in the DB 
	 * @param user object
	 * @return 
	 */
	public boolean insert(User user);
	
	/**
	 * This will delete user record from userDB based on provided userid
	 * @param userid of user
	 */
	public void delete(Integer userid);

	/**
	 * This will delete user record from userDB based on provided user
	 * @param user object
	 */
	public void delete(User user);
	
	/**
	 * This will update user record in DB based on provided userid
	 */
	public void update(User user);
	
	/**
	 * This will list all users from user table from DB
	 * @return
	 */
	public List<User> list();
	
}
