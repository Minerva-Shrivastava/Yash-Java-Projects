package com.yash.cms.daoimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import com.yash.cms.dao.userDAO;
import com.yash.cms.model.User;
import com.yash.cms.util.DBUtil;

/**
 * This is the implementation class of userDAO interface
 * @author minerva.shrivastava
 *
 */
public class userDAOImpl implements userDAO{

	PreparedStatement pstmt = null;
	List<User> userRepository = new LinkedList<User>();
	
	/**
	 * 
	 */
	@Override
	public boolean insert(User user) {
		boolean exc = true;
		try {
		String sql = "insert into users(name,contact,address,email,username,password) values(?,?,?,?,?,?)";
		pstmt = DBUtil.createPreparedStatement(sql);
		pstmt.setString(1, user.getName());
		pstmt.setString(2, user.getContact());
		pstmt.setString(3, user.getAddress());
		pstmt.setString(4, user.getEmail());
		pstmt.setString(5, user.getUsername());
		pstmt.setString(6, user.getPassword());
		exc = pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if(exc == false) {
			System.out.println("Record inserted successfully");
			return true;
		}
		else
			return false;
	}

	@Override
	public void delete(Integer userid) {

		String sql = "delete from users where id='"+userid+"';";
		pstmt = DBUtil.createPreparedStatement(sql);
		boolean exc = true;
		try {
			exc = pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if(exc == false)
			System.out.println("Record deleted successfully");

	}

	@Override
	public void delete(User user) {
		
		String sql = "delete from users where id='"+user.getId()+"';";
		pstmt = DBUtil.createPreparedStatement(sql);
		boolean exc = true;
		try {
			exc = pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if(exc == false)
			System.out.println("Record deleted successfully");

	}

	@Override
	public void update(User user) {
		
		String sql = "update users set name='"+user.getName()+"',"
				+ "contact='"+user.getContact()+"',"
				+ "address='"+user.getAddress()+"',"
				+ "email='"+user.getEmail()+"',"
				+ "username='"+user.getUsername()+"',"
				+ "password='"+user.getPassword()+"' where id='"+user.getId()+"';";
		System.out.println(sql);
		pstmt = DBUtil.createPreparedStatement(sql);
		int exc = 0;
		try {
			exc = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if(exc > 0)
			System.out.println("Record updated successfully");

	}

	@Override
	public List<User> list() {

		String sql = "select * from users;";
		User user = new User();
		pstmt = DBUtil.createPreparedStatement(sql);
		try {
			ResultSet result = pstmt.executeQuery();
			while(result.next())
			{
				extractUserFromResultSet(user, result);
				userRepository.add(user);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return userRepository;
	}

	private void extractUserFromResultSet(User user, ResultSet result) throws SQLException {
		user.setId(result.getInt("id"));
		user.setName(result.getString("name"));
		user.setContact(result.getString("contact"));
		user.setAddress(result.getString("address"));
		user.setEmail(result.getString("email"));
		user.setStatus(Integer.parseInt(result.getString("status")));
		user.setRole(Integer.parseInt(result.getString("role")));
		user.setUsername(result.getString("username"));
		user.setPassword(result.getString("password"));
	}

	
}
