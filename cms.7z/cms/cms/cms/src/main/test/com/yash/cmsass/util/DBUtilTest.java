package com.yash.cmsass.util;
/**
 * test cases for DBUtil class
 */

import static org.junit.Assert.*;

import org.junit.Test;

public class DBUtilTest {
	private DBUtil dbutil;
	/**
	 * this test case for testing whether Driver class is loaded from mysqlconnector.jar or not
	 */
	
	@Test
	public void test_load_driver() {
		try {
			dbutil=new DBUtil("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	/**
	 * this test case for testing that if the class is not found in the mysqlconnector.jar 
	 * this will throw the ClassNotFoundException 
	 * @throws ClassNotFoundException
	 */
	@Test(expected = ClassNotFoundException.class)
	public void test_for_ClassNotFoundException() throws ClassNotFoundException {
		dbutil=new DBUtil("com.mysql.jdbc.Drive");
	}
	
    /**
     * this test case for testing that the given url, username, password giving you a MySql connection 
     */
	@Test
	public void test_getting_connection() {
		assertTrue((dbutil.getConnection("jdbc:mysql://localhost/cms","root","root")!=null));
	}
}
