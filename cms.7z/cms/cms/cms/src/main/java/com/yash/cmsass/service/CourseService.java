package com.yash.cmsass.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

public interface CourseService  {
    
	public List<String> getAllMaintitles(String course);
	public List<String> getCourses();
	public LinkedHashMap<String, ArrayList<String>> getCourseAndMainTitle(); 

}
