package com.yash.cmsass.domain;
/**
 * this will have details for a particular course 
 * @author chetan.magre
 *
 */
public class course {
	/**
	 * course name
	 */
	private String coursename;
	/**
	 * main title of course 
	 */
	private String maintitle;
	/**
	 * subtitle for main title of course
	 */
	private String subtitle;
	/**
	 * description of subtitle
	 */
	private String description;
	/**
	 * path location for the course document file
	 */
	private String path;
	/**
	 * publish status for subtitle
	 */
	private int status;
    
	
	public String getCoursename() {
		return coursename;
	}
	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}
	public String getMaintitle() {
		return maintitle;
	}
	public void setMaintitle(String maintitle) {
		this.maintitle = maintitle;
	}
	public String getSubtitle() {
		return subtitle;
	}
	public void setSubtitle(String subtitle) {
		this.subtitle = subtitle;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
}
