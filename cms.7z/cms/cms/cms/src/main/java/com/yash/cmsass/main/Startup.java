package com.yash.cmsass.main;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import com.yash.cmsass.service.CourseService;
import com.yash.cmsass.serviceimpl.CourseServiceImpl;

public class Startup {

	public static void main(String[] args) {
		CourseService courseService=new CourseServiceImpl();
		LinkedHashMap<String, ArrayList<String>> courseAndTitle=courseService.getCourseAndMainTitle();
        for (Map.Entry m : courseAndTitle.entrySet()) {
        	System.out.println(m.getKey());
			ArrayList<String> main=(ArrayList<String>) m.getValue();
			for (String string : main) {
				System.out.println(string);
			}
		}
		
	}

}
