package com.yash.cmsass.dao;

import java.util.ArrayList;

public interface CourseDao {

	public ArrayList<String> getMaintitles(String course);

	public ArrayList<String> getCourses();
  
}
