package com.yash.cmsass.serviceimpl;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import com.yash.cmsass.dao.CourseDao;
import com.yash.cmsass.daoimpl.CourseDaoImpl;
import com.yash.cmsass.service.CourseService;

public class CourseServiceImpl implements CourseService{
    private CourseDao cdao=new CourseDaoImpl();
	public ArrayList<String> getAllMaintitle(String course) {
		ArrayList<String> maintitle=cdao.getMaintitles(course);
		return maintitle;
	}
	public ArrayList<String> getCourses() {
		ArrayList<String> courses=cdao.getCourses();
		return courses;
	}
	public LinkedHashMap<String, ArrayList<String>> getCourseAndMainTitle() {
		LinkedHashMap<String, ArrayList<String>> courseAndTitle=new LinkedHashMap<String, ArrayList<String>>();
		ArrayList<String> courses=getCourses();
		for (String courseName : courses) {
			courseAndTitle.put(courseName,getAllMaintitle(courseName));
		}
		return courseAndTitle;
	}

}
