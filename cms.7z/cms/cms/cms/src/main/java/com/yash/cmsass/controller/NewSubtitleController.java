package com.yash.cmsass.controller;

import java.io.File;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;

/**
 * Servlet implementation class NewCourseController
 */
public class NewSubtitleController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	  String course="";
	  String maintitle="";
	  String subtitle="";
	  String filepath="";
	  String description="";
	  String status="";
	  String path="D:/AdvanceJava/cmsass/src/main/webapp/Documents/";
	  String newpath="";
	  PrintWriter out=response.getWriter();
	  Enumeration parameters=request.getParameterNames();

	  while(parameters.hasMoreElements()){
		  Object obj= parameters.nextElement();
		  String parameterName=(String)obj;
		  if(parameterName.equalsIgnoreCase("subtitleName")){
			  subtitle=request.getParameter(parameterName);
			  newpath=path+subtitle;
			  out.println(newpath);
				 File file=new File(newpath);
				 if(file.exists()){
					 
				 }
				 else{
					 file.mkdir();
				 }  
		  }
	  }
	  while(parameters.hasMoreElements()){
		  Object obj= parameters.nextElement();
		  String parameterName=(String)obj;
		  if(parameterName.equalsIgnoreCase("course")){course=request.getParameter(parameterName);}
		  if(parameterName.equalsIgnoreCase("mainTitle")){maintitle=request.getParameter(parameterName);}
		  if(parameterName.equalsIgnoreCase("filename")){		
			  MultipartRequest mp=new MultipartRequest(request, newpath);
			  String name=mp.getFilesystemName(parameterName);
			  out.println(name);
		  }
		  if(parameterName.equalsIgnoreCase("course")){course=request.getParameter(parameterName);}
		  
 	  }
	}

}
