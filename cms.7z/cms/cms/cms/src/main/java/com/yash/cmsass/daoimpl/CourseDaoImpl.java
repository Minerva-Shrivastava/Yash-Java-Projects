package com.yash.cmsass.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.yash.cmsass.dao.CourseDao;
import com.yash.cmsass.util.DBUtil;


public class CourseDaoImpl implements CourseDao{
	private DBUtil dbUtil=null;
	private Connection con;
	public CourseDaoImpl() {
		try {
			dbUtil = new DBUtil("com.mysql.jdbc.Driver");
			con=dbUtil.getConnection("jdbc:mysql://localhost/cms","root","root");
		} catch (ClassNotFoundException e1) {
			
			e1.printStackTrace();
		}
	}
	public ArrayList<String> getMaintitles(String course) {
		ArrayList<String> maintitle=new ArrayList<String>();
		String sql="SELECT maintitle FROM subtitle WHERE course='"+course+"' GROUP BY maintitle";
		PreparedStatement statement=null;
		try {
			statement=con.prepareStatement(sql);
			ResultSet rs=statement.executeQuery();
			while(rs.next())
			{
				maintitle.add(rs.getString("maintitle"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return maintitle; 
	}

	public ArrayList<String> getCourses() {
		ArrayList<String> courses=new ArrayList<String>();
		String sql="SELECT course FROM subtitle GROUP BY course";
		PreparedStatement statement=null;
		try {
			statement=con.prepareStatement(sql);
			ResultSet rs=statement.executeQuery();
			while(rs.next())
			{   String name=rs.getString("course");
			    if(name!=null)courses.add(name);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return courses;
	}
}
