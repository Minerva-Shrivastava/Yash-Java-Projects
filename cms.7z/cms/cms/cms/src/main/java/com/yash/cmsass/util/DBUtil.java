package com.yash.cmsass.util;
/**
 * this will create connection to database
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	private String driverClassName;
	private Connection con=null;
	/**
	 * this constructor will load the drivers
	 * @param driverClassName
	 * @throws ClassNotFoundException 
	 */
	public DBUtil(String driverClassName) throws ClassNotFoundException {
			    this.driverClassName=driverClassName;
				Class.forName(this.driverClassName);
			     System.out.println("Driver loaded");	
	}
	public DBUtil() {
	}
	/**
	 * this will create connection of give url ,username ,password to a MySQL database
	 * this will return connection object when called 
	 * @param url
	 * @param username
	 * @param password
	 * @return
	 */
	public Connection getConnection(String url,String username,String password){
		try {
			con=DriverManager.getConnection(url,username,password);
			System.out.println(con.getCatalog());
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}

}
