package com.yash.cmsass.form;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.cmsass.service.CourseService;
import com.yash.cmsass.serviceimpl.CourseServiceImpl;

/**
 * Servlet implementation class CourseForm
 */
public class CourseForm extends HttpServlet {
	private int a=0;
	private static final long serialVersionUID = 1L;
	private String course="";
	private CourseService courseService=new CourseServiceImpl();
	private LinkedHashMap<String, ArrayList<String>> courseAndTitle;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		courseAndTitle=courseService.getCourseAndMainTitle();
		htmlUtilHead(out);
		out.println("<select name='course' onchange='this.form.submit()' required>");
		out.println("<<option value=''>--select an option--</option>");
		for (Map.Entry m : courseAndTitle.entrySet()) {
			out.println("<option value='"+m.getKey()+"'>"+(m.getKey())+"</option>");
			a=0;
		}
		out.println("</select></td><td>");
		out.println("Subtitle<input type='text'>");
		out.println("</td></tr><tr><td>Main Title:");
		out.println("<select name='mainTitle'>");
		out.println("<<option disabled selected>--select an option--</option>");
		out.println("</select>");
		htmlUtilTail(out);

	}
	
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	response.setContentType("text/html");
    	course=request.getParameter("course");
    	if(a>0){
    	ServletContext servletContext = getServletContext();
    	RequestDispatcher requestDispatcher = servletContext.getRequestDispatcher("/NewSubtitleController");
    	requestDispatcher.forward(request, response);
    	}
		PrintWriter out = response.getWriter();
		courseAndTitle=courseService.getCourseAndMainTitle();
		htmlUtilHead(out);
		out.println("<select name='course' onchange='this.form.submit()' required>");
		out.println("<<option value=''>--select an option--</option>");
		for (Map.Entry m : courseAndTitle.entrySet()) {
			if(course.equalsIgnoreCase(""+m.getKey()))
			{out.println("<option value='"+m.getKey()+"' selected>"+(m.getKey())+"</option>");}
			else out.println("<option value='"+m.getKey()+"'>"+(m.getKey())+"</option>");
			
		}
		out.println("</select></td><td>");
		out.println("Subtitle<input type='text' name='subtitleName' required></td></tr><tr>");
		out.println("<td>Main Title:");
		out.println("<select name='mainTitle' required>");
		out.println("<<option value=''>--select an option--</option>");
		for (Map.Entry m : courseAndTitle.entrySet()) {
            if(course.equalsIgnoreCase(""+m.getKey())){
            	ArrayList<String> main=(ArrayList<String>) m.getValue();
            	for (String string : main) {
            		out.println("<<option>"+string+"</option>");   
            	}
            }
            a=1;
		}
		out.println("</select>");
		htmlUtilTail(out);

    }
    private void htmlUtilHead(PrintWriter out) {
		out.println("<html>");
		out.println("<head><title>Subtitle Upload</title></head>");
		out.println("<body>");
		out.println("<center>");
		out.println("<fieldset style='width: 300px'>");
		out.println("<legend>Add Sub Title</legend>");
		out.println("<form action='CourseForm' method='post'>");
		out.println("<table>");
		out.println("<tr><td>Course :");
	}
	private void htmlUtilTail(PrintWriter out) {
		out.println("</td><td>");
		out.printf("Upload File <input type='file' name='filename' required></td></tr><tr>");
		out.println("<td>Description</td>");
		out.println("</tr><tr>");
		out.println("<td colspan='2'><textarea name='description' rows='5' cols='40' required></textarea></td>");
		out.println("</tr><tr>");
		out.println("<td colspan='2'>Publish<input name='status' type='checkbox' checked /></td>");
		out.println("</tr><tr>");
		out.println("<td colspan='2' style='text-align: right;'><input type='submit' value='Submit'/></td>");
		out.println("</tr>");
		out.println("</table></form></fieldset></center></body></html>");
	}
}
