#Q1
DESC employees;
SELECT employeeNumber, lastName, extension, officeCode, reportsTo, jobTitle FROM employees; 

#Q2
SELECT DISTINCT jobTitle FROM employees;

#Q3
SELECT employeeNumber AS 'employee#',extension AS Extn, officeCode AS Office_Code , reportsTo AS ManagerID, jobTitle FROM employees;

#Q4
SELECT CONCAT(firstName ,',',lastName) AS employeeName FROM employees;

#Q5
SELECT CONCAT(e.`firstName`,' ',e.`lastName`) AS 'Employee Name' ,CONCAT(m.`firstName`,' ',m.`lastName`) AS 'Manager Name' FROM employees AS e , employees AS m WHERE e.`reportsTo`=m.`employeeNumber`;

#Q6
SELECT * FROM customers;
SELECT customerName,creditLimit FROM customers WHERE creditLimit BETWEEN 85100 AND 100600;

#Q7
SELECT firstName, lastName, officeCode FROM employees WHERE officeCode="4" OR officeCode="6" ORDER BY firstName;

#Q8
SELECT firstName, lastName FROM employees WHERE reportsTo IS NULL;

#Q9
SELECT contactFirstName,contactLastName, state, city FROM customers WHERE state IS NOT NULL ORDER BY state, city;

#Q10
SELECT contactLastName FROM customers WHERE contactLastName LIKE '_a%';

#Q11
SELECT contactLastName FROM customers WHERE contactLastName LIKE '%g%o%';

#Q12
SELECT firstName, lastName, officeCode, jobTitle FROM employees WHERE (jobTitle LIKE 'Sales Rep' OR jobTitle LIKE 'Sale% manager %')AND officeCode NOT IN (4,6,7);


INSERT INTO employees SELECT * FROM customers WHERE postalCode IN(SELECT customerNumber FROM customers);
