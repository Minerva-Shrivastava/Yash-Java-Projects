SELECT lastName FROM `employees` WHERE `officeCode` IN (SELECT officeCode FROM offices WHERE country ="USA");
SELECT officeCode FROM offices WHERE country ="USA";

SELECT MAX(amount) FROM payments;
SELECT `customerNumber`,checkNumber, amount WHERE amount = (SELECT MAX(amount) FROM payments);

SELECT AVG(amount) FROM payments;
SELECT `customerNumber`,checkNumber, amount WHERE amount = (SELECT MAX(amount) FROM payments);

SELECT DISTINCT `customerNumber` FROM orders;
SELECT customerName FROM customers WHERE `customerNumber` NOT IN(SELECT DISTINCT `customerNumber` FROM orders);

-- Exists or not exists
SELECT customerNumber 
FROM customers
WHERE EXISTS(
	SELECT priceEach*quantityOrdered 
	FROM orderdetails 
	WHERE priceEach*quantityOrdered > 10000
	GROUP BY orderNumber);
	































