-- Using ifnull function 
/* It would be nice if we can get the contact’s home phone if the contact’s business phone is not available.
This is where the IFNULL function comes to play. The IFNULL function returns the home phone if the business phone is NULL. */

SELECT * FROM contacts;
SELECT contactname,
	IFNULL(bizphone, homephone) phone
FROM contacts;

/* Notice that you should avoid using the IFNULL function in the WHERE clause, 
because it degrades the performance of the query. 
If you want to check if a value is NULL or not, 
you can use IS NULL or IS NOT NULL in the WHERE clause. */