SELECT DISTINCT country FROM customers;
SELECT country FROM `customers` GROUP BY country;

SELECT STATUS FROM orders GROUP BY STATUS;

SELECT STATUS, COUNT(*) AS 'Total Orders' FROM orders GROUP BY STATUS;

SELECT STATUS, (`quantityOrdered` * priceEach) AS Amount FROM orders INNER JOIN `orderdetails` GROUP BY STATUS;

SELECT O.status, SUM(OD.quantityOrdered*PriceEach) "Total Amount"
FROM `orders` O
INNER JOIN `orderdetails` OD
USING(`orderNumber`)
GROUP BY o.`status`;

SELECT O.status, SUM(OD.quantityOrdered*PriceEach) "Total Amount", 
FROM `orders` O
INNER JOIN `orderdetails` OD
USING(`orderNumber`)
GROUP BY o.`status`;

SELECT YEAR(`orderDate`) AS "Year",
	SUM(`quantityOrdered`*priceEach) AS total,
	STATUS
FROM orders 
	INNER JOIN 
	`orderdetails` USING(`orderNumber`)
WHERE STATUS = "Shipped"
GROUP BY YEAR(`orderDate`);

SELECT YEAR(`orderDate`) AS "Year",
	SUM(`quantityOrdered`*priceEach) AS total,
	STATUS
FROM orders 
	INNER JOIN 
	`orderdetails` USING(`orderNumber`)
WHERE STATUS = "Shipped"
GROUP BY YEAR(`orderDate`)
HAVING YEAR > 2003;

-- Total number of items along with total sales in each order
SELECT orderNumber,SUM(quantityOrdered) AS itemsCount,
SUM(priceEach)AS total
FROM orderdetails
GROUP BY orderNumber;

-- Total sales > 1000
SELECT orderNumber,SUM(quantityOrdered) AS itemsCount,
SUM(priceEach)AS total
FROM orderdetails
GROUP BY orderNumber
HAVING total > 1000;

-- Total sales > 1000 and itemsCount > 600
SELECT orderNumber,SUM(quantityOrdered) AS itemsCount,
SUM(priceEach)AS total
FROM orderdetails
GROUP BY orderNumber
HAVING total > 1000 AND itemsCount>600;

SELECT a.`orderNumber`orderNumber,STATUS,
	SUM(priceEach)AS total
FROM orderdetails a
	INNER JOIN orders b
	ON b.`orderNumber`=a.`orderNumber`
GROUP BY orderNumber
HAVING total > 1500 AND b.`status`='shipped';























































