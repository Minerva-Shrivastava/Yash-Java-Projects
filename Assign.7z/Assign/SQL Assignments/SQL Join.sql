SELECT CONCAT_WS(',',lastName, firstName) Full_Name
FROM employees
ORDER BY Full_Name;

SELECT orderNumber 'Order No.', SUM(quantityOrdered * priceEach) AS total
FROM orderdetails
GROUP BY 'Order No.'
HAVING total>60000;

-- Dispay Total Orders placed by each customer
SELECT customerNumber 'Customer No.', COUNT(orderNumber)AS Orders_Placed
FROM orders
GROUP BY customerNumber;

SELECT c.customerName, COUNT(O.orderNumber)AS Total_Orders
FROM customers AS c , orders AS o 
WHERE c.`customerNumber` = o.`customerNumber`
GROUP BY c.`customerName`;

SELECT c.customerName, COUNT(O.orderNumber)AS Total_Orders
FROM customers AS c  
INNER JOIN orders AS o 
ON c.`customerNumber` = o.`customerNumber`
GROUP BY c.`customerName`
ORDER BY `Total_Orders`;

SELECT productCode, productName, T1.`productLine`, T2.`textDescription`
FROM products AS T1
INNER JOIN productLines AS T2
ON T1.`productLine` = T2.`productLine`;

SELECT CONCAT(contactLastName,' ,',contactFirstName) AS 'Full Name', paymentDate, amount
FROM customers T1
INNER JOIN 
payments T2
ON t1.`customerNumber` = t2.`customerNumber`
ORDER BY 'Full Name';


-- Left Join

SELECT c.customerNumber, c.`contactFirstName`, o.orderNumber, o.status
FROM customers AS c
LEFT JOIN orders AS o 
ON c.`customerNumber` = o.`customerNumber`;

-- Customer who didn't order
SELECT c.customerNumber, c.`contactFirstName`, o.orderNumber, o.status
FROM customers AS c
LEFT JOIN orders AS o 
ON c.`customerNumber` = o.`customerNumber` ;

-- self join





