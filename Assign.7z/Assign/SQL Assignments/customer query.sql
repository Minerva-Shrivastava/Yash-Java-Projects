CREATE TABLE customer(
cust_first_name INT NOT NULL ,
cust_last_name VARCHAR(20) NOT NULL,
cust_gender CHAR(1) NOT NULL,
cust_year_of_birth INT(4) NOT NULL,
cust_maritial_status VARCHAR(20) NOT NULL,
cust_street_address VARCHAR(40) NOT NULL,
cust_postal_code  VARCHAR(10) NOT NULL,
cust_city VARCHAR(30) NOT NULL,
cust_state_province  VARCHAR(40) NOT NULL,
country_id INT NOT NULL,
cust_income_lever VARCHAR(30),
cust_credit_limit INT,
cust_email VARCHAR(30));

UPDATE customer SET cust_credit_limit=NULL WHERE cust_income_lever IS NULL;
UPDATE customer SET cust_credit_limit=TO_NUMBER('',9999) WHERE cust_income_lever IS NULL;