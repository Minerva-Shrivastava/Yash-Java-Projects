SELECT firstname,lastname,jobtitle FROM employees;
SELECT firstname,lastname,extension FROM employees;
SELECT firstname,email FROM employees;
SELECT * FROM employees;

SELECT DISTINCT firstname FROM employees ORDER BY firstname ;
SELECT DISTINCT officeCode FROM employees ;
SELECT COUNT(officeCode) FROM employees;
SELECT DISTINCT jobTitle FROM employees ;

SELECT state FROM customers ;
SELECT DISTINCT state FROM customers ;
SELECT DISTINCT state,city FROM customers WHERE state IS NOT NULL ORDER BY state;

SELECT state FROM customers GROUP BY state;

SELECT state FROM customers;
SELECT DISTINCT state FROM customers;
SELECT state FROM customers GROUP BY state;

SELECT DISTINCT state FROM customers WHERE state IS NOT NULL LIMIT 5;
SELECT DISTINCT state FROM customers WHERE state IS NOT NULL ;

SELECT * FROM employees WHERE jobTitle ="Sales Rep";
SELECT firstName, lastName,jobTitle FROM employees WHERE jobTitle ="Sales Rep";
SELECT * FROM employees WHERE jobTitle ="Sales Rep" AND officeCode="1";

SELECT * FROM products;
SELECT productName FROM products WHERE productLine ="Classic Cars";
SELECT productName,buyPrice FROM employees WHERE buyPrice>"$55.99" ORDER BY buyPrice;

SELECT * FROM customers;
SELECT customerName,country,state FROM customers WHERE country ="USA" AND state ="CA";
SELECT customerName,creditLimit,country,state FROM customers WHERE (country ="USA" AND state ="CA") AND creditLimit >100000;
SELECT contactLastName, creditLimit FROM customers WHERE creditLimit<100000;
SELECT contactLastName, customernumber FROM customers WHERE customerNumber="121";


SELECT (TRUE OR FALSE) AND FALSE;

SELECT contactFirstName, country FROM customers WHERE country ="USA" OR country="france";
SELECT * FROM customers WHERE (country ="USA" OR country="france") AND creditLimit>"100000";

SELECT firstName,lastName FROM customers ORDER BY lastName ASC;

SELECT * FROM customers ORDER BY firstName;


SELECT * FROM orders ;
SELECT orderNumber, STATUS FROM orders ORDER BY STATUS;
SELECT orderNumber, STATUS FROM orders ORDER BY FIELD(STATUS, 'In Process','On Hold', 'Cancelled', 'Resolved','Disputed', 'Shipped');



CREATE TABLE IF NOT EXISTS items(id INT AUTO_INCREMENT PRIMARY KEY, 
				item_no VARCHAR(255) NOT NULL);				
INSERT INTO items(item_no) VALUES ('1'),('1C'),('10Z'),('2A'),('2'),('3C'),('20D');
SELECT * FROM items;
SELECT * FROM items ORDER BY item_no; 
SELECT * FROM items ORDER BY CAST(item_no AS UNSIGNED), item_no;


