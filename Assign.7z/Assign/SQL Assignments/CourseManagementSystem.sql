CREATE DATABASE course_management_system;
CREATE TABLE subtitle(
	id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	course CHARACTER(30),
	mainTitle CHARACTER(30),
	subTitle CHARACTER(30),
	path CHARACTER(100),
	description TEXT,
	STATUS BINARY  
	);
INSERT INTO subtitle(course, mainTitle)
VALUES ('Java','Introduction'),
	('Java','OOPS'),
	('Java','Exception'),
	('Spring','IOC'),
	('Spring','MVC'),
	('Spring','JDBC'),
	('Spring','ORM'),
	('Hibernate','Intro'),
	('Hibernate','Cashing'),
	('Hibernate','Mapping'),
	('Hibernate','Inheritance');
SELECT * FROM `subtitle`;
		