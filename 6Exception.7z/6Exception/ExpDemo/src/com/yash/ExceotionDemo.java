package com.yash;

public class ExceotionDemo {

	public static void main(String[] args) {
		System.out.println("------Main : Line First --------");
		method1();
		System.out.println("------Main : Line Last--------");
	}
	
	public static void method1() {
		System.out.println("------Method1 : Line First --------");
		method2();
		System.out.println("------Method1 : Line First --------");
	}
	
	public static void method2() {
		System.out.println("------Method2 : Line First --------");
		int a = 10;
		int b = 0 ;
		int c = a/b;
		System.out.println("Result :"+c);
		System.out.println("------Method : Line First --------");
	}
}
