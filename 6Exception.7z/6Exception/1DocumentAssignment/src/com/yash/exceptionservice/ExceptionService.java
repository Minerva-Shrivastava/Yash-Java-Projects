package com.yash.exceptionservice;

import com.yash.Documents.CompanyDocument;
import com.yash.Documents.Document;
import com.yash.Documents.EducationalDocument;
import com.yash.Documents.PersonalDocument;
import com.yash.exception.InvalidDocumentTypeException;

/**
 * The sevice class for providing services like add a document to the repository
 * and list the documents of a particular type
 * @author minerva.shrivastava
 *
 */
public class ExceptionService {

	/** A repository of Document type and a variable location 
	 * to maintain the index uptil where the records are stored */
	private Document[] documentRepository ;
	private int location;
	
	/** Constructor to initialize the repository and the variable */
	public ExceptionService() {
		
		documentRepository = new Document[10];
		location = 0;
	}
	
	/** Method to add the incoming document into the repository*/
	public void addDocument(Document document) {
		
		documentRepository[location] = document;
		location++;
		
	}
	
	/** Method to fetch the documents of the type specified by the user given as parameter to this method 
	 * and this method returns the collection of that specified documents stored in the repository*/
	public Document[] getDocumentByType(Document document) throws InvalidDocumentTypeException
	{
		/**Temporary repository of Document type and a variable to maintain it's index 
		 * uptil which records are stored  */
		Document[] tempDocRepository = new Document[location];
		int tempRepLength = 0;
		
		/** A flag to detect whether a record is found or not*/
		boolean flag = false;
		
		/** Loop to traverse through the repository and search the specified documents */
		for(int i = 0; i<location; i++)
		{
			/** All Personal type documents are fetched and stored into a temporary repository*/
			if(document instanceof PersonalDocument) {
				if(documentRepository[i] instanceof PersonalDocument)
				{
					tempDocRepository[tempRepLength] = documentRepository[i];
					tempRepLength++;
					flag = true;
				}
			}
			
			/** All Company type documents are fetched and stored into a temporary repository*/
			if(document instanceof CompanyDocument) {
				if(documentRepository[i] instanceof CompanyDocument)
				{
					tempDocRepository[tempRepLength] = documentRepository[i];
					tempRepLength++;
					flag = true;
				}
			}
			
			/** All Educational type documents are fetched and stored into a temporary repository*/
			if(document instanceof EducationalDocument) {
				if(documentRepository[i] instanceof EducationalDocument)
				{
					tempDocRepository[tempRepLength] = documentRepository[i];
					tempRepLength++;
					flag = true;
				}
			}
			
			/*if(document instanceof Document) {
			
					tempDocRepository[tempRepLength] = documentRepository[i];
					tempRepLength++;
					flag = true;
				
			}*/
		
		}
		/** An exception is thrown if document type is not a valid one */
		if(flag == false)
		{
			throw new InvalidDocumentTypeException("Provided document type is not valid or not found");
		}
		
		/** Resultant repository having the fetched documents and returning as result*/
		Document[] resultrepository = new Document[tempRepLength];
		for(int i=0; i<tempRepLength; i++)
		{
			resultrepository[i] = tempDocRepository[i];
		}
		return resultrepository;
	}

	
	
	
}
