package com.yash.Documents;


/**
 * Subclass of the Document class to have the information of Educational Document
 * @author minerva.shrivastava
 *
 */
public class EducationalDocument extends Document{

	/** Default constructor */
	public EducationalDocument() {
		
	}
	/** Parameterized constructor */
	public EducationalDocument(int id, String title, String description) {
		this.id = id;
		this.title = title;
		this.description = description;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	/** Setter and getter methods for the instance variables of the class*/
	public int getId() {
		return id;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getTitle() {
		return title;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getDescription() {
		return description;
	}
}
