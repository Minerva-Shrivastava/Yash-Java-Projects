package com.yash.Documents;


/**
 * Subclass of the Document class to have the information of Company Document
 * @author minerva.shrivastava
 *
 */
public class CompanyDocument extends Document{

	/** Default constructor */
	public CompanyDocument() {
		
	}
	/** Parameterized constructor */
	public CompanyDocument(int id, String title, String decsription) {
		this.id = id;
		this.title = title;
		this.description = decsription;
	}
	
	/** Setter and getter methods for the instance variables of the class*/
	public void setId(int id) {
		this.id = id;
	}
	
	public int getId() {
		return id;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getTitle() {
		return title;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getDescription() {
		return description;
	}
}
