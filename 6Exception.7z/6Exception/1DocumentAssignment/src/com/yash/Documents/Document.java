package com.yash.Documents;

/**
 * Document is a parent class for all the documents
 * @author minerva.shrivastava
 *
 */
public class Document {

	int id ;
	String title;
	String description;
	
	/** Overriding the toString method of Object class to display the objects contents in a specific format */
	@Override
	public String toString() {
		
		return "\nDocument ID is: "+this.id+" Title is: "+this.title + " Description is: "+this.description;
	}
}
