package com.yash.ExceptionModal;

import java.util.Scanner;
import com.yash.Documents.CompanyDocument;
import com.yash.Documents.Document;
import com.yash.Documents.EducationalDocument;
import com.yash.Documents.PersonalDocument;
import com.yash.exception.InvalidDocumentTypeException;
import com.yash.exceptionservice.ExceptionService;

/**
 * The execution of the application starts here where user is displayed a menu 
 * to add and fetch documents 
 * @author minerva.shrivastava
 *
 */
public class StartupApplication {

	public static void main(String[] args) {
		
		/** The object of scanner class to interact with the user through the console window */
		Scanner sc = new Scanner(System.in);
		
		/** The object of Service class to access services */
		ExceptionService exceptionService = new ExceptionService();
		
		/** The object of various Document subclasses*/
		PersonalDocument personalDoc;
		EducationalDocument educationalDoc;
		CompanyDocument companyDoc;
		Document document = null;
		
		/** A variable of String type to access the menu again in the loop*/
		String continueChoice;
		
		/** A do-while loop for displaying the menu again */
		do 
		{
			System.out.println("******Menu******");
			System.out.println("\n 1. Add document - Types are :Personal, Company, Educatioanl"
							  +"\n 2. Search document by type"
							  +"\n 3. Exit");
			
			/** A variable for the input for the switch case*/
			int choice = sc.nextInt();
			switch (choice) {
				case 1: 
						/** Ask the user for the type of the document*/
						System.out.println("Which type of document do you want to add?");
				
						String addDocumentName = sc.next();
						
						/** Add the specified document after taking it's details */
						/** For personal document*/
						if(addDocumentName.equalsIgnoreCase("Personal"))
						{
							personalDoc = new PersonalDocument();
							
							System.out.println("Enter the document ID");
							int personallId = sc.nextInt();
							personalDoc.setId(personallId);
							System.out.println("Enter the document Title");
							sc.nextLine();
							String personalTitle = sc.nextLine();
							personalDoc.setTitle(personalTitle);
							System.out.println("Enter the document Description");
							String personalDesc= sc.nextLine();
							personalDoc.setDescription(personalDesc);
							
							exceptionService.addDocument(personalDoc);
						}
					
						/** For company document*/
						if(addDocumentName.equalsIgnoreCase("Company"))
						{
							companyDoc = new CompanyDocument();
							
							System.out.println("Enter the document ID");
							int companyId = sc.nextInt();
							companyDoc.setId(companyId);
							System.out.println("Enter the document Title");
							sc.nextLine();
							String companyTitle = sc.nextLine();
							companyDoc.setTitle(companyTitle);
							System.out.println("Enter the document Description");
							String companyDesc = sc.nextLine();
							companyDoc.setDescription(companyDesc);
							
							exceptionService.addDocument(companyDoc);
						}
						
						/** For educational document*/
						if(addDocumentName.equalsIgnoreCase("Educational"))
						{
							 educationalDoc = new EducationalDocument();
								
								System.out.println("Enter the document ID");
								int educationalId = sc.nextInt();
								educationalDoc.setId(educationalId);
								System.out.println("Enter the document Title");
								sc.nextLine();
								String educationalTitle = sc.next();
								educationalDoc.setTitle(educationalTitle);
								System.out.println("Enter the document Description");
								String educationalDesc = sc.nextLine();
								educationalDoc.setDescription(educationalDesc);
								
								exceptionService.addDocument(educationalDoc);
						}
						
						break;
						
				case 2: /** Option is for retrieving the documents*/
						
						System.out.println("\nWhich document do you want to view? "
							+ "Personal, "
							+ "Company, "
							+ "Educational, ");
				
						String documentNameToView = sc.next();
						
						/** For personal document*/
						if(documentNameToView.equalsIgnoreCase("Personal"))
						{
							document = new PersonalDocument();
						}	
					
						/** For educational document*/
						if(documentNameToView.equalsIgnoreCase("Educational"))
						{
							document = new EducationalDocument();
						}
						
						/** For company document*/
						if(documentNameToView.equalsIgnoreCase("Company"))
						{
							document = new CompanyDocument();
						}
						
						/*if(documentNameToView.equalsIgnoreCase("All"))
						{
							document = new Document();
						}*/
						/** Handling the exception the method throws */
						try {
								Document[] documentResult = exceptionService.getDocumentByType(document);
								for(Document result : documentResult)
								{
									System.out.println(result);
								}
							} catch (InvalidDocumentTypeException e) {
								
								//System.out.println("There's an exception");
								e.printStackTrace();
							}
						break;
						
				case 3:/** Option to exit from the application*/
						System.exit(0);
				
				default:System.out.println("Invalid option");
						break;
			}
				
				System.out.println("Do you want to continue?yes/no");
				continueChoice = sc.next();
		}while(continueChoice.equalsIgnoreCase(continueChoice));
	}
}
