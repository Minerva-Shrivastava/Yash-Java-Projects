package com.yash.exception;

/**
 * A custom exception class for an invalid type of document 
 * It extends Exception class to create a checked exception
 * @author minerva.shrivastava
 *
 */
public class InvalidDocumentTypeException extends Exception{

	/**
	 * Displays the message describing the problem
	 * @param msg
	 */
	public InvalidDocumentTypeException(String msg) {
		super(msg);
	}
}
