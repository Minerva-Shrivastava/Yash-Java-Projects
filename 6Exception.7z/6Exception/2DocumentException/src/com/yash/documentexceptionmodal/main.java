package com.yash.documentexceptionmodal;

import java.util.Scanner;

import com.yash.documents.Document;
import com.yash.exceptionservice.ExceptionService;

public class main {

	public main() {
		Scanner sc = new Scanner(System.in);
		ExceptionService exceptionService = new ExceptionService();
		String type;
		

		Document personal = new PersonalDocument(1,"personal","mydoc");
		Document educational = new PersonalDocument(1,"educational","mydoc");
		Document company = new PersonalDocument(1,"company","mydoc");
		
		Document[] documentarray = new Document[10];
		documentarray[0] = personal;
		documentarray[1] = educational;
		documentarray[2] = company;
		
		Document documentResult1 = exceptionService.getDocumentByType(documentarray, "pers");
				
		System.out.println(documentResult1);
		System.out.println(documentResult2);
		System.out.println(documentResult3);
	}
}
