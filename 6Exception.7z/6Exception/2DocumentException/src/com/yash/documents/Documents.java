package com.yash.documents;

public class Documents {
	public abstract class Document {

		int id ;
		String title;
		String description;
		
		@Override
		public String toString() {
			
			return "\nDocument ID is : "+this.id+" title is : "+this.title;
		}
	}

}
