package com.yash.exceptionservice;

import com.yash.documents.Document;

public class ExceptionService {

	private Document[] documentRepository ;
	private int location;
	
	public ExceptionService() {
		
		documentRepository = new Document[10];
		location = 0;
	}
	
	public void adddocument(Document document) {
		
		documentRepository[location] = document;
		location++;
		
	}
	
	public Document[] getDocumentByType(Document[] documentarray, String type)
	{
		Document[] docByTypeArray = documentarray;
		for(int i = 0; i<docByTypeArray.length; i++)
		{
			if(docByTypeArray[i])
		}
				
		return docByTypeArray;
	}	
	
}
