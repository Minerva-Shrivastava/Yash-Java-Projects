package com.yash.StringMethodsTest;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class StringMethodsTest {

	private String str = "Hello";
	private String str1 =" Everyone";
	private String str2 =" Everyone";
	private String str3 =" EVeRyOnE";
	private String str4 ="Hello,Hello,Hello";
	
	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void test_for_charAt() {
		char result = str.charAt(0);
		assertEquals('H', result);
	}
	
	@Test
	public void test_for_concat() {
		String result = str.concat(str1);
		System.out.println("\nResult for Concat(): "+ result);
		assertEquals("Hello Everyone", result);
	}
	
	@Test
	public void test_for_contains() {
		boolean result = str.contains("lo");
		System.out.println("\nResult for Contains(): "+ result);
		assertEquals(true, result);
	}
	
	@Test
	public void test_for_endsWith() {
		boolean result = str.endsWith("lo");
		System.out.println("\nResult for endsWith(): "+ result);
		assertEquals(true, result);
	}
	
	@Test
	public void test_for_equals() {
		boolean result = str1.equals(str2);
		System.out.println("\nResult for equals(): "+ result);
		assertEquals(true, result);
	}

	@Test
	public void test_for_equalsIgnoreCase() {
		boolean result = str1.equalsIgnoreCase(str3);
		System.out.println("\nResult for equalsIgnoreCase(): "+ result);
		assertEquals(true, result);
	}
	
	@Test
	public void test_for_indexOf() {
		int result = str1.indexOf('y');
		System.out.println("\nResult for IndexOf(): "+ result);
		assertEquals(5, result);
	}
	
	@Test
	public void test_for_intern() {
		String result = str1.intern();
		System.out.println("\nResult for intern(): "+ result);
		assertEquals(" Everyone", result);
	}
	
	@Test
	public void test_for_lastIndexOf() {
		int result = str1.lastIndexOf('e');
		System.out.println("\nResult for lastIndexOf(): "+ result);
		assertEquals(8, result);
	}
	
	@Test
	public void test_For_Length() {
		int result = str1.length();
		System.out.println("\nResult for lenth(): "+ result);
		assertEquals(9, result);
	}
	
	@Test
	public void test_For_Replace() {
		String result = str3.replace('E', 'e');
		System.out.println("\nResult for replace(): "+ result);
		assertEquals(" eVeRyOne", result);
	}
	
	@Test
	public void test_For_Split() {
		String[] result = str4.split(",");
		System.out.println("\nResult for split(): "+ result);
		String[] expected = new String[3];
		expected[0] = "Hello";
		expected[1] = "Hello";
		expected[2] = "Hello";
		assertEquals(expected, result);
	}
	
	@Test
	public void test_For_To_Lower_Case() {
		String result = str3.toLowerCase();
		System.out.println("\nResult for toLowerCase(): "+ result);
		assertEquals(" everyone", result);
	}
	
	@Test
	public void test_For_To_Upper_Case() {
		String result = str3.toUpperCase();
		System.out.println("\nResult for toUpperCase(): "+ result);
		assertEquals(" EVERYONE", result);
	}
	
	@Test
	public void test_For_Trim() {
		String result = str3.trim();
		System.out.println("\nResult for trim(): "+ result);
		assertEquals("EVeRyOnE", result);
	}
	
	@Test
	public void test_For_ValueOf() {
		String result = str3.valueOf('y');
		System.out.println("\nResult for valueof(): "+ result);
		assertEquals("y", result);
	}
	
	@Test
	public void test_For_Substring() {
		String result = str3.substring(2, 5);
		System.out.println("\nResult for substring(): "+ result);
		assertEquals("VeR", result);
	}
	

}
