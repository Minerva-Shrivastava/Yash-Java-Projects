package com.yash.dividibleby7;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.math.BigInteger;

import org.junit.Before;
import org.junit.Test;

public class DivisibilityTest {

	Integer numberInRange = new Integer(101);
	Integer numberNotInRange = new Integer(0);
	private DivisibilityDemo div ;
	
	
	@Before
	public void setUp() throws Exception
	{
		//System.out.println("obj created");
		div = new DivisibilityDemo();
	}
	
	@Test
	public void test_Empty() {
		Integer result = div.divideBySeven(null);
		assertNull(result);
	}
	
	@Test
	public void test_No_In_Range() {
		Integer result = div.divideBySeven(numberInRange);
		assertEquals("2107", result.toString());
	}
	
	@Test
	public void test_Not_In_Range() {
		Integer result = div.divideBySeven(numberNotInRange);
		assertEquals("0", result.toString());
	}
}
