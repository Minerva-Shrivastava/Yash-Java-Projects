package com.yash.dividibleby7;

import java.math.BigInteger;

public class DivisibilityDemo {

	public Integer divideBySeven(Integer number) {
		
		if(number == null)
		{
			return null;
		}
		
		if(number < 100 || number >200)
		{
			return 0;
		}
		else {
		int sum = 0;
		
		for(int i = 100;i<=200;i++)
		{
			if(i%7 == 0)
			{
				sum += i;
			}
		}
		System.out.println(sum);
		return sum;
	
		}
	}
}
