package com.yash.carshop;

/**
 * Car represents a single car with its states as speed, owner, type
 * and count wich shows the number of cars sold
 * @author minerva.shrivastava
 *
 */
public class Car {

	private int speed;
	private String owner;
	private String type;
	static int count = 0;
	
	Car()
	{
		System.out.println("Object Created");
		count++;
	}
	
	/**
	 * setter for speed to set the speed of car
	 * @param speed
	 */
	public void setSpeed(int speed) {
		this.speed = speed;
		System.out.println(this.speed);
		
	}

	/**
	 * Getter for speed 
	 * @return speed
	 */
	public int getSpeed() {
		System.out.println(this.speed);
		return this.speed;
	}

	/**
	 * Setter to set the owner name
	 * @param owner
	 */
	public void setOwner(String owner) {
		this.owner = owner;
		
	}

	/**
	 * Getter for owner name 
	 * @return name of owner
	 */
	public String getOwner() {
		return owner;
	}

	/**
	 * Setter for Type of car
	 * @param type
	 */
	public void setType(String type) {
		this.type = type;
		
	}

	/**
	 * Getter for type of car
	 * @return type
	 */
	public String getType() {
		return type;
	}

	/**
	 * Count the number of cars sold
	 * @return
	 */
	public int carsSold()
	{
		System.out.println(count);
		return count;
	}
}
