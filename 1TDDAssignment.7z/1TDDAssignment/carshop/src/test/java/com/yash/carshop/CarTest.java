package com.yash.carshop;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class CarTest {
	
	private static Car newcar ;
	
	public CarTest() {
		newcar = new Car();
	}
	
	@Before
	public void setUp() throws Exception {
		
	}

	@Test
	public void test_Speed_Setter() {
		int speed = 100;
		newcar.setSpeed(speed);
	 	assertEquals(100, newcar.getSpeed());
	 	
	}

	@Test
	public void test_Owner_Setter() {
		String owner = "Amit";
		newcar.setOwner(owner);
	 	assertEquals(owner, newcar.getOwner());
	}

	/*@Test
	public void test_Owner_Getter() {
	 	String ownerresult=car.getOwner();
	 	assertEquals(owner, ownerresult);
	}*/
	
	@Test
	public void test_Type_Setter() {
	 	String type = "sedan";
		newcar.setType(type);
	 	assertEquals("sedan", newcar.getType());
	}

	/*@Test
	public void test_Type_Getter() {
	 	String ownerresult=car.getOwner();
	 	assertEquals(type, ownerresult);
	}*/

	@Test
	public void test_No_of_Cars_Sold() {
		newcar = new Car();
	 	int ownerresult=newcar.carsSold();
	 	assertEquals(4, ownerresult);
	}

}
