package com.yash.Q3urlSeperation;

import static org.junit.Assert.assertEquals;

import java.math.BigInteger;

import org.junit.Before;
import org.junit.Test;

import com.yash.Q3urlSeperation.Q3UrlSeperation;

import junit.framework.TestCase;

public class Q3UrlSeperationTest extends TestCase {

	
	String completeurl1 = new String("www.yash.com/index.jsp");
	String completeurl2 = new String("www.yash.com/empoyees/salary.xhtml");
	String completeurl3 = new String("www.google.com/searches/searchdata.jsp");
	private Q3UrlSeperation url ;
	
	
	@Before
	public void setUp() throws Exception
	{
		//System.out.println("obj created");
		url = new Q3UrlSeperation();
	}
	
	@Test
	public void test_Empty() {
		String result = url.seperate(null);
		assertEquals(null, result);
		
	}
	
	@Test
	public void test_CompeleteUrl1() {
		String result = url.seperate(completeurl1);
		assertEquals("index", result);
		
	}
	
	@Test
	public void test_CompeleteUrl2() {
		String result = url.seperate(completeurl2);
		assertEquals("salary", result);
		
	}
	
	@Test
	public void test_CompleteUrl3() {
		String result = url.seperate(completeurl3);
		assertEquals("searchdata", result);
		
	}
}
