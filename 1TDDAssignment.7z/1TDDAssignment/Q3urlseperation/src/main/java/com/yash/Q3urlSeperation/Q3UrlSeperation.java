package com.yash.Q3urlSeperation;

public class Q3UrlSeperation {

	public String seperate(String url) {
		
		if(url == null)
		{
			return null;
		}
		else {
		
			int lindx = url.lastIndexOf('/');
			String tempurl = url.substring(lindx);
			lindx = tempurl.lastIndexOf('.');
			String substring = tempurl.substring(1, lindx);
			return substring;
		}	
		


	}
}
