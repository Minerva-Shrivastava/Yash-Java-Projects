package com.yash.factorial;

import java.math.BigInteger;

//import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;



import junit.framework.TestCase;

public class FactorialTest extends TestCase {
	
	BigInteger startingNo = new BigInteger("1");
	BigInteger negativeNo = new BigInteger("-1");
	private FactorialDemo fact ;
	
	@Before
	public void setUp() throws Exception
	{
		//System.out.println("obj created");
		fact = new FactorialDemo();
	}
	
	@Test
	public void test_No_Input() {
		BigInteger result = fact.fatorial(null);
		assertNull(result);
		
	}
	
	@Test
	public void test_Any_Positive_No() {
		BigInteger result = fact.fatorial(startingNo);
		assertEquals("1", result.toString());
		
	}
	
	@Test
	public void test_Any_Negative_No_Input() {
		BigInteger result = fact.fatorial(negativeNo);
		assertEquals("0", result.toString());
		
	}
	
	

}
