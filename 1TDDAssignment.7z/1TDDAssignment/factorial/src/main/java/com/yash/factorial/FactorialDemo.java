package com.yash.factorial;

import static org.hamcrest.CoreMatchers.instanceOf;

import java.math.BigInteger;

public class FactorialDemo {

	public BigInteger fatorial(BigInteger number) {
		
			if(number == null)
			{
				return null;
			}
			
			if(number.intValue()<0)
			{
				BigInteger msg = new BigInteger("0");
				return msg;
			}
			
			BigInteger fact = new BigInteger("1");
			
			for(int i = 1;i<=number.intValue();i++)
			{
				fact = fact.multiply(BigInteger.valueOf(i)) ;
				
			}
			System.out.println(fact);
			return fact;
		
		
	}

}
