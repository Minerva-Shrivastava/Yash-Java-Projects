package com.yash.binaryequivalent;

import org.junit.Test;

import static org.junit.Assert.assertArrayEquals;

import org.junit.Before;

import junit.framework.TestCase;

public class BinaryEquiTest extends TestCase {

	private static final int ANY_VALID_INPUT=10;
	private BinaryEquiDemo binary;
	
	@Before
	public void setUp() throws Exception
	{
		//System.out.println("obj created");
		binary = new BinaryEquiDemo();
	}
	
	@Test
	public void test_Empty_Input() {
		int[] result = binary.equant(0);
		int[] test = new int[10];
		test[0] = 0;
		assertArrayEquals(test, result);
	}
	
	@Test
	public void test_Valid_Input() {
		int[] result = binary.equant(ANY_VALID_INPUT);
		int[] test = new int[10];
		test[0] = 0;
		test[1] = 1;
		test[2] = 0;
		test[3] = 1;
		assertArrayEquals(test, result);
	}
}
