package com.yash.expression;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;


import junit.framework.TestCase;

public class ExprTest extends TestCase {

private ExprDemo expr ;
	
	@Before
	public void setUp() throws Exception
	{
		//System.out.println("obj created");
		expr = new ExprDemo();
	}

	@Test
	public void test_empty() throws Exception {
		System.out.println("Empty Method");
		int result = expr.sum("");
		assertEquals(0,result);
	}
	
	@Test
	public void test_expression_having_addition_operator() throws Exception {
		System.out.println("Method");
		int result = expr.sum("100+200-300/400");
		assertEquals(1000,result);
	}	
}
