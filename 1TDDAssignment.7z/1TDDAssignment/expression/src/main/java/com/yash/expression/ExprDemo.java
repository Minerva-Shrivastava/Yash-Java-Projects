package com.yash.expression;

import java.util.Arrays;

public class ExprDemo {

	public int sum(String string) {
		if(string.isEmpty())
		{return 0;
		}
		else
			return Arrays.stream(string.split("[+\\-/*]")).mapToInt(Integer::parseInt).sum();
		
	
		
	}

}
