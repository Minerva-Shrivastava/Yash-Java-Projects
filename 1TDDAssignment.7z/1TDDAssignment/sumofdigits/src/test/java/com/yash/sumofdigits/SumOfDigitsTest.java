package com.yash.sumofdigits;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import junit.framework.TestCase;

public class SumOfDigitsTest extends TestCase {

	public void setUp() throws Exception {
		
	}
	
	@Test
	public void test_for_emptyExp() {
		SumOfDigits exp = new SumOfDigits();
		int result = exp.add("");
		assertEquals(0, result);
	}

	@Test
	public void test_for_Expression() {
		SumOfDigits exp = new SumOfDigits();
		int result = exp.add("2+3+4");
		assertEquals(9, result);
	}
}
