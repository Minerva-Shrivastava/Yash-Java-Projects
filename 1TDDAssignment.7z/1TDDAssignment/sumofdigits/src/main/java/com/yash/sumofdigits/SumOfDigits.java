package com.yash.sumofdigits;

import java.util.Arrays;

public class SumOfDigits {

	public int add(String input)
	{
		if(input.isEmpty())
		{
			return 0;
		}
		else return Arrays.stream(input.split("[\\+]")).mapToInt(Integer::parseInt).sum();
			
			
		}
		
	}

