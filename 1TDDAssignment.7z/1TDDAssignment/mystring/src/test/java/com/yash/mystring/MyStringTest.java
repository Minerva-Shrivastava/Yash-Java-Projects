package com.yash.mystring;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import junit.framework.TestCase;

public class MyStringTest extends TestCase {

	char[] chararray = {'H','e','l','l','o'};
	private MyString str = new MyString(chararray);
	
	public void setUp() throws Exception {
		
		
	}
	
	
	@Test
	public void test_for_charAt() {
		char result = str.myCharAt(3);
		assertEquals('l', result);
	}
	
	@Test
	public void test_for_length() {
		int result = str.myLength();
		assertEquals(5, result);
	}
	
	@Test
	public void test_for_myIndexOf() {
		int result = str.myindexOf('o');
		
		assertEquals(4, result);
	}
	
	/*@Test
	public void test_for_Concat() {
		char[] concat = {'E','v','e','r','y','o','n','e'};
		char[] result = str.myConcat(concat);
		assertEquals('l', result);
	}*/
}
