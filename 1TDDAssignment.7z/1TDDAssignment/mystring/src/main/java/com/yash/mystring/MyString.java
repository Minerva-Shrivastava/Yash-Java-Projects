package com.yash.mystring;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class MyString {
	
	char[] myString ;
	int count;
	int index;
 	
	public MyString(char[] chararray) {
		myString = chararray;
	}

	public char myCharAt(int index)
	{
		return myString[index];	
	}

	public int myLength() {
		for (char c : myString) {
			count++;
		}
		return count;
	}

	public int myindexOf(char character) {
		for (char c : myString) {
			if(c == character)
			{
				System.out.println("\nIndex of character "+character+" is : "+index);
				return index;
			}
			else
				index++;
			}
		return 0;		
	}

	
	
	/*public char[] myConcat(char[] concat) {
		
		return myString;
	}*/
}
