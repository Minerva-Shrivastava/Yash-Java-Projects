package com.yash.consecutivenos;

import java.math.BigInteger;

public class ConsecutiveDemo {

	public BigInteger add(BigInteger startingNo) {
			
			if(startingNo == null)
			{
				return null;
			}
		
			BigInteger sum = new BigInteger("0");
				for(int i = 0;i<10;i++)
					{
						sum = sum.add(startingNo);
						startingNo = startingNo.add(BigInteger.valueOf(1));
						
					}
				System.out.println("sum = "+sum);
				return sum;
		
		}
	}

	

