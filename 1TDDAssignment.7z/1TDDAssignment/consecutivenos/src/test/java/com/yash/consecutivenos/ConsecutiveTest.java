package com.yash.consecutivenos;

import static org.junit.Assert.*;

import java.math.BigInteger;

import org.junit.Before;
import org.junit.Test;

public class ConsecutiveTest {
	
	BigInteger startingNo = new BigInteger("-1");
	private ConsecutiveDemo consc ;
	
	
	@Before
	public void setUp() throws Exception
	{
		//System.out.println("obj created");
		consc = new ConsecutiveDemo();
	}
	
	@Test
	public void test_Empty() {
		BigInteger result = consc.add(null);
		assertNull(result);
		
	}
	
	@Test
	public void test_Any_No() {
		BigInteger result = consc.add(startingNo);
		assertEquals("35", result.toString());
	}
	
	
}
