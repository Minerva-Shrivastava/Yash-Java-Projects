package com.yash.totalevenodd;

import static org.junit.Assert.assertArrayEquals;

import org.junit.Before;
import org.junit.Test;

import junit.framework.TestCase;

public class TEvenOddTest extends TestCase {
	
	private static final String ANY_VALID_NO_AS_INPUT = "04356346210";
	//private static final String ANY_STRING_AS_INPUT= "sfg";
	
	private TEvenOddDemo evenodd ;
	private int[] array = new int[2];
	
	
	@Before
	public void setUp() throws Exception
	{
		//System.out.println("obj created");
		evenodd = new TEvenOddDemo();
	}
	
	@Test
	public void test_Empty() {
		int[] result = evenodd.total("");
		assertArrayEquals(array, result);
		
	}
	
/*	@Test
	public void test_For_Even() {
		int result = evenodd.total(ANY_VALID_NO_AS_INPUT);
		assertEquals(2, result);
		
	}
	
	@Test
	public void test_For_Odd() {
		int result = evenodd.total(ANY_VALID_NO_AS_INPUT);
		assertEquals(3, result);
		
	}*/
	
	@Test
	public void test_For_Even_And_Odd() {
		int[] result = evenodd.total(ANY_VALID_NO_AS_INPUT);
		array[0] = 7;
		array[1] = 4;
		assertArrayEquals(array, result);
	}
	
	/*@Test
	public void test_Any_Input() {
		int[] result = evenodd.total(ANY_STRING_AS_INPUT);
		array[0] = 0;
		array[1] = 0;
		assertArrayEquals(array, result);
		
	}*/
	
}
