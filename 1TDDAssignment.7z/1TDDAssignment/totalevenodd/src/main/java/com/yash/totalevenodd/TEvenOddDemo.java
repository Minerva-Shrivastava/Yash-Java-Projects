package com.yash.totalevenodd;



public class TEvenOddDemo {

	public int[] total(String string) {
		
		int[] array1 = new int[2];
		
		if(string.isEmpty()) {
			return array1;
		}
		
		
			System.out.println(array1[0]+" "+array1[1]);
			char[] array = string.toCharArray();
			int evencount = 0;
			int oddcount = 0,no1;
			
			for(char arr : array)
			{
				no1 = arr;
				if(no1%2 == 0)
				{
					evencount++;
				}
				else
					oddcount++;
			}
			array1[0] = evencount;
			array1[1] = oddcount;
			
			System.out.println(array1[0]+" "+array1[1]);
		return array1;
		
	}

	
}
