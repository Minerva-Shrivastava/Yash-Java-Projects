package com.yash.maxintinarray;
import java.util.Scanner;

/**
 * This class takes an array of integers and 
 * returns the index of maximum number in that array
 * @author minerva.shrivastava
 *
 */
public class MaxNumber {

	/**
	 * Object of Scanner class to take the input from user
	 * from console screen 
	 * It is made static so that all the methods can access it 
	 */
	static Scanner sc = new Scanner(System.in);
	
	/**
	 * Main method to start the execution
	 * @param args
	 */
	public static void main(String[] args) {
		
		/**
		 * An array and its size is taken as input
		 * The method maxInt is called which returns the index of the maximum number
		 */
		int[] array = null;
		MaxNumber maxNumber = new MaxNumber();
		System.out.println("\nEnter the no of integers you want to enter : " );
		int numbers = sc.nextInt();
		int[] maxIndexArray = maxNumber.MaxInt(array, numbers);
		System.out.println("\nThe maximum no is : "+maxIndexArray[0]);
		System.out.println("\nThe index of maximum no is : "+maxIndexArray[1]);
	}
	
	/**
	 * This method takes the address of array and size as parameters
	 * and returns the index of the maximum nunber in that array
	 * by searching every element of that array
	 * @param array
	 * @param numbers
	 * @return
	 */
	public int[] MaxInt(int[] array, int numbers) {
		
		/**
		 * initialization of array of the given size
		 */
		array = new int[numbers];
		
		
		/**
		 * variables to store max number and its index
		 */
		int max = 0;
		int indexMax = 0;
		
		/**
		 * User enters the elements of the array
		 */
		System.out.println("\nEnter the elements : ");
		for(int i = 0; i<numbers; i++)
		{
			array[i] = sc.nextInt();
		}
		
		/**
		 * Searching the index of maximum element by comparing the max var by every element of array
		 */
		System.out.println("\nSearching the index of maximum element : ");
		max = array[0];
		for(int i = 0; i<numbers; i++)
		{
			if(max < array[i] )
			{
				max = array[i];
				indexMax = i;
			}
		}
		/**
		 * returns the maximum element and its index
		 */
		int[] MaxIndexArray = new int[2];
		MaxIndexArray[0] = max;
		MaxIndexArray[1] = indexMax;
		return MaxIndexArray;
	}
	
}
