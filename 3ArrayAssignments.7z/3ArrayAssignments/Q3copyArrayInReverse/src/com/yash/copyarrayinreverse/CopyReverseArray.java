package com.yash.copyarrayinreverse;

import java.util.Scanner;

/**
 * This class has the functionality which copies an array 
 * in reverse order into another array
 * @author minerva.shrivastava
 *
 */
public class CopyReverseArray {
	
	/**
	 * An array of name array and size 10.
	 * An array of name reverse array to have the reverse of array, of same size
	 */
	int[] array = new int[10];
	int[] reversearray = new int[10];
	
	/**
	 * Object of Scanner class to take input from console screen
	 */
	Scanner sc = new Scanner(System.in);
	
	/**
	 * This method takes elements as an input to array
	 */
	public void enterArray() {
		
		System.out.println("\nEnter 10 elements");
		for(int i=0; i<10; i++)
		{
			array[i] = sc.nextInt();
			
		}
	}
	
	/**
	 * This method displays the array which was given by the user
	 */
	public void displayArray() {	
		System.out.println("\nYour Array is ");
		for(int i=0; i<10; i++)
		{
			System.out.print(array[i]+ " " );	
		}
		
	}
	
	
	/**
	 * This method displays the reversearray of the array which was given by the user
	 * It copies the array in reverse order into another array 
	 */
	public void displayReverseArray() {
		this.enterArray();
		this.displayArray();
		System.out.println("\nThe reverse Array is ");
		for(int i=0,j=array.length-1; i<array.length; i++,j--)
		{
			reversearray[i] = array[j];
		}
		System.out.println("\nThe array after reversal is: ");
		this.displayArray();
	}
}
