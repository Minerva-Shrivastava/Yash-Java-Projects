package com.yash.copyarrayinreverse;

/**
 * This is the class to test the CopyReverseArray class
 * @author minerva.shrivastava
 *
 */
public class CopyReverseArrayMain {

	public static void main(String[] args) {
		
		/**
		 * Creating the object of CopyReverseArray and calling its method for reverse array
		 */
		CopyReverseArray reverseArray = new CopyReverseArray();
		reverseArray.displayReverseArray();
	}
}
