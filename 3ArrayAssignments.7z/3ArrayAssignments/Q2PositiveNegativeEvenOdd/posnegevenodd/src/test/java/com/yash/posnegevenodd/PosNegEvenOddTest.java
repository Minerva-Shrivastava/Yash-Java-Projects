package com.yash.posnegevenodd;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


public class PosNegEvenOddTest {

	/**
	 * Object of the SearchDemo class
	 */	
	private PosNegEvenOdd input = new PosNegEvenOdd();
	
		
	/*@BeforeClass
	public void setUp() throws Exception {
		
	}*/

	/**
	 * Test case to check the count of positive numbers, negative numbers, even numbers,
	 * and odd numbers in the entered Array.
	 */
	@Test
	public void test_For_Count_Positive_Negative_Even_Odd() {
		input.enterArray();
		input.displayArray();
		int[] result = input.countPositiveNegativeEvenOdd();
		int[] expected = new int[4];
		expected[0] = 9;
		expected[1] = 5;
		expected[2] = 7;
		expected[3] = 8;
		assertArrayEquals(expected, result);
	}

	
}
