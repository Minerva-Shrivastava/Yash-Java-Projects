package com.yash.posnegevenodd;

import java.util.Scanner;

/**
 * This class is in correspondence to the PosNegEvenOddTest class.
 * This class takes array as input of size 15
 * Returns the array having count of positive numbers, negative numbers, even numbers, odd numbers.
 * @author minerva.shrivastava
 *
 */
public class PosNegEvenOdd {

	/**
	 * An array of name array and size 15.
	 */
	private int[] array = new int[15];
	
	/**
	 * Object of Scanner class to take input from console screen
	 */
	Scanner sc = new Scanner(System.in);
	
	/**
	 * This method takes elements as an input to array
	 */
	public void enterArray() {
		
		System.out.println("\nEnter 15 elements");
		for(int i=0; i<15; i++)
		{
			array[i] = sc.nextInt();
			
		}
	}
	
	/**
	 * This method displays the array which was given by the user
	 */
	public void displayArray() {	
		System.out.println("\nYour Array is ");
		for(int i=0; i<15; i++)
		{
			System.out.print(array[i]+ " " );	
		}
		
	}

	/**
	 * This method counts positive numbers, negative numbers, even numbers 
	 * and odd numbers and returns an array of these counts 
	 * @return
	 */
	public int[] countPositiveNegativeEvenOdd() {
		int[] resultArray = new int[4];
		int countPos = 0;
		int countNeg = 0;
		int countEven = 0;
		int countOdd = 0;
		
		for(int i=0; i<15; i++)
		{
			if(array[i] > 0)
			{
				countPos++;
			}	
			if(array[i] < 0)
			{
				countNeg++;
			}
			if(array[i] % 2 == 0)
			{
				countEven++;
			}
			if(array[i] % 2 != 0)
			{
				countOdd++;
			}
		}
		resultArray[0] = countPos;
		resultArray[1] = countNeg;
		resultArray[2] = countEven;
		resultArray[3] = countOdd;
		System.out.println("\nPositive numbers in the array are: "+ countPos);
		System.out.println("\nNegative numbers in the array are: "+ countNeg);
		System.out.println("\nEven numbers in the array are: "+ countEven);
		System.out.println("\nOdd numbers in the array are: "+ countOdd);
		return resultArray;
	}
	
	
}
