package model;

/**
 * Employee will represent the data, it is used to represent a single employee object
 * @author minerva.shrivastava
 *
 */

public class Employee {

	/** The states of Employee : ID, name, salary and age*/
	int id;
	String name;
	float salary;
	int age;
	
	/** Getter and Setter methods for above instance variables*/
	public void setId(int id) {
		this.id = id;
	}
	public int getId() {
		return id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public float getSalary() {
		return salary;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getAge() {
		return age;
	}
	
	/** Overriding toString method to display the Employee Object */
	@Override
	public String toString() {
		return "[ id :"+this.getId()+" name :"+ this.getName()+" salary :"+this.getSalary()+" age :"+getAge()+"]";
	}

	
	
}
