package service;

import model.Employee;

/**
 * This class provides services on employee repository
 * @author minerva.shrivastava
 *
 */
public class EmployeeService {
	
	/** This is the local employee repository. */
	private Employee[] employeeRepositry;
	
	/** variable for array index */
	private int location;

	/** Constructor to initialize the repository and its index value */
	public EmployeeService() {
		employeeRepositry = new Employee[2];
		location = 0;
	}
	
	
	/**
	 *This method adds the employees to the repository 
	 *and doubles the repository size when initial repository is completely filled
	 * @param employee the input argument
	 */
	public void addEmployee(Employee employee)
	{
		System.out.println("Employee added at location : "+location);
		if(location >= employeeRepositry.length)
		{
			Employee[] newemployeeRepositry = new Employee[employeeRepositry.length*2];
			for(int i=0 ;i<employeeRepositry.length ;i++)
			{
				newemployeeRepositry[i] = employeeRepositry[i]; 
			}
			employeeRepositry = newemployeeRepositry;
		}
		System.out.println("Repository length :"+employeeRepositry.length);
		employeeRepositry[location++] = employee;
		
	}
	
	
	/**
	 * This method creates the temporary array of employees in the repository and returns that array
	 * @return an array of employee type
	 */
	public Employee[] listEmployee()
	{
		Employee[] templist = new Employee[location];
		System.out.println("\n There is/are "+location+" employees");
		if(location<=0) 
		{
			System.out.println("There are no records");
			return templist;
		}
		else
		{
			for(int i = 0 ; i<location ; i++)
			{
				templist[i] = employeeRepositry[i];
			}
			return templist;
		}	
			
	}
	

	/**
	 * This method deletes the employee by searching through employee's ID
	 * @param id is the input argument
	 */
	public void deleteEmployeeById(int id)
	{
		//System.out.println(location);
		if(location<=0) 
		{
			System.out.println("There are no records");
		}
		else 
		{
			
			for(int i=0 ; i<location ; i++)
			{
				if(employeeRepositry[i].getId() == id)
				{
					System.out.println("\nThe Employee "+employeeRepositry[i]+" will be deleted");
					for(int j=i; j<employeeRepositry.length-1 ; j++) 
					{
						employeeRepositry[j]=employeeRepositry[j+1];
					}
					location--;
				}
			}
		}
		
		System.out.println("\nThe no of records are:" + location);
		
	}

	/**
	 * Method to sort the employee list by name
	 */
	public void sortEmployeeListByName() {
		
		Employee[] templist = new Employee[location];
		System.out.println("Location :"+location);
		if(location<=0) 
		{
			System.out.println("There are no records");
		}
		else
		{
			for(int i = 0 ; i<location ; i++)
			{
				templist[i] = employeeRepositry[i];
			}
			
			for(int i=0; i<location; i++)
			{
				for(int j=0; j<location-1; j++)
				{
					int compare = templist[j].getName().compareToIgnoreCase(templist[j+1].getName());
					//System.out.println("compare : "+compare);
					if(compare > 0)
					{
						Employee temp = templist[j];
						templist[j] = templist[j+1];
						templist[j+1] = temp;
					}
				}
			}

			System.out.println("The sorted employees are :");
			for(Employee element:templist )
			{
				System.out.println(element);
			}
		}	
		
	}

	/** Method to sort employee list by ID */
	public void sortEmployeeListById() {
		
		Employee[] templist = new Employee[location];
		System.out.println("Location :"+location);
		if(location<=0) 
		{
			System.out.println("There are no records");
		}
		else
		{
			for(int i = 0 ; i<location ; i++)
			{
				templist[i] = employeeRepositry[i];
			}
			
			for(int i=0; i<location; i++)
			{
				for(int j=0; j<location-1; j++)
				{
					if(templist[j].getId() > templist[j+1].getId())
					{
						Employee temp = templist[j];
						templist[j] = templist[j+1];
						templist[j+1] = temp;
					}
				}
			}

			System.out.println("The sorted employees are :");
			for(Employee element:templist )
			{
				System.out.println(element);
			}
		}	
		
	}
	
	/** Method to sort employee list by Salary */
	public void sortEmployeeListBySalary() {
		
		Employee[] templist = new Employee[location];
		System.out.println("Location :"+location);
		if(location<=0) 
		{
			System.out.println("There are no records");
		}
		else
		{
			for(int i = 0 ; i<location ; i++)
			{
				templist[i] = employeeRepositry[i];
			}
			
			for(int i=0; i<location; i++)
			{
				for(int j=0; j<location-1; j++)
				{
					if(templist[j].getSalary() > templist[j+1].getSalary())
					{
						Employee temp = templist[j];
						templist[j] = templist[j+1];
						templist[j+1] = temp;
					}
				}
			}

			System.out.println("The sorted employees are :");
			for(Employee element:templist )
			{
				System.out.println(element);
			}
		}	
		
	}

	/** Method to sort employee list by Age */
	public void sortEmployeeListByAge() {
			
			Employee[] templist = new Employee[location];
			System.out.println("Location :"+location);
			if(location<=0) 
			{
				System.out.println("There are no records");
			}
			else
			{
				for(int i = 0 ; i<location ; i++)
				{
					templist[i] = employeeRepositry[i];
				}
				
				for(int i=0; i<location; i++)
				{
					for(int j=0; j<location-1; j++)
					{
						if(templist[j].getAge() > templist[j+1].getAge())
						{
							Employee temp = templist[j];
							templist[j] = templist[j+1];
							templist[j+1] = temp;
						}
					}
				}

				System.out.println("The sorted employees are :");
				for(Employee element:templist )
				{
					System.out.println(element);
				}
			}	
		
	}
	
}
