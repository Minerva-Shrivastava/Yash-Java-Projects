package main;

import java.util.Scanner;
import model.Employee;
import service.EmployeeService;

/**
 * Starting point of application where services are called
 * @author minerva.shrivastava
 *
 */
public class StartupApplication {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);/**Object of Scanner class to take input from console */
		
		/**Reference of Employee class and object of EmployeeService class to access the services*/
		Employee employee ;
		EmployeeService employeeservice = new EmployeeService();
		
		int choice;
		String continuechoice;
		
		/**
		 * This Menu is for choosing the services that are provided
		 */
		
		do
		{
			System.out.println("****Main Menu****");
			System.out.println("\n Enter your choice "
					+ "\n 1. Add Employee	"
					+ "\n 2. List Employees  "
					+ "\n 3. Delete Employee"
					+ "\n 4. Sort Employees List By Name"
					+ "\n 5. Sort Employees List By ID"
					+ "\n 6. Sort Employees List By Salary"
					+ "\n 7. Sort Employees List By Age"
					+ "\n 0. Exit");
			choice = sc.nextInt();
			switch(choice)
			{
				case 1:  employee = new Employee();/**Add Employees to the list*/
				
						boolean match = true;
						do {
							try {
								System.out.println("Enter Employee ID");
								int id = sc.nextInt();
								
								employee.setId(id);
								}catch (Exception e) {
									System.out.println("Enter only numbers");
									match = false;
									
								}
						}while(match == false); 
						
						
						System.out.println("Enter Employee Name");
							employee.setName(sc.next());
							System.out.println("Enter Employee Salary");
							employee.setSalary(sc.nextFloat());
							System.out.println("Enter Employee Age");
							employee.setAge(sc.nextInt());
						
						
						employeeservice.addEmployee(employee);
						break;
						
				case 2: Employee[] employees = employeeservice.listEmployee();/**Display the list of employees*/
							for(Employee emp:employees)
							{
								System.out.println(emp);
							}
						break;
						
				case 3: System.out.println("Enter the Employee ID you want to delete");/**Delete employee by ID*/
						employeeservice.deleteEmployeeById(sc.nextInt()); 
						break;
						
				case 4:employeeservice.sortEmployeeListByName();
					    break;
					    
				case 5:employeeservice.sortEmployeeListById();
			    		break;
			    		
				case 6:employeeservice.sortEmployeeListBySalary();
	    				break;
	    				
				case 7:employeeservice.sortEmployeeListByAge();
	    				break;
						
				case 0: System.out.println("Thank you");
						sc.close();
						System.exit(0);/**Exit from the system*/
						break;
						
				default:System.out.println("Invalid");/**All other choices are invalid*/
			}
			System.out.println("Do you want to continue: yes/no?");/**Choice to continue in the loop*/
			continuechoice = sc.next();
		}while(continuechoice.equalsIgnoreCase("yes")); 
		
		
	}
}
