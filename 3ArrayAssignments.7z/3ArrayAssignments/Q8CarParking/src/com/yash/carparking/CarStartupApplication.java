package com.yash.carparking;

import java.util.Scanner;

/**
 * Car Parking Application's startup point
 * where user can choose services from the provided
 * @author minerva.shrivastava
 * 
 */
public class CarStartupApplication {

	public static void main(String[] args) {
		
		/**
		 * Object of Scanner class to take the input from console screen
		 */
		Scanner sc = new Scanner(System.in);
		/**
		 * Object of services class to access the services provided
		 */
		CarParkingServices carpark = new CarParkingServices();
		
		/**
		 * variable to continue in the loop displaying the menu
		 */
		String continuechoice;
		
		
		/**
		 * Do While loop for the menu of servicess
		 */
		do {
		System.out.println("\t\t\t*****Welcome To Car Parking*****");
		System.out.println("\n press 1 : If you want to park your car "
						 + "\n press 2 : If you want to take your car "
						 + "\n press 3 : Display parking space"
						 + "\n press 4 : Exit");
		int choice = sc.nextInt();
		
			
			/**
			 * Switch case to select a choice from the above menu
			 */
			switch (choice) {
			case 1: Car car = new Car();
					
					System.out.println("Enter registration no. of car");
					int regNo = sc.nextInt();
					car.setRegNo(regNo);
					
					System.out.println("Enter name of car");
					String name = sc.next();
					car.setName(name);
					
					System.out.println("Enter owner name of car");
					String ownerName = sc.next();
					car.setOwnerName(ownerName);
					
					car.setTokenNo();
					ParkingToken parkToken =  car.getTokenNo();
					//System.out.println(car);
					System.out.println(parkToken);
					
					carpark.parkCar(car);
					
					break;
	
			case 2:	System.out.println("Give the token no of the car you want to take out");
					int tokenNo = sc.nextInt();
					carpark.takeOutCar(tokenNo);
					break;
				
			case 3: System.out.println("\nShowing the parking space : ");
					carpark.displayParking();
					break;
			
			case 4:sc.close();
					System.exit(0);
					break;
				
			default:System.out.println("invalid entry");
					break;	
			}
			System.out.println("Do you want to continue?Yes/No");
			continuechoice = sc.next();
		}while(continuechoice.equalsIgnoreCase("yes"));
		
		System.out.println("\nThank you for visiting us");
	}
	
}
