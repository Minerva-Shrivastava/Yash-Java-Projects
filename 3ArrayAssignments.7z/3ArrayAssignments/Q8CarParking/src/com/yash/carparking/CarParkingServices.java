package com.yash.carparking;

/**
 * This class defines the services that are provided to the user which are 
 * 1.Park the car
 * 2.Take car out
 * 3.Display the parking space
 * @author minerva.shrivastava
 *
 */
public class CarParkingServices {
	
	/**
	 * Jagged array of car type
	 */
	private Car[][] carparking = new Car[5][];
	
	/**
	 * Initailization of array in constructor
	 */
	public CarParkingServices()
	{
		carparking[0] = new Car[1];
		carparking[1] = new Car[2];
		carparking[2] = new Car[3];
		carparking[3] = new Car[4];
		carparking[4] = new Car[5];
	}
	
	/**
	 * Method is for parking car at the next available space
	 * @param car
	 */
	public void parkCar(Car car)
	{
		System.out.println("Checking availability for immidiate next space");                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
		boolean flag = false;
		for(int i=4,floorNo=0; i>=0; i--,floorNo++)
		{
			for(int j=0; j<carparking[i].length; j++)
			{
				if(carparking[i][j]==null)
				{
					carparking[i][j] = car;
					System.out.println("Your car is parked at :"+floorNo+" floor and "+j+" slot");
					flag = true;
					break;
				}
			}			
			if(flag == true)
			{
				break;
			}
			else
			{
				continue;
			}
		
			
		}
		if(flag == false)
		{
			System.out.println("There is no more space left");
		}
		
	}
	
	/**
	 * Method is for Taking out the car by it's token number
	 * @param tokenNo
	 */
	public void takeOutCar(int tokenNo)
	{
		boolean flag = false;
		int storedTokNo;
		System.out.println("Taking out your car");
		
		for(int i=4,floorNo=0; i>=0; i--,floorNo++)
		{
			for(int j=0; j<=carparking[i].length; j++)
			{
				try {
				storedTokNo = carparking[i][j].getTokenNo().getTokNo();
				//System.out.println(storedTokNo);
				if(storedTokNo == tokenNo)
				{
					carparking[i][j] = null;
					System.out.println("You can take your car");
					System.out.println("Parking at :"+floorNo+" floor and "+j+" slot is now available");
					flag = true;
					break;
				}
				}catch (Exception e) {
					System.out.println("Empty slot");
				}
				continue;
				
				
			}
			if(flag == true)
			{
				break;
			}
			else
			{
				continue;
			}
		}
		if(flag == false)
		{
			System.out.println("Your car was not found");
		}
		
	}

	/**
	 * Method is for displaying the parking space
	 */
	public void displayParking() {
		
		for(int i=4,floorNo=0; i>=0; i--,floorNo++)
		{
			System.out.println("\nfloor : "+floorNo);
			for(int j=0; j<carparking[i].length; j++)
			{				
				try {
				System.out.print("\t"+"slot : "+j+" car : "+carparking[i][j].getRegNo()+" Token : "+carparking[i][j].getTokenNo().getTokNo());
				}catch (Exception e) {
					System.out.print("\t"+"slot : "+j+" Empty slot");
				}
				continue;
			}
			System.out.println("");
		}
		
	}
}


