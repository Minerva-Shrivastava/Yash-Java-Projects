package com.yash.carparking;
/**
 * Class to have a car having it's registration number, name, owner name, and token no
 * @author minerva.shrivastava
 *
 */
public class Car {
	
	/**
	 * Instance variables are 
	 * regNo for registration number of type interger
	 * name of type String 
	 * ownername of type string
	 * tokenNo of type ParkingToken class
	 */
	private int regNo;
	private String name;
	private String ownerName;
	private ParkingToken tokenNo;
	
	/**
	 * getter and setter methods for the instance variables
	 * @return
	 */
	public int getRegNo() {
		return regNo;
	}
	public void setRegNo(int regNo) {
		this.regNo = regNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public ParkingToken getTokenNo() {
		return tokenNo;
	}
	public void setTokenNo() {
		tokenNo = new ParkingToken();
		this.tokenNo = tokenNo.generateToken();
	}
	
	/**
	 * overriding the toString method to display the car details in the following format
	 */
	@Override
	public String toString() {
		
		System.out.print("\nCar details : ");
		return "\nThe registration no is: "+ this.getRegNo()
			  +"\ncar name :"+this.getName()
			  +"\nOwner name : "+this.getOwnerName();
	}
	
	
}
