package com.yash.carparking;

/**
 * Class for generating a token to be given 
 * when a car comes in the parking area
 * @author minerva.shrivastava
 *
 */
public class ParkingToken {

	/**
	 * Instance variables for generating tokens
	 */
	private static int totalCars = 1;
	private int tokNo;
	private String tokname;
	
	
	public ParkingToken() {
		  tokNo = totalCars++;
	}
	
	public ParkingToken generateToken()
	{	
		return this;
	}
	
	public int getTokNo() {
		return tokNo;
	}
	
	/**
	 * Overriding the toString method to display 
	 * the token object in the following format
	 */
	
	@Override
	public String toString() {
		
		return "\nThe token no is: "+ this.getTokNo();
	}
	
	
	
}
