package com.yash.searchelement;

import java.util.Scanner;


/**
 * This class is in correspondence to the SearchTest class.
 * This class takes array as input of size 10 and an element to search in that array.
 * @author minerva.shrivastava
 *
 */
public class SearchDemo {

	/**
	 * An array of name array and size 10.
	 */
	private int[] array = new int[10];
	/**
	 * Object of Scanner class to take input from console screen
	 */
	Scanner sc = new Scanner(System.in);
	
	/**
	 * This method takes elements as an input to array
	 */
	public void enterArray() {
		
		System.out.println("\nEnter 10 elements");
		for(int i=0; i<10; i++)
		{
			array[i] = sc.nextInt();
			
		}
	}
	
	/**
	 * This method displays the array which was given by the user
	 */
	public void displayArray() {	
		System.out.println("\nYour Array is ");
		for(int i=0; i<10; i++)
		{
			System.out.print(array[i]+ " " );	
		}
		
	}

	/**
	 * This method searches the element given by the user 
	 * This method also returns how many times that element occurs in the array
	 * @return
	 */
	public int searchArray() {
		
		System.out.println("\nEnter the number to be searched");
		int searchNumber = sc.nextInt();
		int count = 0;
		for(int i=0; i<10; i++)
		{
			if(array[i] == searchNumber)
			{
				count++;
			}
			
		}
		if(count>0)
		{
			System.out.println("\nNo is present in the array");
			System.out.println("The number appears "+count+" times");
		}
		else {
			System.out.println("\nNumber is not present in the array");
		}
		
		return count;
		
	}
	
	
	
	

}
