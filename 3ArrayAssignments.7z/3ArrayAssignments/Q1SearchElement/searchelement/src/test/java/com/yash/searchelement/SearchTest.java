package com.yash.searchelement;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * This class is to test whether an element is in the given array or not.
 * @author minerva.shrivastava
 *
 */
public class SearchTest {

	/**
	 * Object of the SearchDemo class
	 */
	private SearchDemo input = new SearchDemo();
	

	public SearchTest() {
		input.enterArray();
		input.displayArray();
	}
	
	/**
	 * Test case to check whether the number entered by the user is present or not.
	 * If the number is not present the countresult, should be zero 
	 * If the number is present, the countresult should be the number of times 
	 * the number occurs in the array
	 */
	@Test
	public void test_Number_is_present() {
		int countresult = input.searchArray();
		assertEquals(0, countresult);
	}

	
}
