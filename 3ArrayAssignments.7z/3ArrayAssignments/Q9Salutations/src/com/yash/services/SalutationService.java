package com.yash.services;

import com.yash.salutations.Person;

/**
 * Salutation Service class for providing services on the Person class to add the salutations
 * @author minerva.shrivastava
 *
 */
public class SalutationService {

	/**
	 * An array to have the list of persons
	 */
	private Person[] person;
	
	/**
	 * An array of salutations
	 */
	private String[] sal;
	
	/**
	 * A 2 Dimensional array to have the index of both salutation and person
	 */
	private int[][] salPerson;
	
	/**
	 * Variable to get the location of person array uptil which it is filled
	 */
	private int locationPerson;

	
	/**
	 * Constructor for initializing the person array and the salutation array
	 */
	public SalutationService() {
		person = new Person[10];
		
		sal = new String[3];
		sal[0] = "Mr." ;
		sal[1] = "Ms";
		sal[2] = "Mrs";
	}
	
	/**
	 * Method for adding the new person into the person array
	 * @param newperson
	 */
	public void addPerson(Person newperson) {

		person[locationPerson++] = newperson;
		
	}

	/**
	 * Method for displaying the person array uptil the location the array is filled
	 */
	public void showAllPeople() {
		
		for(int i=0;i<locationPerson; i++)
		{
			System.out.println(person[i]);
		}
		
	}

	/**
	 * Method for adding the salutations according to the gender and the marital status
	 */
	public void addSalutations() {
		
		salPerson = new int[locationPerson][2];
		for(int i=0; i<locationPerson; i++)
		{
			String gender = person[i].getGender();
			if(gender.equalsIgnoreCase("male"))
			{
				salPerson[i][0] = 0;
				salPerson[i][1] = i;
			}
			if(gender.equalsIgnoreCase("female"))
			{
				String maritalStatus = person[i].getMaritalStatus();
				if(maritalStatus.equalsIgnoreCase("married"))
				{
					salPerson[i][0] = 2;
					salPerson[i][1] = i;
				}
				if(maritalStatus.equalsIgnoreCase("unmarried"))
				{
					salPerson[i][0] = 1;
					salPerson[i][1] = i;
				}
			}
			
		}
		
		this.showSalutations();
		
	}

	/**
	 *Method for displaying the full name of the person with salutations
	 */
	private void showSalutations() {
		
		System.out.println("in showsalutations");
		for(int i=0; i<salPerson.length; i++)
		{
			System.out.println("Full Name : "+sal[salPerson[i][0]]+" "+person[salPerson[i][1]].getName());
			System.out.println();
		}
		
	}

}
