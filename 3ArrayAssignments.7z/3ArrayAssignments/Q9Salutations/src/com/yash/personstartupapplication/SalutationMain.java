package com.yash.personstartupapplication;

import java.util.Scanner;

import com.yash.salutations.Person;
import com.yash.services.SalutationService;
import com.yash.salutations.*;

/**
 * The salutation main class is the startup application where the menu is displayed to the user
 * having choices to add a person, show the list of people, and add salutations
 * @author minerva.shrivastava
 *
 */
public class SalutationMain {

	public static void main(String[] args) {
		
		/**
		 * Object of scanner class to take input from the console screen 
		 */
		Scanner sc = new Scanner(System.in);
		
		/**Reference of person class */
		Person person;
		
		/**Object of Service class */
		SalutationService service = new SalutationService();
		
		/**Variable to continue in the DoWhile loop */
		String continueChoice;
		
		/**DoWhile loop to display the menu to the user and a switch case to choose from the menu */
		do {
			System.out.println("\t\t\t*****Welcome To Adding Salutations*****");
			System.out.println("\n press 1 : Add Person"
							 + "\n press 2 : Show Persons"
							 + "\n press 3 : Add Salutions"
							 + "\n press 4 : Exit");
			int choice = sc.nextInt();
			
				
				/**
				 * Switch case to select a choice from the above menu
				 */
				switch (choice) {
				case 1: person = new Person();/**Object of person class to enter the details of the person */
						
						System.out.println("Enter name");
						String name = sc.next();
						person.setName(name);
						
						System.out.println("Enter gender");
						String gender = sc.next();
						person.setGender(gender);
						
						System.out.println("Enter maritalStatus");
						String maritalStatus = sc.next();
						person.setMaritalStatus(maritalStatus);
						
						service.addPerson(person);/**Service to add person in the array*/
						break;
		
				case 2:	service.showAllPeople();/**Service to display the people added in the array*/
						break;
					
				case 3: service.addSalutations();/**Service to add salutations*/
						break;
				
				case 4:System.exit(0);/**The case to exit from the system*/
					
				default:System.out.println("invalid entry");/**Any entry apart from the cases is invalid entry*/
					break;	
				}
				System.out.println("Do you want to continue?yes/no");/**Choice to continue in the loop*/
				continueChoice = sc.next();
		}while(continueChoice.equalsIgnoreCase("yes"));
	}
}
