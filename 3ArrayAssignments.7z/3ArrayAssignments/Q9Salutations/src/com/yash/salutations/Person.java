package com.yash.salutations;

/**
 * Person represents the data of person
 * It is used to represent a single person object
 * @author minerva.shrivastava
 *
 */
public class Person {

	/**
	 * The details of person here include name, gender and marital status
	 */
	private String name;
	private String gender;
	private String maritalStatus;
	
	
	/**
	 * The getter and setter methods for each of the instance variables
	 * @return
	 */
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	
	/**
	 * Overriding the toString method to represent in the following format
	 */
	@Override
	public String toString() {
	
		return "\nName : "+this.getName()+"\t Gender : "+ this.getGender()+"\t Marital Status : "+ this.getMaritalStatus();
	}
}
