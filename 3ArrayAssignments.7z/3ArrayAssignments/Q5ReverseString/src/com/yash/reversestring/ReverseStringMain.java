package com.yash.reversestring;

import java.util.Scanner;

/**
 * This is the class to test the ReverseString class
 * @author minerva.shrivastava
 *
 */
public class ReverseStringMain {

	public static void main(String[] args) {
		
		/**
		 * Creating the object of RerverseString class and calling its methods
		 */
		ReverseString reverseString = new ReverseString();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("\nEnter the string : ");
		String input1 = sc.nextLine();
		
		String reverse = reverseString.reverseIt(input1);
		String reverse1 = reverseString.reverseIt("able was I era I saw elba");
				
		System.out.println("\nReverse Strings: ");
		System.out.println(reverse);
		System.out.println(reverse1);
		
	}
	
}
