package com.yash.reversestring;

public class ReverseString {

	/**
	 * This method takes the string and swaps the first and last, second and 
	 * next to last characters and so on
	 * which is done through a character array
	 * And the reverse array is the result
	 * @param givenString
	 * @return
	 */
	public String reverseIt(String givenString)
	{
		char[] temp = new char[givenString.length()];
		temp = givenString.toCharArray();
		char tempVar;
		
		for(int i=0,j=temp.length-1; i<temp.length/2; i++,j--)
		{
			
			tempVar = temp[i];
			temp[i] = temp[j];
			temp[j] = tempVar;
			
			//givenString.replace(givenString.charAt(i), givenString.charAt(j)) ;
		}
		String reverseString = new String(temp);
		//System.out.println(reverseString);
		return reverseString;
		
	}
	
}
