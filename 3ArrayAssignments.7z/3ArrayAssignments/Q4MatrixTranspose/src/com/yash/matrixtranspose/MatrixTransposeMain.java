package com.yash.matrixtranspose;

/**
 * This is the class to test the MatrixTranspose class
 * @author minerva.shrivastava
 *
 */
public class MatrixTransposeMain {

	public static void main(String[] args) {
		
		/**
		 * Creating the object of CopyReverseArray and calling its method to transpose the matrix
		 */
		MatrixTranspose matrix = new MatrixTranspose();
		matrix.Transpose();
		
	}
}
