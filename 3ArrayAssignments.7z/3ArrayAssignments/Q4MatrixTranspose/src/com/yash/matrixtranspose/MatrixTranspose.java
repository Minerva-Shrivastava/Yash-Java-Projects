package com.yash.matrixtranspose;

import java.util.Scanner;

/**
 * The class is for taking the transpose of the given matrix
 * @author minerva.shrivastava
 *
 */
public class MatrixTranspose {

	/**
	 * An matrix of name matrix and size 16(4*4).
	 */
	int[][] matrix = new int[4][4];
	/**
	 * An object of Scanner class to take the input from console
	 */
	Scanner sc = new Scanner(System.in);
	
	/**
	 * The method for user to enter the matrix
	 */
	public void entermatrix()
	{
		System.out.println("\nEnter the elements of matrix:");
		for(int i = 0; i<4; i++)
		{
			for(int j = 0; j<4; j++)
			{
				matrix[i][j] = sc.nextInt();
			}
		}
		this.displayMatrix();
		
	}
	
	
	/**
	 * The method to display the matrix
	 */
	public void displayMatrix()
	{
		System.out.println("\nYour matrix is : ");
		for(int i = 0; i<4; i++)
		{
			for(int j = 0; j<4; j++)
			{
				System.out.print("\t"+matrix[i][j]); 
			}
			System.out.println("");
		}
	}
	
	
	/**
	 * The method to transpose the entered matrix\
	 * where elements in the row of the matrix are replaced by the elements in the column
	 */
	public void Transpose()
	{
		this.entermatrix();
		System.out.println("\nTaking the transpose of matrix");
		int temp;
		for(int i = 0; i<4; i++)
		{
			for(int j = i; j<4; j++)
			{
				temp = matrix[i][j];
				matrix[i][j] = matrix[j][i];
				matrix[j][i] = temp;
			}
		}
		this.displayMatrix();
	}
	
}
