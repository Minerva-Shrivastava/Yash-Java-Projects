import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;


public class CollectionDemo {

	public static void main(String[] args) {
	
		ArrayList<String> names = new ArrayList<String>();
		names.add("Minerva");
		
		HashSet<String> set = new HashSet<>();
		set.add("Minerva");
		
		HashMap<String, String> map = new HashMap<>();
		
		map.put("1", "Minu");
		map.keySet();
 		
	}

}
