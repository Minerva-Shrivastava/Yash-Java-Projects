
public class hashSetTest {

	public static void main(String[] args) {
		
		MyHashSet mySet = new MyHashSet();
		
		String firstName = "Minerva";
		String lastName = "Shrivastava";
		
		mySet.add(firstName);
		mySet.add(lastName);
		
		MyOwnClass class1 = new MyOwnClass();
		class1.setId(0);
		class1.setName("Amit");
		mySet.add(class1);
		
		MyOwnClass class2 = new MyOwnClass();
		class1.setId(1);
		class1.setName("Amrita");
		mySet.add(class2);
		
		MyOwnClass class3 = new MyOwnClass();
		class1.setId(2);
		class1.setName("Ami");
		mySet.add(class3);
		
		Integer integer1 = new Integer(12);
		Integer integer2 = new Integer(123);
		Integer integer3 = new Integer(127);
		Integer integer4 = new Integer(127);
		
		
		mySet.add(integer1);
		mySet.add(integer2);
		mySet.add(integer3);
		mySet.add(integer4);
		
		System.out.println("The Set has :");
		mySet.displaySet();
		
	}
	
}
