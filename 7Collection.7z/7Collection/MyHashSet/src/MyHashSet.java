import java.util.HashSet;

public class MyHashSet {

	HashSet myHashSet; 

	public MyHashSet() {
		myHashSet = new HashSet<>(5);
	}
	
	public void add(Object object)
	{
		myHashSet.add(object);
	}
	
	public void displaySet()
	{
		for (Object object : myHashSet) {
			System.out.println(object);
		}
	}
}
