
public class LinkedHashSetDemoTest {
	public static void main(String[] args) {
		
		LinkedHashSetDemo LinkedHashSetDemo = new LinkedHashSetDemo();
		Integer givenInteger = new Integer(1000);
		Integer givenInteger1 = new Integer(200);
		Integer givenInteger2 = new Integer(300);
		
		LinkedHashSetDemo.addInteger(givenInteger);
		LinkedHashSetDemo.addInteger(givenInteger1);
		LinkedHashSetDemo.addInteger(givenInteger2);
		
		String firstName = "Minerva";
		String firstName1 = "Amit";
		String lastName = "Shrivastava";
		
		LinkedHashSetDemo.addString(firstName);
		LinkedHashSetDemo.addString(firstName1);
		LinkedHashSetDemo.addString(lastName);
	
		
		LinkedHashSetDemo.display();
	}
}
