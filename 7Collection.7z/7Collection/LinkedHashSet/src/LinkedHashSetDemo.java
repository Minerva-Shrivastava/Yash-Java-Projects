import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class LinkedHashSetDemo {

	Set<String> linkedSetString;
	Set<Integer> linkedSetInteger;
	
	public LinkedHashSetDemo() {
		linkedSetString = new LinkedHashSet<String>();
		linkedSetInteger= new LinkedHashSet<Integer>();
	}
		
	
	public void addString(String givenString)
	{
		linkedSetString.add(givenString);
	}
	
	public void addInteger(Integer givenInteger)
	{
		linkedSetInteger.add(givenInteger);
	}
	
	public void display()
	{
		System.out.println("Linked Hash set of strings");
		for (String str : linkedSetString) {
			System.out.println(str);
		}
		System.out.println("Linked Hash set of integers");
		for (Integer integer : linkedSetInteger) {
			System.out.println(integer);
		}
		
	}
}
