import java.util.Set;
import java.util.TreeSet;

public class TreeSetDemo {

	Set<String> treeSetString;
	Set<Integer> treeSetInteger;
	
	public TreeSetDemo() {
		treeSetString = new TreeSet<String>();
		treeSetInteger = new TreeSet<Integer>();
	}
	
	public void addString(String givenString)
	{
		treeSetString.add(givenString);
	}
	
	public void addInteger(Integer givenInteger)
	{
		treeSetInteger.add(givenInteger);
	}
	
	public void display()
	{
		System.out.println("Tree set of strings");
		for (String str : treeSetString) {
			System.out.println(str);
		}
		System.out.println("Tree set of integers");
		for (Integer integer : treeSetInteger) {
			System.out.println(integer);
		}
		
	}
	
}
