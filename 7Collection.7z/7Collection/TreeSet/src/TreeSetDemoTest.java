
public class TreeSetDemoTest {

	public static void main(String[] args) {
		
		TreeSetDemo treeSetDemo = new TreeSetDemo();
		Integer givenInteger = new Integer(1000);
		Integer givenInteger1 = new Integer(200);
		Integer givenInteger2 = new Integer(300);
		
		treeSetDemo.addInteger(givenInteger);
		treeSetDemo.addInteger(givenInteger1);
		treeSetDemo.addInteger(givenInteger2);
		
		String firstName = "Minerva";
		String firstName1 = "Amit";
		String lastName = "Shrivastava";
		
		treeSetDemo.addString(firstName);
		treeSetDemo.addString(lastName);
		treeSetDemo.addString(firstName1);
		
		treeSetDemo.display();
	}
}
