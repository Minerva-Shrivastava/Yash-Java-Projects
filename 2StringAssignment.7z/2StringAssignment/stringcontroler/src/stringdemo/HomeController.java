package stringdemo;

public class HomeController implements IController {

	@Override
	public  void getController(String name){
		System.out.println("Home Controller");
	}

	@Override
	public void isActivate(String controller) {
		if(controller.equals("home"))
			System.out.println(controller+" controller Activated");
		
	}
}
