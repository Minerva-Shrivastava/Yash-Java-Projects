package stringdemo;

public class URLSeperation {
	
	public static void main(String[] args) {
		
		FrontController urlsep = new FrontController();
		
		String url1 = "http://www.yash.com/employees/showEmployeeList.htm";
		
		String url2 = "http://www.yash.com/users/salary.do";
		String url3 = "http://www.yash.com/home.jsp";
		String url4 = "http://www.yash.com/admin/show/listusers.htm";
		
		
		String url5 = "http://www.yash.com/admin/show/listusers.htm";
		
		urlsep.seperate(url2);
		urlsep.seperate(url3);
		urlsep.seperate(url4);
		
		/*String substring = urlsep.seperate(url1);
		System.out.println(substring);
		new HomeController().isActive(substring);
		
		substring = urlsep.seperate(url2);
		System.out.println(substring);
		new SalaryController().isActive(substring);
		
		substring = urlsep.seperate(url3);
		System.out.println(substring);
		new AdminController().isActive(substring);*/
	}
	
	/*public String seperate(String url)
	{
		int lindx = url.lastIndexOf('/');
		String tempurl = url.substring(lindx);
		lindx = tempurl.lastIndexOf('.');
		String substring = tempurl.substring(1, lindx);
		return substring;
	}*/
	
}
