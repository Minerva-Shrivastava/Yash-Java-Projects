package stringdemo;

public interface IController {

	public void getController(String name);
	public void isActivate(String controller);

}
