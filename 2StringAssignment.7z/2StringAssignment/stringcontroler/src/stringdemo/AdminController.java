package stringdemo;

public class AdminController implements IController {

	@Override
	public void getController(String name){
		System.out.println("Admin Controller");
	}
	
	@Override
	public void isActivate(String controller) {
		if(controller.equals("listusers"))
		System.out.println(controller+" controller Activated");
		
	}
}
