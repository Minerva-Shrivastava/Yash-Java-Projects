package stringdemo;


public class FrontController {

	public void seperate(String url)
	{
		int lindx = url.lastIndexOf('/');
		String tempurl = url.substring(lindx);
		lindx = tempurl.lastIndexOf('.');
		String substring = tempurl.substring(1, lindx);
		
		FrontController.callController(substring);
	}
	
	public static void callController(String contname){
		switch(contname){
		case "salary":{
			IController sc=new SalaryController();
			sc.getController("salary");
			sc.isActivate("salary");
			}
			break;
		case "home":{
			IController hc=new HomeController();
			hc.getController("home");
			hc.isActivate("home");;
		
			}
			break;
		case "listusers":{
			IController ac=new AdminController();
			ac.getController("listusers");
			ac.isActivate("listusers");		
			}
			break;
		default:System.out.println("no controller activated");
			}
	}
}