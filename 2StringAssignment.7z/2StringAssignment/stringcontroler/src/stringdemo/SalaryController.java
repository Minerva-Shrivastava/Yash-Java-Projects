package stringdemo;

public class SalaryController implements IController{

	@Override
	public void getController(String name){
		System.out.println("Salary Controller");
	}
	
	@Override
	public void isActivate(String controller) {
		if(controller.equals("salary"))
		System.out.println(controller+" controller Activated");
		
	}
}
