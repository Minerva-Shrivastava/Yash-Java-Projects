
public class Calculator {
	
		public static void main(String[] args)
		{
			Calculator c = new Calculator();

			int a = c.calc("");
			int b = c.calc("10");
			int d = c.calc("10,20");
		}
		
		public int calc(String val)
		{
			int num = 0;
			int sum = 0;
			for(int i=0;i<val.length();i++)
			{
				if(val.charAt(i)==',')
				{
					num = (int)sum;
					sum += num;
					num = 0;
				}
				String snum = null;
				snum = snum + val.charAt(i);
				
				
			}
			return sum;
			
		}

	
}
