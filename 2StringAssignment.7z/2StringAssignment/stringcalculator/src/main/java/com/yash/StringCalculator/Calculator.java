package com.yash.StringCalculator;

import java.util.Arrays;

public class Calculator {

	public int add(String string) {
		
		if(string.isEmpty())
		{return 0;
		}
		else
			return Arrays.stream(string.split(",")).mapToInt(Integer::parseInt).sum();
			
			/*if(string.indexOf(",")!=-1)
		{
			String strings[] = string.split(",");
			int sum = 0;
			for(String stringNumber : strings)
			{
				sum += Integer.parseInt(stringNumber);
			}
			return sum;
		}
		else
		return Integer.parseInt(string);
		*/
		
	}

}
