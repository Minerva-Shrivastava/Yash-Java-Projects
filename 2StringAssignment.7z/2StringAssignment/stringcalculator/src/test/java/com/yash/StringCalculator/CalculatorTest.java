package com.yash.StringCalculator;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import junit.framework.TestCase;

public class CalculatorTest extends TestCase {
	private static final String ANY_VALID_SINGLE_STRING_AS_INPUT = "3";
	private Calculator calculator;
	
	
	
	@Test
	public void test_empty() throws Exception {
		System.out.println("Empty Method");
		int result = calculator.add("");
		assertEquals(0,result);
	}
	
	@Test
	public void test_two_numbers_seperated_by_comma_return_sum_of_input() throws Exception {
		System.out.println("Empty Method");
		int result = calculator.add("100,200,300");
		assertEquals(600,result);
	}	
	@Test
	public void test_for_single_value_input_asAnySingleNumber() throws Exception {
		System.out.println("Single Input Method");
		int result = calculator.add(ANY_VALID_SINGLE_STRING_AS_INPUT);
		assertEquals(3,result);
	}
}
