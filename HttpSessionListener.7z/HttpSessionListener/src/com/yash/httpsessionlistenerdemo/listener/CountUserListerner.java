package com.yash.httpsessionlistenerdemo.listener;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;


public class CountUserListerner implements HttpSessionListener {

	private ServletContext ctx;
	private static int totalUserCount = 0;
	private static int currentUserCount = 0;
	
	
    public void sessionCreated(HttpSessionEvent httpSessionEvent)  { 
         
    	System.out.println("******************************");
    	System.out.println("sessionCreated method has been called in "
        		 + this.getClass().getName());
         
         totalUserCount++;
         currentUserCount++;
         
         ctx = httpSessionEvent.getSession().getServletContext();
         ctx.setAttribute("totalUsers", totalUserCount);
         ctx.setAttribute("currentUsers", currentUserCount);
         
         System.out.println("******************************");
         
    }

	/**
     * @see HttpSessionListener#sessionDestroyed(HttpSessionEvent)
     */
    public void sessionDestroyed(HttpSessionEvent arg0)  { 
         
    	System.out.println("******************************");
    	System.out.println("sessionDestroyed method has been called in"
    			+ this.getClass().getName());
    	currentUserCount--;
    	ctx.setAttribute("currentUsers", currentUserCount);
    	System.out.println("******************************");
    }
	
}
