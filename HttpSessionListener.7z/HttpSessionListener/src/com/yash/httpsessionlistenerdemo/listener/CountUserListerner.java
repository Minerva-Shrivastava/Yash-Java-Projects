package com.yash.httpsessionlistenerdemo.listener;

import javax.servlet.ServletContext;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 * Application Lifecycle Listener implementation class CountUserListerner
 *
 */
@WebListener
public class CountUserListerner implements HttpSessionListener {

	private ServletContext ctx = null;
	private static int totalUserCount = 0;
	private static int currentUserCount = 0;
	/**
     * Default constructor. 
     */
    public CountUserListerner() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see HttpSessionListener#sessionCreated(HttpSessionEvent)
     */
    public void sessionCreated(HttpSessionEvent httpSessionEvent)  { 
         System.out.println("sessionCreated method has been called in "
        		 + this.getClass().getName());
         totalUserCount++;
         currentUserCount++;
         
         ctx = httpSessionEvent.getSession().getServletContext();
         ctx.setAttribute("totalUsers", totalUserCount);
         ctx.setAttribute("currentusers", currentUserCount);
         
    }

	/**
     * @see HttpSessionListener#sessionDestroyed(HttpSessionEvent)
     */
    public void sessionDestroyed(HttpSessionEvent arg0)  { 
         
    	System.out.println("sessionDestroyed method has been called in"
    			+ this.getClass().getName());
    	currentUserCount--;
    	ctx.setAttribute("currentUsers", currentUserCount);
    }
	
}
