package com.yash.httpsessionlistenerdemo.controller;


import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	
    
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		
		String name = request.getParameter("name");
		out.println("welcome "+name);
		
		HttpSession session = request.getSession(true);
		session.setAttribute("uname", name);
		
		
		ServletContext ctx = getServletContext();
		int totalUsers = (Integer) ctx.getAttribute("totalUsers");
		int currentUsers = (Integer) ctx.getAttribute("currentUsers");
		
		out.println("<br> Total users :"+totalUsers);
		out.println("<br> Current logged users :"+currentUsers);
		
		out.println("<br> <a href='Logout' >logout</a>");
		
		out.close();
		
	}
}
