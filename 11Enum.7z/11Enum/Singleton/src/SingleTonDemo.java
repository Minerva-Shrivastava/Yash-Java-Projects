
public class SingleTonDemo {

	public static void main(String[] args) {
		
		SingleObject object =  SingleObject.getInstance();
		SingleObject object1 =  SingleObject.getInstance();
		object.showMessage();
		object1.showMessage();
	}
}
