package com.yash.enumerator;

public enum Color {
RED,GREEN,BLUE;
}
