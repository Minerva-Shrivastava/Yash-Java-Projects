package com.yash.main;

import javax.xml.parsers.DocumentBuilderFactory;

import com.yash.enumcurrrency.enumerations.Currency;

public class EnumCurrencyDemo {

	public static void main(String[] args) {

		/*
		 * Currency currency = Currency.DIME; System.out.println(currency);
		 */
		for (Currency coin : Currency.values()) {
			System.out.println(coin);
		}
	}
}