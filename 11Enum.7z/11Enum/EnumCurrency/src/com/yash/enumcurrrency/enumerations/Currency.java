package com.yash.enumcurrrency.enumerations;

enum Gender {
	MALE, FEMALE, OTHER
};

public enum Currency {

	PENNY(1) {
		@Override
		public String color() {
			return "Copper";
		}
	},
	NICKLE(5) {
		@Override
		public String color() {
			return "Bronze";
		}
	},
	DIME(10) {
		@Override
		public String color() {
			return "Silver";
		}
	},
	QUARTER(25) {
		@Override
		public String color() {
			return "Silver";
		}
	};

	private int value;

	private Currency(int value) {
		this.value = value;
	}

	public abstract String color();

	@Override
	public String toString() {

		switch (this) {
		case DIME:
			return "\n Dime Coin - " + "value is:" + value + ", color is:" + this.color();

		case NICKLE:
			return "\n Nickle Coin - " + "value is:" + value + ", color is:" + this.color();

		case PENNY:
			return "\n Penny Coin - " + "value is:" + value + ", color is:" + this.color();

		case QUARTER:
			return "\n Quarter Coin - " + "value is:" + value + ", color is:" + this.color();

		default:
			return "\n Invalid option";

		}
	}
}
