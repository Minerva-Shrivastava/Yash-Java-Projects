package com.yash.userstatus.service;

import java.util.ArrayList;
import java.util.List;

import com.yash.userstatus.modal.User;

/**
 * Providing services for the user status class
 * @author minerva.shrivastava
 *
 */
public class UserStatusService {

	/** A repository to store users */
	private List<User> userRepository ;
	
	/** Constructor to initialize the user repository*/
	public UserStatusService() {
		userRepository = new ArrayList<>();
	}
	
	/** Adding the user into the repository by this method*/
	public void addUser(User user)
	{
		userRepository.add(user);
	}
	
	/** Method to display the repository*/
	public List<User> listUser()
	{
		return userRepository;
	}
	
	/** Method for updating the user status in the repository*/
	public void updateUser(User givenUser)
	{
		for (User user : userRepository) {
			if(user.getId()==(givenUser.getId()))
			{
				user.setName(givenUser.getName());
				user.setStatus(givenUser.getStatus().getValue());
				System.out.println("updating "+givenUser.getStatus().toString());
				System.out.println("Update successful");
			}
		}
	}
	
}
