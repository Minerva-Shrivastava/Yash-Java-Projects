package com.yash.userstatus.main;

import java.util.Scanner;

import com.yash.userstatus.enumerator.UserStatusEnum;
import com.yash.userstatus.modal.User;
import com.yash.userstatus.service.UserStatusService;

/**
 * The UserStatusEnum applications starts from this class having main method
 * @author minerva.shrivastava
 *
 */
public class UserStatus {

	UserStatusEnum status;
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		/**
		 * Printing all the statuses a user can be in
		 */
		System.out.println("\n There are four statuses a user can be in : ");
		for (UserStatusEnum status : UserStatusEnum.values()) {
			System.out.println(status);
		}
		
		String conitnueChoice = null;
		UserStatusService service = new UserStatusService();
		
		/**
		 * Displaying the menu to add, update and list user statuses
		 */
		do {
			
			System.out.println("*****Menu*****");
			System.out.println("\n 1.Add user"
							 + "\n 2.Update status"
							 + "\n 3.List status");
			int choice = sc.nextInt();
			switch (choice) {
			case 1: User user = new User();
					System.out.println("\n Enter ID");
					int id = sc.nextInt();
					user.setId(id);
					System.out.println("\n Enter name");
					sc.nextLine();
					String name = sc.nextLine();
					user.setName(name);
					System.out.println("\n Enter status");
					String status = sc.next();
					user.setStatus(status);
					service.addUser(user);
				break;
				
			case 2: User updateUser = new User();
					System.out.println("\n Enter ID");
					int id1 = sc.nextInt();
					updateUser.setId(id1);
					System.out.println("\n Enter name");
					sc.nextLine();
					String name1 = sc.nextLine();
					updateUser.setName(name1);
					System.out.println("\n Enter status");
					String status1 = sc.next();
					updateUser.setStatus(status1);
					service.updateUser(updateUser);
				break;
				
			case 3: for (User listUser: service.listUser()) {
						System.out.println(listUser);
					}
					break;
					
			default:System.out.println("Invalid option");
				break;
			}

			System.out.println("\n Do you want to continue?yes/no");
			conitnueChoice = sc.next();
		} while (conitnueChoice.equalsIgnoreCase("yes"));
		sc.close();
	}
}
