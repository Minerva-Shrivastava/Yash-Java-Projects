package com.yash.userstatus.modal;

import com.yash.userstatus.enumerator.UserStatusEnum;

/**
 * Class representing user and his information
 * @author minerva.shrivastava
 *
 */
public class User {

	
	/** Instance variables id, name and status  */
	private int id;
	private String Name;
	UserStatusEnum status;
	
	/** Getter and setter methods for the instance variables*/
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public UserStatusEnum getStatus() {
		return status;
	}
	
	/** Setting the status of the user*/
	public void setStatus(String status) {
		
		if(status.equalsIgnoreCase("active"))
			this.status = UserStatusEnum.ACTIVE;
		if(status.equalsIgnoreCase("pending"))
			this.status = UserStatusEnum.PENDING;
		if(status.equalsIgnoreCase("inactive"))
			this.status = UserStatusEnum.INACTIVE;
		if(status.equalsIgnoreCase("deleted"))
			this.status = UserStatusEnum.DELETED;
		
	}
	
	/** Overriding the toSting method to display the user object*/
	@Override
	public String toString() {
		
		return "[ user ID:"+this.getId()+" user name:"+this.getName()+" "+this.getStatus()+" ]";
	}

}
