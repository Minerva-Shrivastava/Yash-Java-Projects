package com.yash.fileIO.presentation;

import java.io.IOException;
import java.util.Scanner;

import com.yash.fileIO.modal.Employee;
import com.yash.fileIO.service.Authentication;

public class StartupApplication {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		Scanner sc = new Scanner(System.in);
		Employee employee = new Employee();
		Authentication auth = new Authentication();
		String continueChoice;
		do {
			System.out.println("*****Menu*****");
			System.out.println("\n 1.Registration"
							 + "\n 2.Login") ;
			
			int choice = sc.nextInt();
			
			switch (choice) {
			case 1:
					System.out.println("\n Enter your details : ");
					System.out.println("\n Enter your ID: ");
					int id = sc.nextInt();
					employee.setId(id);
					System.out.println("\n Enter your designation : ");
					String designation = sc.next();
					employee.setDesignation(designation);
					System.out.println("\n Enter your name: ");
					sc.nextLine();
					String name = sc.nextLine();
					employee.setName(name);
					System.out.println("\n Enter your password : ");
					String pwd = sc.next();
					employee.setPassword(pwd);
					
					auth.registration(employee);
				
				break;
				
			case 2:	
					System.out.println("\n Enter your credentials : ");
					System.out.println("\n Enter your userName: ");
					sc.nextLine();
					String userName = sc.nextLine();
					System.out.println("\n Enter your password : ");
					String password = sc.next();
					auth.authenticate(userName, password);

			default:
				break;
			}
			System.out.println("\n Do you want to continue?yes/no");
			continueChoice = sc.next();
		} while (continueChoice.equalsIgnoreCase("yes"));
		
		
		
		System.out.println("\n Enter designation :");
		String name = sc.nextLine();
		System.out.println("\n Enter password :");
		String pwd = sc.next();
		System.out.println("\n Welcome "+name+" with password :"+pwd);

		sc.close();
	}
}
