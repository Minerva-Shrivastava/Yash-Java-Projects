package com.yash.fileIO.modal;

import java.io.Serializable;

public class Employee implements Serializable{

	private int id;
	private String designation;
	private String name;
	private String password;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	@Override
	public String toString() {
		
		return "[ ID:"+this.getId()+" Designation:"+this.getDesignation()+" Name:"+this.getName()+" password:"+this.getPassword()+" ]";
	}

	
}
