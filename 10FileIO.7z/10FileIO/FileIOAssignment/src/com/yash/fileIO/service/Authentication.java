package com.yash.fileIO.service;

import java.io.BufferedReader;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import com.yash.fileIO.modal.Employee;

public class Authentication {


	public void registration(Employee employee) throws IOException, ClassNotFoundException
	{
		System.out.println("Registering");
		
		String path = "C:\\Users\\minerva.shrivastava\\Documents\\workspace-sts-3.9.1.RELEASE\\10FileIO\\FileIOAssignment\\Registration\\Register.txt";
		File File = new File(path);
		if(File.mkdirs())
			System.out.println("Directory made");
		if(File.createNewFile())
			System.out.println("File made");
		
		//Writing in file Register.txt
		FileWriter fw = new FileWriter(path,true);
		String str = " ID : "+employee.getId()+" designation : "+employee.getDesignation()+" Name : "+employee.getName()+" password : "+employee.getPassword()+System.lineSeparator();
		CharSequence csq = str;
		fw.append(csq);
		fw.flush();
		
		//Writing objects in file RegisterObjects.txt
		String path1 = "C:\\Users\\minerva.shrivastava\\Documents\\workspace-sts-3.9.1.RELEASE\\10FileIO\\FileIOAssignment\\Registration\\RegisterObject.txt";
		File RegObj = new File(path1);
		if(RegObj.createNewFile())
			System.out.println("RegisterObject file made");
		FileOutputStream fos = new FileOutputStream(RegObj, true);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(employee);
		
		fw.close();
		fos.close();
		oos.close();
		
		System.out.println("Registeration successful");
		
	}
	
	
	public String authenticate(String designation, String password) throws IOException, ClassNotFoundException
	{
		System.out.println("Authenticating");
		String path = "C:\\Users\\minerva.shrivastava\\Documents\\workspace-sts-3.9.1.RELEASE\\10FileIO\\FileIOAssignment\\Registration\\RegisterObject.txt";
		File fileView = new File(path);
		
		FileInputStream fis = new FileInputStream(fileView);
			
		ObjectInputStream ois = new ObjectInputStream(fis);
	
		Employee savedObject1 = (Employee)ois.readObject();
		System.out.println(savedObject1);
		
		Employee savedObject2 = (Employee)ois.readObject();
		System.out.println(savedObject2);
		try {
			while(ois.readObject()!=null)
			{
				System.out.println("Into loop");
				Employee savedObject = (Employee)ois.readObject();
				System.out.println(savedObject);
			}
		}catch (EOFException e) {
			System.out.println("End of file reached");
		}
			
		ois.close();
		
		/*InputStreamReader fr = new InputStreamReader(fis);
		BufferedReader br = new BufferedReader(fr);
		
		while() {
			System.out.println("All objects");
			System.out.println(br.readLine());
			Employee foundObj = (Employee) ois.readObject();
			System.out.println(foundObj);
		}
		
		br.close();*/
		
		return null;
	}
	
}
