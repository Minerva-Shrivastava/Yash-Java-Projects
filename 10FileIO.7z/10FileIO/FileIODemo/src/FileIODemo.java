import java.io.File;
import java.io.FileDescriptor;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileIODemo {

	public static void main(String[] args) throws IOException {
	
		File file = new File("B.txt");
		file.createNewFile();
		FileWriter fw = new FileWriter(file);
		fw.write("khgjh");
		fw.close();
		
		/*FileReader fr = new FileReader("Abc.txt");
		int i=fr.read();
		while(i!=-1)
		{
			System.out.print((char)i);
			i=fr.read();
		}
		
		fr.close();*/
	}
	
}
