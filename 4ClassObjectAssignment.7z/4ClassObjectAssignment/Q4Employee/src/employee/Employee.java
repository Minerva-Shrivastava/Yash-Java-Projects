package employee;

/**
 * Class for representing the Employee data - Employee No and Employee compensation
 * @author minerva.shrivastava
 *
 */
public class Employee {

	/** Instance variables for employee number and employee compensation */
	private int empNo;
	private float empCompensation;
	
	/** Getter and setter methods for the instance variables*/
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	public float getEmpCompensation() {
		return empCompensation;
	}
	public void setEmpCompensation(float empCompensation) {
		this.empCompensation = empCompensation;
	}
	
}
