package employee;

import java.util.Scanner;

/**
 * Class to store and retrieve the details of three employees
 * @author minerva.shrivastava
 *
 */
public class EmployeeTest {

	public static void main(String[] args) {
		
		/** Object of scanner class to take the input from the user*/
		Scanner sc = new Scanner(System.in);
		
		/** An array of Employee type to store the employee objects and their information*/
		Employee[] employee = new Employee[3];
		
		/** Loop for traversal through the array to take the information of employees*/
			for(int i = 0; i<3 ; i++)
			{
				System.out.println("\nEnter the data of employee");
				employee[i] = new Employee();
				System.out.println("Enter employee number");
				int empNo= sc.nextInt();
				employee[i].setEmpNo(empNo);
				System.out.println("Enter employee compensation");
				float empCompensation= sc.nextFloat();
				employee[i].setEmpCompensation(empCompensation);
			}
		
		/** Loop for traversal through the array to display the information of employees*/
			for(int i = 0; i<3 ; i++)
			{
				System.out.println("\nThe details of employee are");
				System.out.println("Employee number : "+employee[i].getEmpNo());
				System.out.println("Employee compensation : "+employee[i].getEmpCompensation());
			}
		
	}
}
