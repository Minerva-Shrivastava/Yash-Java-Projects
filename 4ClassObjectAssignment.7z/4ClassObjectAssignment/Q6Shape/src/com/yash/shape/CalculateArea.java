package com.yash.shape;

/**
 * Class to calculate the area of shapes 
 * @author minerva.shrivastava
 *
 */
public class CalculateArea {

	public static void main(String[] args) {
		
		CalculateArea area = new CalculateArea("Square", 10); 
		CalculateArea area1 = new CalculateArea("Rectangle", 10, 20); 
		CalculateArea area2 = new CalculateArea("Traingle", 10.0f, 50.0f); 
		
	}
	/**
	 * Constructor taking shape type, length and breadth 
	 * and calculate the area of rectangle
	 * @param shapeType
	 * @param length
	 * @param breadth
	 */
	public CalculateArea(String shapeType,int length, int breadth) {
		System.out.println("\nThe area of shape type :"+shapeType+" is");
		Rectangle rectangle = new Rectangle(length, breadth);
		float area = rectangle.calculateArea();
		System.out.println(area);
	}
	
	/**
	 * Constructor taking shape type, length 
	 * and calculate the area of square
	 * @param shapeType
	 * @param length
	 */
	public CalculateArea(String shapeType, int length) {
		System.out.println("\nThe area of shape type :"+shapeType+" is");
		Square square = new Square(length);
		float area = square.calculateArea();
		System.out.println(area);
	}
	
	/**
	 * Constructor taking shape type, length and height
	 * and calculate the area of triangle
	 * @param shapeType
	 * @param length
	 * @param height
	 */
	public CalculateArea(String shapeType, float length, float height) {
		System.out.println("\nThe area of shape type :"+shapeType+" is");
		Traingle traingle = new Traingle(length, height);
		float area = traingle.calculateArea();
		System.out.println(area);
	}
	
}
