package com.yash.shape;

/**
 * Parent class Shape 
 * @author minerva.shrivastava
 *
 */
public abstract class Shape {

	float length;
	float breadth;
	float height;
	float area;
	
	/**
	 * An abstract method calculateArea which returns a float type value
	 * This method must be defined in every subclass
	 * @return
	 */
	public abstract float calculateArea();
	
}
