package com.yash.shape;

public class Square extends Shape{

	/**
	 * Parameterized constructor taking length of type integer
	 * @param length
	 */
	public Square(int length) {
		this.length = length;
		this.area = this.length*this.length;
	}
	
	/** Method to calculate area of rectangle*/
	public float calculateArea() {
		this.area = this.length*this.length;
		return this.area;
	}
}
