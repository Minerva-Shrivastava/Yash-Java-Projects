package com.yash.shape;

public class Traingle extends Shape{
	/**
	 * Parameterized constructor taking length and breadth of type float
	 * @param length
	 * @param height
	 */
	public Traingle(float length, float height) {
		this.length = length;
		this.height = height;
	}
	
	/** Method to calculate area of rectangle*/
	public float calculateArea() {
		this.area = (this.length*this.height)/2;
		return this.area;
	}
	
}
