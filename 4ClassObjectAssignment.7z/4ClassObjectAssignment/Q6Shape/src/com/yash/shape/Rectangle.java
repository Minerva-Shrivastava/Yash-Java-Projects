package com.yash.shape;

/**
 * The subclass Rectangle which extends from parent class shape 
 * @author minerva.shrivastava
 *
 */
public class Rectangle extends Shape{

	/**
	 * Parameterized constructor taking length and breadth, both of type integer
	 * @param length
	 * @param breadth
	 */
	public Rectangle(int length, int breadth) {
		this.length = length;
		this.breadth = breadth;
		
	}
	
	/** Method to calculate area of rectangle*/
	public float calculateArea() {
		this.area = this.length*this.breadth;
		return this.area;
	}
	
}
