package com.yash.toolbooth;

import java.util.Scanner;

/**
 * Class is to examine the toolbooth class 
 * @author minerva.shrivastava
 *
 */
public class ToolBoothTest {

	public static void main(String[] args) {
		
		/**Object of scanner class to take input from the console screen*/
		Scanner sc = new Scanner(System.in);
		
		/**Variable to continue in the DoWhile loop*/
		String continueChoice;
		
		/**Loop which displays the menu repeatedly*/
		do
		{
			System.out.println("****Mneu****");
			System.out.println("1. Car payed");
			System.out.println("2. Car did not pay");
			System.out.println("3. ESC(to see total and exit)");
			
			/**Variable for Switch case*/
			char choice = sc.next().charAt(0);
			
			/**Switch to perform functionalities according to the menu above*/
			switch(choice)
			{
			case '1': ToolBooth toolbooth = new ToolBooth();
					toolbooth.payingCar();/**Calling the method if a car pays up*/
					break;
					
			case '2': ToolBooth toolbooth1 = new ToolBooth();
					toolbooth1.noPayCar();/**Calling the method if a car doesn't pay*/
					break;
					
			case '3'/*KeyEvent.VK_ESCAPE*/: System.out.println("\nPress ESC key to exit");/**Exit if ESC key is pressed*/
									 ToolBooth.display();
									 break;
			
			default : System.out.println("Invalid Entry");/**Any other option is invalid*/
			}
			
			System.out.println("Do you want to continue?yes/no");
			continueChoice = sc.next();
			
		}while(continueChoice.equalsIgnoreCase("yes"));
	}
}
