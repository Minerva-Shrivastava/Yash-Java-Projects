package com.yash.toolbooth;

/**
 * Class ToolBooth counts the total no of cars and the total money collected
 * when cars pass through the toolbooth 
 * @author minerva.shrivastava
 *
 */
public class ToolBooth {

	/**Static variables which are common for all objects */
	static private int totalCars;
	static private double moneyCollection;
	
	/*public ToolBooth() {
		totalCars = 0;
		moneyCollection = 0;
	}*/
	
	/**Method which increases the count of cars and money collection if the car pays */
	public void payingCar()
	{
		totalCars++;
		moneyCollection += 0.50;
	}
	
	/**Method which increases the car count only if car does not pay */
	public void noPayCar()
	{
		totalCars++;
	}
	
	/**Method which displays the total count of cars and the total money collected*/
	public static void display() 
	{
		System.out.println("\nTotal cars : "+totalCars);
		System.out.println("\ntotal cash : "+moneyCollection);
	}
}
