package com.yash.integer;

/**
 * Class is to exercise the Int class
 * @author minerva.shrivastava
 *
 */
public class IntTest {

	public static void main(String[] args) {
		
		/**One uninitialized variable */
		Int number1;
		Int sum = new Int();/**Sum variable is initialized to default value*/
		
		/**Variables initialized to int value*/
		Int number2 = new Int(50);
		Int number3 = new Int(100);
		
		/**Adding the two above numbers and their sum is returned into the above uninitialized variable*/
		number1 = sum.add(number2, number3);
		
		/**Displaying the int value of sum obtaned above*/
		System.out.println(number1.getValue());
	
	}
}
