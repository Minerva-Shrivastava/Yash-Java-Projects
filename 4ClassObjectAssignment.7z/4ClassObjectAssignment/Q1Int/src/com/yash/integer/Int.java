package com.yash.integer;

/**
 * Class imitates the functionality of the basic data type int 
 * @author minerva.shrivastava
 *
 */
public class Int {

	/**Has a variable of int type	 */
	private int value;
	
	
	/**Constructor to initialize the variable to default value zero*/
	public Int() {
		value = 0;
	}
	
	
	/**Constructor to initialize the variable to int value */
	public Int(int givenvalue)
	{
		value = givenvalue;
	}
	
	/**Method to set the variable to int value */
	public void setValue(int value) {
		this.value = value;
	}
	
	/**Method to get the variable's value */
	public int getValue() {
		return value;
	}

	/**Method to add two Int type numbers and return the value*/
	public Int add(Int number1, Int number2)
	{
		Int sum = new Int();
		sum.setValue(number1.value+number2.value);
		return sum;
	}
}
