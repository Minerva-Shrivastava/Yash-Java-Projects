package com.yash.joindate;

/** 
 * Class JoinDate to take a date from the user and display it
 * @author minerva.shrivastava
 *
 */
public class JoinDate {

	/** Instance variables for day, month and year*/
	int day;
	int month;
	int year;
	
	/** Method to take the input date from the user*/
	public void getDate(String date)
	{
		/** Splitting the input date by "/" symbol and the tokens are stored in an array*/
		String[] dateArray= date.split("/+");
		
		/** Getting the day, month and year from the array*/
		int givenDay = Integer.parseInt(dateArray[0]);
		int givenMonth = Integer.parseInt(dateArray[1]);
		int givenYear = Integer.parseInt(dateArray[2]);		
			
		/** validating the date*/
		for(int i=1; i<=12 ; i++) 
		{	
			if((givenMonth < 0 || givenMonth > 12) || (givenYear<=0))
			{	
				System.out.println("\nEnter a right date");
				break;
			}
			
			if(givenMonth == i)
			{
				if(i %2 == 0)
				{
					if(givenMonth == 2)
					{
						if(((((givenYear%4==0) && (givenYear%100!=0)) || (givenYear%400==0))))
						{
							if(givenDay <= 29 && givenDay>0)
								this.day = givenDay;
							else
							{
								System.out.println("\nIt's a leap year, enter the right day");
								break;
							}
						}
						else
							if(givenDay <= 28 && givenDay>0)
								this.day = givenDay;
							else
							{
								System.out.println("\nEnter a right date");
								break;
							}	
					}
					if(givenDay <= 30 && givenDay>0)
						this.day = givenDay;
					else
					{
						System.out.println("\nEnter the right date");
						break;
					}
				}
				else 
				{
					if(givenDay <= 31 && givenDay>0)
						this.day = givenDay;
					else
					{
						System.out.println("\nEnter a right date");
						break;
					}
				}
				
				this.month = givenMonth;
				this.year = givenYear;
			}
			
		}
		
	}
	
	/** Method to display the date*/
	public String showDate()
	{
		System.out.println(day+"/"+month+"/"+year);
		return null;
	}
	
}
