package com.yash.joindate;

import java.util.Scanner;

/**
 * Class to test the JoinDate class 
 * It tests whether the entered test is right or not
 * @author minerva.shrivastava
 *
 */
public class JoinDatemain {

	public static void main(String[] args) {
		
		/** Object of scanner class to take input from console screen */
		Scanner sc = new Scanner(System.in);
		
		/** Object of JoinDate class to access its methods*/
		JoinDate date = new JoinDate();
		
		/** User enter's the date*/
		System.out.println("\nEnter the date :");
		String givenDate = sc.next();
		
		/** Method to take the date and verify it*/
		date.getDate(givenDate);
		
		/** Method to display the date, user entered*/
		System.out.println("\nYou entered :");
		date.showDate();
	}
	
}
