package com.yash.time;

/**
 * This class tests the Time class 
 * @author minerva.shrivastava
 *
 */
public class TimeTest {

	public static void main(String[] args) {
		
		/**Uninitialized object of Time class */
		Time time;
		
		/**Initialized objects of Time class */
		Time sum = new Time();
		Time time1 = new Time(2,20,30);
		Time time2 = new Time(5,50,40);
		
		/**Calling the method add, which adds two given times*/
		time = sum.addTime(time1, time2);
		
		/**The resultant time after addition*/
		System.out.println(time);
	}
}
