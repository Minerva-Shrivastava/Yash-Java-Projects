package com.yash.time;

/**
 * The Time class is for objects having  hour, minute and seconds
 * @author minerva.shrivastava
 *
 */
public class Time {

	/**Three instance variables	 */
	private int hours;
	private int minutes;
	private int seconds;
	
	/**Constructor to initialize the variables to default values */
	public Time() {
		hours = 0;
		minutes = 0;
		seconds = 0;
	}
	
	/**Constructor to initialize the variables to given values */
	public Time(int hours, int minutes, int seconds)
	{
		this.hours = hours;
		this.minutes = minutes;
		this.seconds = seconds;
	}
	
	/**Method to display the time in a specific format*/
	public void displayInFormat()
	{
		System.out.println(hours+":"+minutes+":"+seconds);
	}
	
	/**Method to add two given times and return the result */
	public Time addTime(Time time1, Time time2)
	{
		Time newTime = new Time();
		int sumSeconds = time1.seconds+time2.seconds ;
		if(sumSeconds>60) /**Adding the seconds, if greater than 60, a minute increases*/
		{
			while(sumSeconds>60)
			{
				newTime.minutes++;
				sumSeconds -= 60;
				newTime.seconds=sumSeconds;
			}
		}
		else
		{
			newTime.seconds = time1.seconds + time2.seconds;
		}
		
		int sumMinutes = time1.minutes+time2.minutes;
		if(sumMinutes>60)/**Adding the minutes, if greater than 60, an hour increases*/
		{
			while(sumMinutes>60)
			{
				newTime.hours++;
				sumMinutes -= 60;
				newTime.minutes += sumMinutes;
			}
		}
		else
		{	
			newTime.minutes += time1.minutes+time2.minutes;
		}
		
		newTime.hours += time1.hours+time2.hours;
		
		return newTime;
	}
	
	/**Override the toString method to display the instance variables in a specific format*/
	@Override
	public String toString() {
		
		return "\nTime : "+this.hours+":"+this.minutes+":"+this.seconds;
	}
	
}
