package com.yash.jdbc.serviceimpl;

import java.util.Set;
import com.yash.jdbc.dao.CoursesDao;
import com.yash.jdbc.daoimpl.CoursesDaoImpl;
import com.yash.jdbc.modal.Course;
import com.yash.jdbc.service.TraineeService;

public class TraineeServiceImpl implements TraineeService{

	CoursesDao courseDB = new CoursesDaoImpl();
	
	@Override
	public void listCourses() {
		
		Set<Course> listCourses = courseDB.listCourses();
		for (Course course : listCourses) {
			System.out.println(course);
		}
		
		
	}
	
	
}
