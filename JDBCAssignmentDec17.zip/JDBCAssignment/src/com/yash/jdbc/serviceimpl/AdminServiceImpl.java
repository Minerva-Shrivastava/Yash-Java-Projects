package com.yash.jdbc.serviceimpl;

import java.util.Iterator;
import java.util.Set;

import com.yash.jdbc.dao.UserDao;
import com.yash.jdbc.daoimpl.UserDaoImpl;
import com.yash.jdbc.modal.User;
import com.yash.jdbc.service.AdminService;

public class AdminServiceImpl implements AdminService{

	UserDao userDB = new UserDaoImpl();
	
	@Override
	public void listUsers() {
		
		Set<User> userSet = userDB.getAllUsers();
		Iterator<User> it = userSet.iterator();
		while (it.hasNext()) {
			User user = (User) it.next();
			System.out.println(user);
		}
		
	}
	
	@Override
	public void changeStatus(int id, String changeStatus) {
		
		User user = userDB.getUserById(id);
		user.setStatus(changeStatus);
		boolean statusChanged = userDB.updateUser(user);
		if(statusChanged == true)
			System.out.println("User data is updated");
		else
			System.out.println("User data is not updated");
	}


	@Override
	public void changeRole(int id1, String changeRole) {
		
		User user = userDB.getUserById(id1);
		user.setRole(changeRole);
		boolean statusChanged = userDB.updateUser(user);
		if(statusChanged == true)
			System.out.println("User data is updated");
		else
			System.out.println("User data is not updated");
		
	}

	@Override
	public void updateUser(User updateUser) {
		
		boolean userUpdated = userDB.updateUser(updateUser);
		if(userUpdated == true)
			System.out.println("User data is updated");
		else
			System.out.println("User data is not updated");
	}
	
	@Override
	public void deleteUsers(int id) {
		boolean userDeleted = userDB.deleteUser(id);
		if(userDeleted == true)
			System.out.println("Record of user id "+id+ " is deleted");
		else 
			System.out.println("Record of user id "+id+ " is not deleted");
		
	}

	@Override
	public void listCourses() {
		// TODO Auto-generated method stub
		
	}


	
	
}
