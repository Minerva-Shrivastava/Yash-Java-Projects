package com.yash.jdbc.dao;

import java.util.Set;

import com.yash.jdbc.modal.User;

public interface UserDao {

	Set<User> getAllUsers();
	User getUserById(Integer id);
	User getUserByUserNameAndpassword(String userName, String password);
	boolean insertUser(User newUser);
	boolean updateUser(User user);
	boolean deleteUser(int id);
	Set<User> listTrainees();
		
}

