package com.yash.jdbc.dao;

import java.util.Set;

import com.yash.jdbc.modal.Course;

public interface CoursesDao {

	boolean addCourse(Course course);

	boolean updateCourse(Course updateCourse);

	boolean deleteCourse(int deleteId);

	Set<Course> listCourses();

	
}
