package com.yash.jdbc.service;

import com.yash.jdbc.modal.Course;

public interface TrainerService {

	void listTrainees();

	void addCourse(Course course);

	void updateCourse(Course updateCourse);

	void deleteCourse(int deleteId);

	void listCourses();

}
