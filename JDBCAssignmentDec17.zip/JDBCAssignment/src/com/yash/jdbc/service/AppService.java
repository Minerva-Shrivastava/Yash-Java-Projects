package com.yash.jdbc.service;

import com.yash.jdbc.modal.User;

public interface AppService {

	void userRegistration(User newUser);

	void userLogin(String userName, String password);

	
}
