package com.yash.jdbc.service;

public interface TraineeService {

	void listCourses();

	
}
