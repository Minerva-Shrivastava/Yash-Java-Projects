package com.yash.jdbc.modal;

import java.sql.Date;

import com.yash.jdbc.enumeration.UserRoleEnum;
import com.yash.jdbc.enumeration.UserStatusEnum;

public class User {

	private Integer id;
	private String firstName;
	private String lastName;
	private String email;
	private String contact;
	private UserStatusEnum status = UserStatusEnum.PENDING;
	private UserRoleEnum role = UserRoleEnum.TRAINEE;
	private String userName;
	private String password;
	private Date createdDate;
	private Date modifiedDate;
	
	
	public User() {
		
	}
	
	public User(Integer id, String firstName, String lastName, String email, String contact, UserStatusEnum status,
			UserRoleEnum role, String userName, String password) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.contact = contact;
		this.status = status;
		this.role = role;
		this.userName = userName;
		this.password = password;
	}
	
	
	public User(String firstName, String lastName, String email, String contact, UserStatusEnum status,
			UserRoleEnum role, String userName, String password) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.contact = contact;
		this.status = status;
		this.role = role;
		this.userName = userName;
		this.password = password;
	}

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	
	
	public UserStatusEnum getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		
		if(status.equalsIgnoreCase("active"))
			this.status = UserStatusEnum.ACTIVE;
		if(status.equalsIgnoreCase("pending"))
			this.status = UserStatusEnum.PENDING;
		if(status.equalsIgnoreCase("inactive"))
			this.status = UserStatusEnum.INACTIVE;
		if(status.equalsIgnoreCase("deleted"))
			this.status = UserStatusEnum.DELETED;
		
	}
	public UserRoleEnum getRole() {
		return role;
	}
	public void setRole(String role) {
		
		if(role.equalsIgnoreCase("admin"))
			this.role = UserRoleEnum.ADMIN;
		if(role.equalsIgnoreCase("trainer"))
			this.role = UserRoleEnum.TRAINER;
		if(role.equalsIgnoreCase("trainee"))
			this.role = UserRoleEnum.TRAINEE;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	@Override
	public String toString() {
		
		return "[ ID:"+this.getId()
			 +" \tname:"+this.getFirstName()+" "+this.getLastName()
			 +" \temail:"+this.getEmail()
			 +" \tcontact:"+this.getContact()
			 +" \tstatus:"+this.getStatus()
			 +" \trole:"+this.getRole()
			 +" \tuser name:"+this.getUserName()
			 +" \tpassword:"+this.getPassword()
			 +" \tcreated date:"+this.getCreatedDate()
			 +" \tmodified date:"+this.getModifiedDate()
			 +" ]";
	}
	
}
