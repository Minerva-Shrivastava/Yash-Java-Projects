package com.yash.jdbc.utilities;

import java.util.Scanner;

import com.yash.jdbc.service.TraineeService;
import com.yash.jdbc.serviceimpl.TraineeServiceImpl;

public class TraineeMenu {

	public static void displayMenu()
	{
		Scanner sc = new Scanner(System.in);
		TraineeService traineeService= new TraineeServiceImpl();
		String continueChoice ;
		
		do {
			System.out.println("******Trainee Menu******");
			System.out.println(" 1. List all courses");
			
			int choice = sc.nextInt();
			
			switch (choice) {
			case 1:
					traineeService.listCourses();			
				break;

			default:System.out.println("Invalid option");
					sc.close();
					System.exit(0);
				break;
			}
			
			System.out.println("Do you want to continue?yes/no");
			continueChoice = sc.next();
			if(continueChoice.equalsIgnoreCase("no"))
				System.out.println("Going back to main menu");
		}while(continueChoice.equalsIgnoreCase("yes"));
		
	}
}
