package com.yash.jdbc.utilities;

import java.util.Scanner;

import com.yash.jdbc.modal.Course;
import com.yash.jdbc.service.TrainerService;
import com.yash.jdbc.serviceimpl.TrainerServiceImpl;

public class TrainerMenu {

	
	public static void displayMenu()
	{
		Scanner sc = new Scanner(System.in);
		TrainerService trainerService = new TrainerServiceImpl();
		String continueChoice ;
		
		do {
			System.out.println("******Trainer Menu******");
			System.out.println(" 1. List all trainees"
					  + "\n 2. Add course"
					  + "\n 3. Update course"
					  + "\n 4. Delete course"
					  + "\n 5. List all courses");
			
			int choice = sc.nextInt();
			
			switch (choice) {
			case 1:
					trainerService.listTrainees();			
				break;
			
			case 2:
				Course course = new Course();
				System.out.println("Enter course name");
				sc.nextLine();
				String name = sc.nextLine();
				course.setName(name);
				System.out.println("Enter user's id learning this course");
				int user_id = sc.nextInt();
				course.setUser_id(user_id);
				trainerService.addCourse(course);			
			break;
			
			case 3:
				Course updateCourse = new Course();
				System.out.println("Enter course id");
				int id = sc.nextInt();
				updateCourse.setId(id);
				System.out.println("Enter course name");
				sc.nextLine();
				String updateName = sc.nextLine();
				updateCourse.setName(updateName);
				System.out.println("Enter user's id learning this course");
				int updateUser_id = sc.nextInt();
				updateCourse.setUser_id(updateUser_id);
				trainerService.updateCourse(updateCourse);			
			break;

			case 4:
				System.out.println("Enter course id");
				int deleteId = sc.nextInt();
				trainerService.deleteCourse(deleteId);			
			break;
			
			case 5:
				trainerService.listCourses();			
			break;
			
			default:System.out.println("Invalid option");
					sc.close();
					System.exit(0);
				break;
			}
			
			System.out.println("Do you want to continue?yes/no");
			continueChoice = sc.next();
			if(continueChoice.equalsIgnoreCase("no"));
				System.out.println("Going back to main menu");
		}while(continueChoice.equalsIgnoreCase("yes"));
		
	}
}
