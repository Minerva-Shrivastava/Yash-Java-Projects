package com.yash.jdbc.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashSet;
import java.util.Set;

import com.yash.jdbc.connection_factory.DBConnection;
import com.yash.jdbc.dao.CoursesDao;
import com.yash.jdbc.modal.Course;

public class CoursesDaoImpl implements CoursesDao{

	private Connection con = DBConnection.getConnection();
	private PreparedStatement pstmt ;
	
	@Override
	public boolean addCourse(Course course) {
		
		String addCourseSql = "INSERT INTO courses (user_id, course_name) VALUES(?,?)";
		try {
			pstmt = con.prepareStatement(addCourseSql);
			
			pstmt.setInt(1, course.getUser_id());
			pstmt.setString(2, course.getName());
			int execute = pstmt.executeUpdate();
			if(execute > 0) {
				//System.out.println("Course added");
				return true;
			}
			else {
				//System.out.println("Course not added");
				return false;
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
			return false;
		}
		
	}

	@Override
	public boolean updateCourse(Course updateCourse) {
		
		String updateCourseSql = "UPDATE courses SET user_id = '"+updateCourse.getUser_id()+"'"
						+ ",course_name = '"+updateCourse.getName()+"' ;";
		try {
			pstmt = con.prepareStatement(updateCourseSql);
			int execute = pstmt.executeUpdate();
			if(execute > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
			return false;
		}
		
	}

	@Override
	public boolean deleteCourse(int deleteId) {
		
		String deleteCourseSql = "DELETE FROM courses WHERE id = '"+deleteId+"' ;";
		try {
			pstmt = con.prepareStatement(deleteCourseSql);
			int execute = pstmt.executeUpdate();
			if(execute > 0)
				return true;
			else
				return false;
		} catch (SQLException e) {
			
			e.printStackTrace();
			return false;
		}
	
	}

	@Override
	public Set<Course> listCourses() {
		
		Set<Course> courseList = new LinkedHashSet<Course>();
		String allCoursesSql = "SELECT * FROM courses ;";
		try {
			pstmt = con.prepareStatement(allCoursesSql);
			ResultSet result = pstmt.executeQuery();
			
			while(result.next())
			{
				Course course = extractCourseFromResultSet(result);
				courseList.add(course);
			}
			return courseList;
		} catch (SQLException e) {
			
			e.printStackTrace();
			return null;
		}
		
	}

	private Course extractCourseFromResultSet(ResultSet result) throws SQLException {
		
			Course course = new Course();
			course.setId(result.getInt("id"));
			course.setUser_id(result.getInt("user_id"));
			course.setName(result.getString("course_name"));
			return course;
		}
	}

