package com.yash.loginapp.userController;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.loginapp.service.userService;
import com.yash.loginapp.service.userServiceImpl;


public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	userService service = new userServiceImpl();
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		PrintWriter out = resp.getWriter();
		resp.setContentType("text/html");
		
		HttpSession session = req.getSession(true);
		
		String email = req.getParameter("email");
		String pwd = req.getParameter("pwd");
		session.setAttribute("uname", email);
		
		boolean authenticate = service.authenticateUser(email, pwd);
		if(authenticate == true) {
			out.println("Welcome");
		RequestDispatcher rd = req.getRequestDispatcher("UserDashboard");
		rd.forward(req, resp);
		}
		else {
			
			RequestDispatcher rd = req.getRequestDispatcher("/Login.html");
			String fileName = getServletContext().getInitParameter("messages");
			Properties prop = new Properties();
			prop.load(getClass().getClassLoader().getResourceAsStream(fileName));
			String failureMsg = prop.getProperty("Login_error");
			out.println(failureMsg);
			rd.include(req, resp);
		}
	}
    
}
