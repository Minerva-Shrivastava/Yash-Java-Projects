package com.yash.loginapp.userController;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UserDashboard
 */
public class UserDashboard extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		String fileName = getServletContext().getInitParameter("messages");
		Properties prop = new Properties();
		prop.load(getClass().getClassLoader().getResourceAsStream(fileName));
		String successMsg = prop.getProperty("Login_successful");
		
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("<head><title>Dashboard Page</title></head>");
		out.println("<body>");
		out.println("<center>");
		out.println("<fieldset style='width: 700px'>");
		out.println("<legend>User Dashboard</legend>");
		out.println("Welcome "+request.getParameter("email"));
		out.println("<form action = 'Logout' method='post'>");
		out.println("<table>");
		out.println("<tr>"+ successMsg);
		out.println("<tr>"
				+ "<td colspan='2' style='text-align: right;'><input type='submit' value='Logout'></td>"
				+"</tr>");
		
	}

}
