package com.yash.userController;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.service.userService;
import com.yash.service.userServiceImpl;


public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	userService service = new userServiceImpl();
       @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    		throws ServletException, IOException {
    	   response.setContentType("text/html");
   		PrintWriter out = response.getWriter();
   		out.println("<!DOCTYPE html>");
   		out.println("<html>");
   		out.println("<head><title>Login Page</title></head>");
   		out.println("<body>");
   		out.println("<center>");
   		out.println("<fieldset style='width: 700px'>");
   		out.println("<legend>Login</legend>");
   		out.println("<form action = 'UserController' method='post'>");
   		out.println("<table>");
   		out.println("<tr>"
   				+ "<td>email id </td>"
   				+ "<td><input type='text' name='email'></td>"
   				+ "</tr>");
   		out.println("<tr>"
   				+ "<td>password</td>"
   				+ "<td><input type='text' name='pwd'></td>"
   				+"</tr>");
   		out.println("<tr>"
   				+ "<td colspan='2' style='text-align: right;'><input type='submit' value='Add'></td>"
   				+"</tr>");
   		out.println("<tr>"
   				+ "<td colspan='2'></td>"
   				+"</tr>");
    }
    
	
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter out = resp.getWriter();
		String email = req.getParameter("email");
		String pwd = req.getParameter("pwd");
		boolean authenticate = service.authenticateUser(email, pwd);
		if(authenticate == true) {
			out.println("Welcome");
		RequestDispatcher rd = req.getRequestDispatcher("UserDashboard");
		rd.forward(req, resp);
		}
		else {
			
			RequestDispatcher rd = req.getRequestDispatcher("UserController");
			out.println("Wrong input");
			rd.forward(req, resp);	
		}
			
		super.doPost(req, resp);
	}

}
