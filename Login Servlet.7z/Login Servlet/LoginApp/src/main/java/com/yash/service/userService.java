package com.yash.service;

import com.yash.modal.userCommand;

public interface userService {

	public boolean authenticateUser(String emailId, String pwd);
}
