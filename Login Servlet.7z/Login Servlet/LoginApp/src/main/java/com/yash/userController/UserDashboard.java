package com.yash.userController;

import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UserDashboard
 */
public class UserDashboard extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserDashboard() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		String value = getServletContext().getInitParameter("massage");
		Properties prop = new Properties();
		prop.load(getClass().getClassLoader().getResourceAsStream(value));
		String successMsg = prop.getProperty("Login_successful");
		
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("<head><title>Dashboard Page</title></head>");
		out.println("<body>");
		out.println("<center>");
		out.println("<fieldset style='width: 700px'>");
		out.println("<legend>User Dashboard</legend>");
		out.println("Welcome "+request.getParameter("email"));
		out.println("<form action = 'UserController'>");
		out.println("<table>");
		out.println("<tr>"+ successMsg);
		out.println("<tr>"
				+ "<td colspan='2' style='text-align: right;'><input type='submit' value='Logout'></td>"
				+"</tr>");
	}

}
