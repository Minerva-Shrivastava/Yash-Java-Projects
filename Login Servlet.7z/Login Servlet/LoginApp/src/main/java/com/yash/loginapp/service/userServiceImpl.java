package com.yash.loginapp.service;

import java.util.LinkedList;
import java.util.List;

import com.yash.loginapp.modal.userCommand;

public class userServiceImpl implements userService{

	private List<userCommand> userRepository = new LinkedList<userCommand>();
	userCommand user = new userCommand("a@gmail.com","123");
	userCommand user1 = new userCommand("b@gmail.com","123");
	userCommand user2 = new userCommand("c@gmail.com","123");
	
	public boolean authenticateUser(String emailId, String pwd)
	{
		userRepository.add(user);
		userRepository.add(user1);
		userRepository.add(user2);
		
		for (userCommand user : userRepository) {
			if(emailId.equals(user.getEmailId()) && pwd.equals(user.getPassword()))
			{
				return true;
			}
		}
		return false;
	}
}
