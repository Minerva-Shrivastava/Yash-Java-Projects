package com.yash.loginapp.service;

public interface userService {

	public boolean authenticateUser(String emailId, String pwd);
}
