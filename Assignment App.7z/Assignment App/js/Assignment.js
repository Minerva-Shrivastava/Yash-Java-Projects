var assignmentList={
    
    //assignments array
    assignments:[],
    
    //Add assignments
    addAssignment:function(assignmentText)
    {
        this.assignments.push({
            assignmentText:assignmentText,
            completed:false
        });
    
    },
    
    //Edit assignments
    editAssignment:function(position,newAssignmentText)
    {
        this.assignments[position].assignmentText = newAssignmentText;
    
    },

    //Delete assignments
    deleteAssignment:function(position)
    {
        this.assignments.splice(position,1);
    
    },
    
    //Toggle Assignment status
    toggleCompleted:function(position)
    {
        var assignment = this.assignments[position];
        assignment.completed = ! assignment.completed;
    
    },
    
    //Toggle all the assignments
    toggleAll:function(){
        var totalCompleted = this.assignments.length;
        var countCompleted = 0;
        
        for(var i=0;i<this.assignments.length;i++){
                if(this.assignments[i].completed===true)
                    countCompleted++;
            }
        
        
        for(var j=0;j<this.assignments.length;j++){
                if(countCompleted===totalCompleted){
                        this.assignments[j].completed=false;
                } else {
                        this.assignments[j].completed=true;
                    }
        }
    
    }
};
var handlers = {
    
    toggleAll:function(){
        assignmentList.toggleAll();
		view.displayAssignments();
    },
    addAssignment:function(key){
		if(key.keyCode === 13){
			
			var assignmentTextInput = document.getElementById('assignmentTextInput');
			assignmentList.addAssignment(assignmentTextInput.value);
			assignmentTextInput.value='';
			view.displayAssignments();	
			
		}
    },
    editAssignment:function(){
		
        var editAssignmentPosition = document.getElementById('editAssignmentPosition');
        var editAssignmentText = document.getElementById('editAssignmentText');
        assignmentList.editAssignment(editAssignmentPosition.valueAsNumber,editAssignmentText.value);
        editAssignmentPosition.value='';
        editAssignmentText.value='';
		view.displayAssignments();
		
    },
    deleteAssignment:function(deleteAssignmentPosition){
		
        var deleteAssignmentPosition = document.getElementById(deleteAssignmentPosition);
        assignmentList.deleteAssignment(deleteAssignmentPosition.valueAsNumber);
        deleteAssignmentPosition.value='';
		view.displayAssignments();
		
    },
    toggleCompleted:function(toggleAssignmentPosition){
		
        var toggleAssignmentPosition = document.getElementById(toggleAssignmentPosition);
        assignmentList.toggleCompleted(toggleAssignmentPosition.valueAsNumber);
        toggleAssignmentPosition.value='';
		view.displayAssignments();
		
    }    
};

var view = {
    
    displayAssignments:function(){
        var assignmentUl = document.querySelector('ul');
            assignmentUl.innerHTML='';

		
        for(var i=0; i<assignmentList.assignments.length;i++)        {
			var assignmentLi = document.createElement('li');
            var checkBox = this.createCheckBoxButton();
			var assignment = assignmentList.assignments[i];
			console.log(assignmentList.assignments[i]);
            if(assignment.completed === true)            {
                var assignmentTexteWithCompletion = '(X)'+assignment.assignmentText;
				assignmentLi.className="checkedToggle";
				checkBox.setAttribute("checked",true);
            } else {
                assignmentTexteWithCompletion = assignment.assignmentText;
			assignmentLi.className="unCheckedTogle";
			checkBox.setAttribute("unchecked",true);
			}
			
			
            assignmentLi.textContent = assignmentTexteWithCompletion;
			assignmentUl.appendChild(assignmentLi);
			assignmentLi.appendChild(checkBox);
			
			assignmentLi.id = i;
			
			assignmentLi.appendChild(this.createDeleteButton());
        }
    },
	
	createDeleteButton(){
		var deleteButton = document.createElement('button');
		deleteButton.textContent='X';
		deleteButton.className='deleteButtonClass';
		return deleteButton;
	},
	
	createCheckBoxButton(){
		var checkBox = document.createElement('input');
		checkBox.type = "checkBox";
		checkBox.className='checkBoxClass';
		return checkBox;
	}
};

var deleteAssignmentUl=document.querySelector('ul');
deleteAssignmentUl.addEventListener('click', function(event){
         var deleteEvent = event.target;
		if(deleteEvent.className==='deleteButtonClass'){
			handlers.deleteAssignment(parseInt(event.target.parentNode.id))
		}
});
									
var checkBoxUl=document.querySelector('ul');
checkBoxUl.addEventListener('change',function(event){
	var checkBoxEvent= event.target;
	if(checkBoxEvent.className==='checkBoxClass')		{
			handlers.toggleCompleted(parseInt(event.target.parentNode.id));
		}
})
									
									
									
									
									
									
									
									
									
									