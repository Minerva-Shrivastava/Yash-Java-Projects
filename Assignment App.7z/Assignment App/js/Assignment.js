var assignmentList={
    
    //assignments array
    assignments:[],
    
    //Add assignments
    addAssignment:function(assignmentText)
    {
        this.assignments.push({
            assignmentText:assignmentText,
            completed:false
        });
    
    },
    
    //Edit assignments
    editAssignment:function(position,newAssignmentText)
    {
        this.assignments[position].assignmentText = newAssignmentText;
    
    },

    //Delete assignments
    deleteAssignment:function(position)
    {
        this.assignments.splice(position,1);
    
    },
    
    //Toggle Assignment status
    toggleCompleted:function(position)
    {
        var assignment = this.assignments[position];
        assignment.completed = ! assignment.completed;
    
    },
    
    //Toggle all the assignments
    toggleAll:function()
    {
        var totalCompleted = this.assignments.length;
        var countCompleted = 0;
        
        for(var i=0;i<this.assignments.length;i++)
            {
                if(this.assignments[i].completed===true)
                    countCompleted++;
            }
        
        
        for(var j=0;j<this.assignments.length;j++)
            {
                if(countCompleted===totalCompleted)
                    {
                        this.assignments[j].completed=false;
                    }
                else
                    {
                        this.assignments[j].completed=true;
                    }
        }
    
    }
};
var handlers = {
    
    toggleAll:function(){
        assignmentList.toggleAll();
		view.displayAssignments();
    },
    addAssignment:function(key){
		if(key.keyCode === 13){
			var assignmentTextInput = document.getElementById('assignmentTextInput');
			assignmentList.addAssignment(assignmentTextInput.value);
			assignmentTextInput.value='';
			view.displayAssignments();	
		}
    }
    /*editAssignment:function(){
        var editAssignmentPosition = document.getElementById('editAssignmentPosition');
        var editAssignmentText = document.getElementById('editAssignmentText');
        assignmentList.editAssignment(editAssignmentPosition.valueAsNumber,editAssignmentText.value);
        editAssignmentPosition.value='';
        editAssignmentText.value='';
		view.displayAssignments();
    },
    deleteAssignment:function(){
        var deleteAssignmentPosition = document.getElementById('deleteAssignmentPosition');
        assignmentList.deleteAssignment(deleteAssignmentPosition.valueAsNumber);
        deleteAssignmentPosition.value='';
		view.displayAssignments();
    },
    toggleCompleted:function(){
        var toggleAssignmentPosition = document.getElementById('toggleAssignmentPosition');
        assignmentList.toggleCompleted(toggleAssignmentPosition.valueAsNumber);
        toggleAssignmentPosition.value='';
		view.displayAssignments();
    }*/    
};

var view = {
    
    displayAssignments:function(){
        var assignmentUl = document.querySelector('ul');
            assignmentUl.innerHTML='';

        for(var i=0; i<assignmentList.assignments.length;i++)
        {
            var assignment = assignmentList.assignments[i];
            if(assignment.completed === true)
            {
                var assignmentTexteWithCompletion ="(X)"+ assignment.assignmentText;
            }
            else
                assignmentTexteWithCompletion = "( )"+assignment.assignmentText;
			
			var label = document.createElement('label');
			var input = document.createElement('input');
			input.setAttribute("type","checkbox");
			label.appendChild(input);
            var assignmentLi = document.createElement('li');
            assignmentLi.textContent = assignmentTexteWithCompletion;
			
            assignmentUl.appendChild(assignmentLi);
        }
    }
};
