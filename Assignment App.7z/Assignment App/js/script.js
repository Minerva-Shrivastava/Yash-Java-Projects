var assignmentList={
    
    //assignments array
    assignments:['Assignment 1','Assginement 2'],
    
    //Display assigments
    displayAssignments:function(){
        console.log('My Assignments : ',this.assignments);
    },
    
    //Add assignments
    addAssignment:function(assignment)
    {
        this.assignments.push(assignment);
        this.displayAssignments();
    },
    
    //Edit assignments
    editAssignment:function(position,newAssignment)
    {
        this.assignments[position]=newAssignment;
        this.displayAssignments();
    },

    //Delete assignments
    deleteAssignment:function(position)
    {
        this.assignments.splice(position,1);
        this.displayAssignments();
    }
    
};