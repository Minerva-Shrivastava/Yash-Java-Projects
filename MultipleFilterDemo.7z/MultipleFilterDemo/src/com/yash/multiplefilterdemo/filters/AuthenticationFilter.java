package com.yash.multiplefilterdemo.filters;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class AuthenticationFilter implements Filter {

	public void init(FilterConfig fConfig) throws ServletException {
			
		System.out.println("************");
		System.out.println("Auth filter init method of Auth. filter called in : "
				+ this.getClass().getName());
		System.out.println("************");
		
	}
	
	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		System.out.println("************");
		System.out.println("do filter method of Auth. filter called in : "
				+ this.getClass().getName());
		
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse resp = (HttpServletResponse) response;
		
		String userName = req.getParameter("name");
		String password = req.getParameter("pwd");

		if((userName.equalsIgnoreCase("Admin") && password.equalsIgnoreCase("123")))
		{
			chain.doFilter(req, resp);
		}
		else
			resp.sendRedirect("Login.html");
	}

	@Override
	public void destroy() {
		
		System.out.println("************");
		System.out.println("Auth filter destroy method of Auth. filter called in : "
				+ this.getClass().getName());
		System.out.println("************");
		
	}

	

}
