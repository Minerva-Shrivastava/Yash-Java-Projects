package com.yash.DAO;

import java.util.List;
import com.yash.modal.Course;

public interface CourseDAO {

	List<Course> getAllCourses();
}
