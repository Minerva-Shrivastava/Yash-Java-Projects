package com.yash.DAO;

import java.util.List;
import com.yash.modal.Course;

public interface CourseDAO {

	List<String> getAllCourses();

	List<String> getAllMainTitles(String course);

	
}
