package com.yash.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*import com.yash.service.cmsService;
import com.yash.serviceimpl.cmsServiceImpl;*/

/**
 * Servlet implementation class AddSubtitleServlet
 */
public class AddSubtitleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/HTML");
		//service.addCourseList();
		PrintWriter out = response.getWriter();
		out.println("On Servlet<br>");
		RequestDispatcher rd = request.getRequestDispatcher("AddSubTitle.html");
		rd.include(request, response);
		
	}

}
