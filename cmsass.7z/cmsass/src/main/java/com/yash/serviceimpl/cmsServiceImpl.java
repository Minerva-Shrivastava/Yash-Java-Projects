package com.yash.serviceimpl;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import com.yash.DAO.CourseDAO;
import com.yash.DAOImpl.CourseDAOImpl;
import com.yash.service.cmsService;

public class cmsServiceImpl implements cmsService{

	private CourseDAO courseDB = new CourseDAOImpl();

	public List<String> getAllMaintitle(String course) {
		return courseDB.getAllMainTitles(course);
	}

	public List<String> getAllCourses() {
		return courseDB.getAllCourses();
	}

	public LinkedHashMap<String, List<String>> getMainTitleFromCourse() {
		LinkedHashMap<String, List<String>> course_MainTitleList = new LinkedHashMap<String, List<String>>();
		List<String> allCourses = getAllCourses();
		for (String courseName : allCourses) {
			course_MainTitleList.put(courseName, getAllMaintitle(courseName));
		}
 		return course_MainTitleList;
	}
	
	

}
