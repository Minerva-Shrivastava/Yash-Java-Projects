package com.yash.serviceimpl;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.List;

import com.yash.DAO.CourseDAO;
import com.yash.DAOImpl.CourseDAOImpl;
import com.yash.service.cmsService;

public class cmsServiceImpl implements cmsService{

	CourseDAO courseDB = new CourseDAOImpl();
	
	public void addCourseList() {
		
	List<String > courseList = courseDB.getAllCourses();
	File addSubTitle = new File("AddSubTitle.html");
	try {
		PrintWriter writer = new PrintWriter(addSubTitle);
		/*public static void aMethod(){
		    RandomAccessFile f = new RandomAccessFile(new File("whereDidIPutTHatFile"), "rw");
		    long aPositionWhereIWantToGo = 99;
		    f.seek(aPositionWhereIWantToGo); // this basically reads n bytes in the file
		    f.write("Im in teh fil, writn bites".getBytes());
		    f.close();
		}*/
		
	} catch (FileNotFoundException e) {
		e.printStackTrace();
	}
	
	
		
	}

}
