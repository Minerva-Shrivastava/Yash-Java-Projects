package com.yash.service;

public interface cmsService {

	void addCourseList();

}
