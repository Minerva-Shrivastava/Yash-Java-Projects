package com.yash.cms.enumeration;

public enum UserRoleEnum {

	ADMIN("Admin"),TRAINER("Trainer"),TRAINEE("Trainee");
	
	/**
	 * variable value and constructor
	 */
	private String value;
	private UserRoleEnum(String value) {
		this.value = value;
	}
	
	/**
	 * Getter method for value 
	 * @return value
	 */
	public String getValue() {
		return value;
	}
}
