package com.yash.cms.DAOImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashSet;
import java.util.Set;
import com.yash.cms.DAO.UsersDAO;
import com.yash.cms.dbutil.DBUtil;
import com.yash.cms.modal.User;

public class UsersDAOImpl implements UsersDAO{
	
	Connection con = DBUtil.getConnection();
	PreparedStatement pstmt;
	private long time = System.currentTimeMillis();
	private java.sql.Date date = new java.sql.Date(time);
	
		public User getUserById(Integer id) {
			
			String sql =  "select * from userDetails where id = '"+id+"'";
			try {
				pstmt = con.prepareStatement(sql);
				ResultSet result = pstmt.executeQuery();
				if(result.next())
				{
					
					return extractUserFromResultSet(result);
					
				}
				else
					System.out.println("User not found");
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return null;
		}

		
		public User getUserByUserNameAndpassword(String userName, String password) {
			
			String loginsql =  "select * from userDetails where userName = '"+userName+"' AND password = '"+password+"';";
			//System.out.println(loginsql);
			try {
				pstmt = con.prepareStatement(loginsql);
				ResultSet result = pstmt.executeQuery();
				if(result.next())
				{
					
					return extractUserFromResultSet(result);
					
				}
				/*else
					System.out.println("User not found");*/
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return null;
		}


		private User extractUserFromResultSet(ResultSet result) {
			User user = new User();
			
			try {
				user.setId(result.getInt("id"));
				user.setFirstName(result.getString("firstName"));
				user.setLastName(result.getString("lastName"));
				user.setEmail(result.getString("email"));
				user.setContact(result.getString("contact"));
				user.setStatus(result.getString("status"));
				user.setRole(result.getString("role"));
				user.setUserName(result.getString("userName"));
				user.setPassword(result.getString("password"));
				user.setCreatedDate(result.getDate("createdDate"));
				user.setModifiedDate(result.getDate("modifiedDate"));
				
				return user;
			} catch (SQLException e) {
				
				e.printStackTrace();
				return null;
			}
		}

		
		public boolean insertUser(User newUser) {
			
			String insertSql = "Insert into userDetails(firstName,lastName,email,contact,status,role,userName,password,createdDate)values(?,?,?,?,?,?,?,?,?)";
			try {
			
				pstmt = con.prepareStatement(insertSql);
				pstmt.setString(1, newUser.getFirstName());
				pstmt.setString(2, newUser.getLastName());
				pstmt.setString(3, newUser.getEmail());
				pstmt.setString(4, newUser.getContact());
				pstmt.setString(5, newUser.getStatus().getValue());
				pstmt.setString(6, newUser.getRole().getValue());
				pstmt.setString(7, newUser.getUserName());
				pstmt.setString(8, newUser.getPassword());
				pstmt.setDate(9, date);
				
				pstmt.execute();
				
				return true;
				
			} catch (SQLException e) {
				
				e.printStackTrace();
				return false;
			}
			
		}

		
		public boolean updateUser(User user) {
			
			String updateSql = "UPDATE userDetails SET firstName = '"+user.getFirstName()+"'"
					+ ",lastName = '"+user.getLastName()+"' "
					+ ",email = '"+user.getEmail()+"' "
					+ ",contact = '"+user.getContact()+"' "
					+ ",status = '"+user.getStatus().getValue()+"' "
					+ ",role = '"+user.getRole().getValue()+"' "
					+ ",userName = '"+user.getUserName()+"' "
					+ ",password = '"+user.getPassword()+"' "
					+ ",modifiedDate = '"+date+"' "
					+ "WHERE id = '"+user.getId()+"' ";
			//System.out.println(updateSql);
			try {
				pstmt = con.prepareStatement(updateSql);
				int updateExecuted = pstmt.executeUpdate(updateSql);
				if(updateExecuted > 0) {
					//System.out.println("User data is updated");
					return true;
				}
				else {
					//System.out.println("User data is not updated");
					return false;
				}
			} catch (SQLException e) {
				
				e.printStackTrace();
				return false;
			}
			
		}

		public Set<User> getAllUsers() {
			
			Set<User> usersList = new LinkedHashSet<User>();
			String allSql = "select * from userDetails;";
			try {
				pstmt = con.prepareStatement(allSql);
				ResultSet result = pstmt.executeQuery();
				
				while (result.next()) {
					User user = extractUserFromResultSet(result);
					usersList.add(user);
				}
				
				return usersList;
				
			} catch (SQLException e) {
				
				e.printStackTrace();
				return null;
			}

		}

		
		public boolean deleteUser(int id) {
			
			String deleteSql =  "delete from userDetails where id = '"+id+"';";
			//System.out.println(deleteSql);
			try {
				pstmt = con.prepareStatement(deleteSql);
				int execute = pstmt.executeUpdate();
				if(execute > 0) {
					//System.out.println("User data deleted");
					return true;
				}
				else {
					//System.out.println("User data not deleted");
					return false;
				}
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}

		
		public Set<User> listTrainees() {
			
			Set<User> traineeList = new LinkedHashSet<User>();
			String allTraineesSql = "select * from userDetails where role = 'Trainee';";
			//System.out.println(allTraineesSql);
			try {
				pstmt = con.prepareStatement(allTraineesSql);
				ResultSet result = pstmt.executeQuery();
				
				while (result.next()) {
					User user = extractUserFromResultSet(result);
					traineeList.add(user);
				}
				
				return traineeList;
				
			} catch (SQLException e) {
				
				e.printStackTrace();
				return null;
			}
			
		}

	}


