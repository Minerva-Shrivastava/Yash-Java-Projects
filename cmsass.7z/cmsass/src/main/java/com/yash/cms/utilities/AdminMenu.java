package com.yash.cms.utilities;

import java.util.Scanner;

import com.yash.cms.modal.User;
import com.yash.cms.service.AdminService;
import com.yash.cms.serviceimpl.AdminServiceImpl;

public class AdminMenu {

	public static void displayMenu()
	{
		Scanner sc = new Scanner(System.in);
		AdminService adminService = new AdminServiceImpl();
		String continueChoice ;
		
		do {
			System.out.println("******Admin Menu******");
			System.out.println(" 1. List all users"
					  + "\n 2. Change status of a user"
					  + "\n 3. Change role of a user "
					  + "\n 4. Update user"
					  + "\n 5. Delete user"
					  + "\n 6. List all courses");
			
			int choice = sc.nextInt();
			
			switch (choice) {
			case 1:
				adminService.listUsers();			
			break;

			case 2:
				System.out.println("Enter user's id: ");
				int id = sc.nextInt();
				System.out.println("Enter the status:");
				String changeStatus = sc.next();
				adminService.changeStatus(id, changeStatus);			
				break;
			
			case 3:
				System.out.println("Enter user's id: ");
				int idForUpdate = sc.nextInt();
				System.out.println("Enter the role:");
				String changeRole = sc.next();
				adminService.changeRole(idForUpdate, changeRole);			
				break;
			
			case 4:	User updateUser = new User();
					System.out.println("Enter your ID: ");
					int id1 = sc.nextInt();
					updateUser.setId(id1);
					System.out.println("Enter your first name : ");
					String firstName = sc.next();
					updateUser.setFirstName(firstName);
					System.out.println("Enter your last name : ");
					String lastName = sc.next();
					updateUser.setLastName(lastName);
					System.out.println("Enter your email : ");
					sc.nextLine();
					String email = sc.nextLine();
					updateUser.setEmail(email);
					System.out.println("Enter your contact : ");
					String contact = sc.next();
					updateUser.setContact(contact);
					System.out.println("Enter your status : ");
					String status = sc.next();
					updateUser.setStatus(status);
					System.out.println("Enter your role : ");
					String role = sc.next();
					updateUser.setRole(role);
					System.out.println("Enter your userName : ");
					String userName = sc.next();
					updateUser.setUserName(userName);
					System.out.println("Enter your password : ");
					String password = sc.next();
					updateUser.setPassword(password);
					adminService.updateUser(updateUser);			
					break;

			case 5:
				System.out.println("Enter user's id: ");
				int idForDelete = sc.nextInt();
				adminService.deleteUsers(idForDelete);
				break;
			case 6:
				adminService.listCourses();			
				break;


			
			default:System.out.println("Invalid option");
					sc.close();
					System.exit(0);
				break;
			}
			
			System.out.println("Do you want to continue?yes/no");
			continueChoice = sc.next();
		}while(continueChoice.equalsIgnoreCase("yes"));
		
	}
}
