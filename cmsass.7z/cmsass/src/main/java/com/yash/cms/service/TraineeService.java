package com.yash.cms.service;

public interface TraineeService {

	void listCourses();

	
}
