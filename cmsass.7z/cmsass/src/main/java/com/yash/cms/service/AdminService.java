package com.yash.cms.service;

import com.yash.cms.modal.User;

public interface AdminService {

	void listUsers();

	void changeStatus(int id, String changeStatus);

	void changeRole(int id1, String changeRole);

	void updateUser(User updateUser);

	void deleteUsers(int idForDelete);

	void listCourses();

	
}
