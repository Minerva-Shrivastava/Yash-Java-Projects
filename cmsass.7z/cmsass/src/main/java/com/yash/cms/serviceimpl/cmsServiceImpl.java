package com.yash.cms.serviceimpl;

import java.util.LinkedHashMap;
import java.util.List;

import com.yash.cms.DAO.CourseDAO;
import com.yash.cms.DAOImpl.CourseDAOImpl;
import com.yash.cms.service.cmsService;

public class cmsServiceImpl implements cmsService{

	private CourseDAO courseDB = new CourseDAOImpl();

	public List<String> getAllMaintitle(String course) {
		return courseDB.getAllMainTitles(course);
	}

	public List<String> getAllCourses() {
		return courseDB.getAllCourses();
	}

	public LinkedHashMap<String, List<String>> getMainTitleFromCourse() {
		LinkedHashMap<String, List<String>> course_MainTitleList = new LinkedHashMap<String, List<String>>();
		List<String> allCourses = getAllCourses();
		for (String courseName : allCourses) {
			course_MainTitleList.put(courseName, getAllMaintitle(courseName));
		}
 		return course_MainTitleList;
	}

	public boolean authenticate(String userName, String pwd) {
		
		String password = courseDB.getPasswordFromUsername(userName);
		if(pwd.equals(password))
			return true;
		else
			return false;
	}
	
	

}
