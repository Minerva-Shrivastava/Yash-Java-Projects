package com.yash.cms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.cms.service.cmsService;
import com.yash.cms.serviceimpl.cmsServiceImpl;

/**
 * Servlet implementation class AddSubtitleServlet
 */
public class AddSubtitleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private cmsService service = new cmsServiceImpl();
	private LinkedHashMap<String, List<String>> courseAndMainTitle;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/HTML");
		String course = request.getParameter("course");
		courseAndMainTitle = service.getMainTitleFromCourse();
		PrintWriter out = response.getWriter();
		out.println("On Servlet<br>");
		/*RequestDispatcher rd = request.getRequestDispatcher("AddSubTitle.html");
		rd.include(request, response);
		*/
		htmlHead(out);
		out.println("<td><select name='course' onchange='this.form.submit() style='width: 150px' required>");
		out.println("<option value=''>--select an option--</option>");
		for (Map.Entry map : courseAndMainTitle.entrySet()) {
			if(course.equalsIgnoreCase(""+map.getKey()))
			{out.println("<option value='"+map.getKey()+"' selected>"+(map.getKey())+"</option>");}
			else out.println("<option value='"+map.getKey()+"'>"+(map.getKey())+"</option>");
		}
		out.println("</select></td><td>Sub Title</td>");
		out.println("<td><input type='text' name='Subtitle'></td></tr>");
		out.println("<tr><td>Main Title</td>" + 
				"<td><select name='mainTitle' style='width: 150px'>");
		out.println("<<option value=''>--select an option--</option>");
		for (Map.Entry map : courseAndMainTitle.entrySet()) {
            if(course.equalsIgnoreCase(""+map.getKey())){
            	List<String> mainTitles=(List<String>)map.getValue();
            	for (String mainTitleName : mainTitles) {
            		out.println("<option value'"+mainTitleName+"'>"+mainTitleName+"</option>");   
            	}
            }
		}
		out.println("</select></td>");
		htmlTail(out);
	}

	private void htmlHead(PrintWriter out) {
			out.println("<!DOCTYPE html>");
			out.println("<html>");
			out.println("<head><title>Subtitle File Upload</title></head>");
			out.println("<body>");
			out.println("<center>");
			out.println("<fieldset style='width: 700px'>");
			out.println("<legend>Add Sub Title</legend>");
			out.println("<form action = 'AddSubtitleServlet' method='post' enctype='multipart form-data'>");
			out.println("<table>");
			out.println("<tr><td>Course :</td>");
		
	}
	private void htmlTail(PrintWriter out) {

		out.println("<td>Upload file<br>(only pdf and mp4):</td>" + 
				"	<td><input type='file' name='fname'></td>" + 
				"	</tr>" + 
				"	<tr>" + 
				"	 	<td>Description</td>" + 
				"		  	<td colspan='5'><textarea rows=4' cols='60' name='description'></textarea></td>" + 
				"	</tr>" + 
				"	<tr>" + 
				"		 <td>Publish the document</td>" + 
				"		 <td><input type='checkbox' name='publish' value='publish'></td>" + 
				"	</tr>" + 
				"	<tr>" + 
				"		 <td colspan=\"4\" style=\"text-align: right;\"><input type=\"submit\" value=\"Add\"></td>\r\n" + 
				"	</tr>" + 
				"	</table>" + 
				"</form>" + 
				"</fieldset>" + 
				"</body>" + 
				"</html>");
		
	}

}
