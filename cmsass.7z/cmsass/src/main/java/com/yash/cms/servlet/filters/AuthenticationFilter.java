package com.yash.cms.servlet.filters;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import com.yash.cms.service.cmsService;
import com.yash.cms.serviceimpl.cmsServiceImpl;

/**
 * Servlet Filter implementation class AuthenticationFilter
 */
public class AuthenticationFilter implements Filter {
	
	cmsService service = new cmsServiceImpl();

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		
		
		System.out.println("************");
		System.out.println("Auth filter init method called in : "
				+ this.getClass().getName());
		System.out.println("************");
		
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		response.setContentType("text/html");
		System.out.println("************");
		System.out.println("do filter method of Auth. filter called in : "
				+ this.getClass().getName());
		
		HttpServletRequest req = (HttpServletRequest) request;
		//HttpServletResponse resp = (HttpServletResponse) response;
		
		String userName = req.getParameter("name");
		String pwd = req.getParameter("pwd");
		
		System.out.println("Username :"+userName +"password :" +pwd);
		
		boolean auth = service.authenticate(userName,pwd);
		
		if(auth == true)
			chain.doFilter(request, response);
		else
		{
			RequestDispatcher rd = req.getRequestDispatcher("Login.html");
			PrintWriter out= response.getWriter();
			out.println("<center><font color=red>Either user name or password is wrong.</font></center>");
			rd.include(request, response);
		}
	}

	

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		
		System.out.println("************");
		System.out.println("Auth filter destroy method called in : "
				+ this.getClass().getName());
		System.out.println("************");
		
	}
}
