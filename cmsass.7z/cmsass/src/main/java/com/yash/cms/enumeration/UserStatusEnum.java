package com.yash.cms.enumeration;

public enum UserStatusEnum {

PENDING("Pending"), ACTIVE("Active"), INACTIVE("Inactive"), DELETED("Deleted");
	
	/**
	 * variable value and constructor
	 */
	private String value;
	private UserStatusEnum(String value) {
		this.value = value;
	}
	/**
	 * Getter method for value 
	 * @return value
	 */
	public String getValue() {
		
		return value;
		
	}
}
