package com.yash.cms.serviceimpl;

import java.util.List;
import com.yash.cms.DAO.CourseDAO;
import com.yash.cms.DAOImpl.CourseDAOImpl;
import com.yash.cms.service.TraineeService;

public class TraineeServiceImpl implements TraineeService{

	CourseDAO courseDB = new CourseDAOImpl();
		
		public String getPasswordFromUsername(String userName) {
			// TODO Auto-generated method stub
			return null;
		}
		
		public List<String> getAllMainTitles(String course) {
			// TODO Auto-generated method stub
			return null;
		}
		
		public List<String> getAllCourses() {
			// TODO Auto-generated method stub
			return null;
		}
	
	
	public void listCourses() {
		
		List<String> listCourses = courseDB.getAllCourses();
		for (String course : listCourses) {
			System.out.println(course);
		}
		
		
	}
}

