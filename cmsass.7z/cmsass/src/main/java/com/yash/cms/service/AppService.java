package com.yash.cms.service;

import com.yash.cms.modal.User;

public interface AppService {

	void userRegistration(User newUser);

	boolean userLogin(String userName, String password);

	
}
