package com.yash.cms.DAO;

import java.util.Set;
import com.yash.cms.modal.User;

public interface UsersDAO {

	Set<User> getAllUsers();
	User getUserById(Integer id);
	User getUserByUserNameAndpassword(String userName, String password);
	boolean insertUser(User newUser);
	boolean updateUser(User user);
	boolean deleteUser(int id);
	Set<User> listTrainees();

}
