package com.yash.cms.DAO;

import java.util.List;
import java.util.Set;

import com.yash.cms.modal.Course;

public interface CourseDAO {

	List<String> getAllCourses();

	List<String> getAllMainTitles(String course);

	String getPasswordFromUsername(String userName);

	boolean addCourse(Course course);

	Set<Course> listCourses();

	boolean deleteCourse(int deleteId);

	boolean updateCourse(Course updateCourse);

	
}
