package com.yash.cms.service;

import java.util.LinkedHashMap;
import java.util.List;

public interface cmsService {

	public List<String> getAllMaintitle(String course);
	public List<String> getAllCourses();
	public LinkedHashMap<String, List<String>> getMainTitleFromCourse();
	public boolean authenticate(String userName, String pwd); 
	
}
