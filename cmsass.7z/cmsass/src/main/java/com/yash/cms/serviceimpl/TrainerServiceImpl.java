package com.yash.cms.serviceimpl;

import java.util.Set;
import com.yash.cms.DAO.CourseDAO;
import com.yash.cms.DAO.UsersDAO;
import com.yash.cms.DAOImpl.CourseDAOImpl;
import com.yash.cms.DAOImpl.UsersDAOImpl;
import com.yash.cms.modal.Course;
import com.yash.cms.modal.User;
import com.yash.cms.service.TrainerService;

public class TrainerServiceImpl implements TrainerService{

	UsersDAO userDB = new UsersDAOImpl();
	CourseDAO courseDB = new CourseDAOImpl(); 
		
	public void listTrainees() {
		
		Set<User> traineeslist = userDB.listTrainees();
		for (User user : traineeslist) {
			System.out.println(user);
		}
		
	}

	public void addCourse(Course course) {
		
		boolean courseAdded = courseDB.addCourse(course);
		if(courseAdded == true)
			System.out.println("Course is added");
		else
			System.out.println("Course is not added");
	}

	
	public void updateCourse(Course updateCourse) {
		
		boolean courseUpdated = courseDB.updateCourse(updateCourse);
		if(courseUpdated == true)
			System.out.println("Course is updated");
		else
			System.out.println("Course is not updated");
	}

	public void deleteCourse(int deleteId) {
		
		boolean deleteCourse = courseDB.deleteCourse(deleteId);
		if(deleteCourse == true)
			System.out.println("Course is deleted");
		else
			System.out.println("Course is not deleted");
	}

	public void listCourses() {
		
		Set<Course> listCourses = courseDB.listCourses();
		for (Course course : listCourses) {
			System.out.println(course);
		}
	}
	
	
	

}
