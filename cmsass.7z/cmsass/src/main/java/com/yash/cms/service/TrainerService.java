package com.yash.cms.service;

import com.yash.cms.modal.Course;

public interface TrainerService {

	void listTrainees();

	void addCourse(Course course);

	void updateCourse(Course updateCourse);

	void deleteCourse(int deleteId);

	void listCourses();

}
