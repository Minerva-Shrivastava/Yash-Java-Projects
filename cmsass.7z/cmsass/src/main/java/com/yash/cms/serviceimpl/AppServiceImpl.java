package com.yash.cms.serviceimpl;

import com.yash.cms.DAO.UsersDAO;
import com.yash.cms.DAOImpl.UsersDAOImpl;
import com.yash.cms.modal.User;
import com.yash.cms.service.AppService;
import com.yash.cms.utilities.AdminMenu;
import com.yash.cms.utilities.TraineeMenu;
import com.yash.cms.utilities.TrainerMenu;

public class AppServiceImpl implements AppService {

	UsersDAO userDB = new UsersDAOImpl();
	
	public void userRegistration(User newUser) {
		
		userDB.insertUser(newUser);
		
	}
	
	
	public boolean userLogin(String userName, String password) {
		
		User user = userDB.getUserByUserNameAndpassword(userName, password);
		if(user == null) {
			System.out.println("User not found");
			return false;
		}
		getUserRole(user);
		return true;
	}


	private void getUserRole(User user) {
		String role = user.getRole().getValue();
		String status = user.getStatus().getValue();
		System.out.println("Login successful");
		System.out.println("Role:"+role+" status:"+status);
		
		if(role.equalsIgnoreCase("Admin") && status.equalsIgnoreCase("Active"))
		{
			System.out.println("\n Welcome "+user.getFirstName()+" "+user.getLastName()+" to Admin Dashboard");
			AdminMenu.displayMenu();
		}
		if(role.equalsIgnoreCase("Trainer") && status.equalsIgnoreCase("Active"))
		{
			System.out.println("\n Welcome "+user.getFirstName()+" "+user.getLastName()+" to Trainer Dashboard");
			TrainerMenu.displayMenu();
		}
		if(role.equalsIgnoreCase("Trainee") && status.equalsIgnoreCase("Active"))
		{
			System.out.println("\n Welcome "+user.getFirstName()+" "+user.getLastName()+" to Trainee Dashboard");
			TraineeMenu.displayMenu();
		}
	}
	
	
}
