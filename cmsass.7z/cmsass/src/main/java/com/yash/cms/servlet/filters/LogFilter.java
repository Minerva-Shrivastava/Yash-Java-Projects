package com.yash.cms.servlet.filters;

import java.io.IOException;
import java.util.Date;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

/**
 * Servlet Filter implementation class LogFilter
 */
public class LogFilter implements Filter {

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		
		System.out.println("************");
		System.out.println("Log filter init method called in : "
				+ this.getClass().getName());
		System.out.println("************");
		
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		System.out.println("log filter doFiler called in : "
				+ this.getClass().getName());
		
		HttpServletRequest req = (HttpServletRequest) request;
		
		//Get the IP Address of client machine
		String ipAddress = req.getRemoteAddr();
		
		//Log the IP Address and current time stamp
		System.out.println("IP :"+ipAddress+" ,time: "
				+ new Date().toString()+"\n\n");
				
		chain.doFilter(request, response);
	}


	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		
		System.out.println("************");
		System.out.println("Log filter destroy method called in"
				+ this.getClass().getName());
		System.out.println("************");
	}

}
