package com.yash.cms.DAOImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import com.yash.cms.DAO.CourseDAO;
import com.yash.cms.dbutil.DBUtil;
import com.yash.cms.modal.Course;

public class CourseDAOImpl implements CourseDAO{

	private Connection con = DBUtil.getConnection();
	private PreparedStatement pstmt;
	private List<String> courseRepository = new LinkedList<String>();
	
	public List<String> getAllCourses() {
		
		String allCoursesSql = "SELECT DISTINCT course FROM courses;";
		try {
			System.out.println("Getting all courses");
			pstmt = con.prepareStatement(allCoursesSql);
			ResultSet result = pstmt.executeQuery();
			return extractFromResultSet(result,"course");
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	private List<String> extractFromResultSet(ResultSet result,String columnName) {
		try {
			while(result.next()) {
			System.out.println(result.getString(columnName));
			courseRepository.add(result.getString(columnName));
			}
			return courseRepository;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	public List<String> getAllMainTitles(String course) {
		String allMainTitlesSql = "SELECT mainTitle FROM courses WHERE course='"+course+"';";
		try {
			pstmt = con.prepareStatement(allMainTitlesSql);
			ResultSet result = pstmt.executeQuery();
			return extractFromResultSet(result,"mainTitle");
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}	
	}
	public String getPasswordFromUsername(String userName) {
		
		String getPasswordSql = "SELECT password FROM userdetails WHERE userName='"+userName+"';";
		System.out.println(getPasswordSql);
		try {
			pstmt = con.prepareStatement(getPasswordSql);
			ResultSet result = pstmt.executeQuery();
			String pwd = result.getString(0);
			return pwd;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	public boolean addCourse(Course course) {
		// TODO Auto-generated method stub
		return false;
	}

	public Set<Course> listCourses() {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean deleteCourse(int deleteId) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean updateCourse(Course updateCourse) {
		// TODO Auto-generated method stub
		return false;
	}

	
}
