package com.yash.DAOImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import com.yash.util.DBUtil;
import com.yash.DAO.CourseDAO;

public class CourseDAOImpl implements CourseDAO{

	private Connection con = DBUtil.getConnection();
	private PreparedStatement pstmt;
	private List<String> courseRepository = new LinkedList<String>();
	
	public List<String> getAllCourses() {
		
		String allCoursesSql = "SELECT DISTINCT course FROM courses;";
		try {
			System.out.println("Getting all courses");
			pstmt = con.prepareStatement(allCoursesSql);
			ResultSet result = pstmt.executeQuery();
			return extractFromResultSet(result,"course");
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	private List<String> extractFromResultSet(ResultSet result,String columnName) {
		try {
			while(result.next()) {
			System.out.println(result.getString(columnName));
			courseRepository.add(result.getString(columnName));
			}
			return courseRepository;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	public List<String> getAllMainTitles(String course) {
		String allMainTitlesSql = "SELECT mainTitle FROM courses WHERE course='"+course+"';";
		try {
			pstmt = con.prepareStatement(allMainTitlesSql);
			ResultSet result = pstmt.executeQuery();
			return extractFromResultSet(result,"mainTitle");
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}	
	}
}
