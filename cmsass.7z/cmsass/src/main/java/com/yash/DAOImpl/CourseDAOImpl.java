package com.yash.DAOImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;
import com.yash.modal.Course;
import com.yash.util.DBUtil;
import com.yash.DAO.CourseDAO;

public class CourseDAOImpl implements CourseDAO{

	Connection con = DBUtil.getConnection();
	PreparedStatement pstmt;
	
	public List<Course> getAllCourses() {
		
		String allCoursesSql = "SELECT course FROM ";
		//con.prepareStatement(allCoursesSql);
		return null;
		
	}
	
}
