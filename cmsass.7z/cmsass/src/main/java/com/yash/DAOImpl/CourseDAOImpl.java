package com.yash.DAOImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import com.yash.modal.Course;
import com.yash.util.DBUtil;
import com.yash.DAO.CourseDAO;

public class CourseDAOImpl implements CourseDAO{

	Connection con = DBUtil.getConnection();
	PreparedStatement pstmt;
	List<String> courseRepository = new LinkedList<String>();
	
	public List<String> getAllCourses() {
		
		String allCoursesSql = "SELECT course FROM courses";
		try {
			pstmt = con.prepareStatement(allCoursesSql);
			ResultSet result = pstmt.executeQuery();
			return extractFromResultSet(result);
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
		
	}

	private List<String> extractFromResultSet(ResultSet result) {
		try {
			while(result.next()) {
			courseRepository.add(result.getString("course"));
			}
			return courseRepository;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
	}
	
}
