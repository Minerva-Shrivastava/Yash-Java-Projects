package com.yash.modal;

public class Course {

	private int id;
	private String course;
	private String mainTitle;
	private String subTitle;
	private String path;
	private String description;
	private int status;
	
	public Course() {
		
	}
	public Course(int id, String course, String mainTitle, String subTitle, String path, String description,
			int status) {
		super();
		this.id = id;
		this.course = course;
		this.mainTitle = mainTitle;
		this.subTitle = subTitle;
		this.path = path;
		this.description = description;
		this.status = status;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public String getMainTitle() {
		return mainTitle;
	}
	public void setMainTitle(String mainTitle) {
		this.mainTitle = mainTitle;
	}
	public String getSubTitle() {
		return subTitle;
	}
	public void setSubTitle(String subTitle) {
		this.subTitle = subTitle;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	
	@Override
	public String toString() {
		
		return "[ course:"+this.course
				+" \tMainTitle:"+this.mainTitle
				+" \tSubTitle:"+this.subTitle
				+" \tPath:"+this.path
				+" \tDescription:"+this.description
				+" \tStatus:"+this.status
				+" ]";
	}
}
