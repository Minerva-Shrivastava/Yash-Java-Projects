package com.yash.util;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;

public class DBUtil {

	public DBUtil(String driverClassName) {
		try {
			Class c = Class.forName(driverClassName);
			System.out.println("Driver Loaded "+c);
			
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
			System.out.println("Driver not loaded");
		}
		
	}

	public static Connection getConnection() {
		
		java.sql.Connection conn;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/course_management_system", "root", "root");
			System.out.println("Connection made");
			return conn;
		} catch (Exception e) {
			
			e.printStackTrace();
			return null;
		}
		
	}
	
	
	
	

}
