package cmsass;

import static org.junit.Assert.*;
import org.junit.Test;
import com.yash.util.DBUtil;

public class DBUtilTest {

	@Test
	public void costructorTestForDriver() {
		DBUtil dbUtil=new DBUtil("com.mysql.jdbc.Driver");
		assertEquals(com.mysql.jdbc.Driver.class,ClassLoader.getSystemClassLoader().getClass());
	}
	
	@Test(expected = ClassNotFoundException.class)
	public void costructorExceptionTestForDriver() {
		DBUtil dbUtil=new DBUtil("com.mysql.jdbc.Driver");
		
	}
	
	/*@Test
	public void testConnection() throws SQLException {
		DBUtil dbUtil=new DBUtil("com.mysql.jdbc.Driver");
		java.sql.Connection conn = dbUtil.getConnection();
		java.sql.Connection expectedConn  = DriverManager.getConnection("jdbc:mysql://localhost:3306/course_management_system", "root", "root");
		System.out.println("Expected connection "+expectedConn.getCatalog());
		System.out.println("Expected connection "+conn.getCatalog());
		assertEquals(expectedConn.getCatalog(), conn.getCatalog());
		
	}*/
}
