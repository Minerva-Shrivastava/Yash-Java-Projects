package com.yash.abstractdemo;

public class Maruti800 extends Car {

	@Override
	public void drive() {
		System.out.println("Drive Maruti800 by normal steetring");
		
	}

	@Override
	public void stop() {
		System.out.println("Stop Maruti800 by normal brake");
		
	}
	
	

	
}
