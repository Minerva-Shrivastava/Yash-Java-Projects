package com.yash.abstractdemo;

public class CarTest {

	public static void main(String[] args) {
		Car driver = new Safari();
		driver.drive();
		driver.stop();
		driver.fillTank();
		driver.musicSystem();
	}
}
