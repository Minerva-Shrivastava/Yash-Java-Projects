package com.yash.abstractdemo;

public class Safari extends Car{

	@Override
	public void drive() {
		System.out.println("Drive Safari by normal steetring");
		
	}

	@Override
	public void stop() {
		System.out.println("Drive Safari by normal steetring");
		
	}

	
	
}
