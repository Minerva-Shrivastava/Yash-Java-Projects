package com.yash.abstractdemo;
public abstract class Car {

	public abstract void drive();
	public abstract void stop();
	
	public void fillTank()
	{
		System.out.println("filling tank");
	}

	public void musicSystem()
	{
		System.out.println("Music is playing....");
	}
	
}
