 package com.yash.collDemo.util;

import com.yash.collDemo.serviceimpl.EmployeeServiceImpl;
import com.yash.collDemo.service.IEmployeeService;

public class ServiceFactory {

	public static IEmployeeService getEmployeeService() {
		return new EmployeeServiceImpl();
	}
}
