package com.yash.collDemo.util;

public class ApplicationMenu {

	public static void showApplicationMenu()
	{
		System.out.println("******Menu*****");
		System.out.println("\n 1. Add Employee"
						 + "\n 2. Search Employee By ID"
						 + "\n 3. Display List of Employee"
						 + "\n 4. Delete by ID"
						 + "\n 5. Delete Employee"
						 + "\n 6. Update "
						 + "\n 7. Search By freetext"
						 + "\n 8. Sort Empolyee"
						 + "\n 9. No Duplicate Record"
						 + "\n 10.Duplicate Records"
						 + "\n 11.Duplicate Records with frequency"
						 + "\n 0. Exit");
	}
}

