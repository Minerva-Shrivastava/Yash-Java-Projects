package com.yash.collDemo.exception;

public class IllegalSortOrderException extends Exception{

}
