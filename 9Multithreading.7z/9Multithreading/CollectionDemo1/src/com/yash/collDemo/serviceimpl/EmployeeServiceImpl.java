package com.yash.collDemo.serviceimpl;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.yash.collDemo.comparator.DepatmentCamparator;
import com.yash.collDemo.comparator.IdComparator;
import com.yash.collDemo.comparator.NameComparator;
import com.yash.collDemo.comparator.SalaryComaparator;
import com.yash.collDemo.model.Employee;
import com.yash.collDemo.service.*;
import java.util.List;

public class EmployeeServiceImpl implements IEmployeeService{
	
	private List<Employee> employeeRepositpory = null;
	
	public EmployeeServiceImpl() {
		employeeRepositpory = new ArrayList<>();
		employeeRepositpory.add(new Employee(101, "Amit", 1200, "Development"));
		employeeRepositpory.add(new Employee(102, "Amrita", 1300, "Testing"));
		employeeRepositpory.add(new Employee(103, "Amrita", 1300, "Testing"));
		employeeRepositpory.add(new Employee(104, "Amit", 1300, "Testing"));
		employeeRepositpory.add(new Employee(105, "Amit", 1300, "Testing"));
		employeeRepositpory.add(new Employee(106, "Sakshi", 1300, "Testing"));
	}

	@Override
	public void insert(Employee employee) {
		employeeRepositpory.add(employee);
	}

	@Override
	public void deleteByEmployee(Employee employee) {
		
		this.deleteById(employee.getId());
		
	}

	@Override
	public void deleteById(Integer id) {
		for (Employee employee : employeeRepositpory) {
			if(employee.getId() == id)
			{
				employeeRepositpory.remove(employee);
				break;//Size is reduced but loop will look uptil 10 locations, break so that it can process the size
			}
		}
		
		getAvailableList();
	}

	private void getAvailableList() {
		System.out.println("Available List...");
		for (Employee employee : employeeRepositpory) {
			System.out.print("{"+" ID:"+employee.getId()+" Name:"+employee.getName()+" Salary:"+employee.getSalary()+" Department:"+employee.getDepartment()+" }");
			System.out.println();
		}
	}

	@Override
	public Employee getEmployee(Integer id) {
		for(Employee employee:employeeRepositpory)
		{
			if(employee.getId() == id)
			{
				System.out.println("Found the Employee");
				return employee;
			}
		}
		return null;
	}

	@Override
	public List<Employee> listEmployee() {
		
		return employeeRepositpory;
	}

	@Override
	public void updateEmployee(Employee employeeToBeUpdated) {
		
		for(Employee employee:employeeRepositpory)
		{
			if(employee.getId() == employeeToBeUpdated.getId())
			{
				employee.setName(employeeToBeUpdated.getName());
				System.out.println(employeeToBeUpdated.getName()+"************");
				employee.setSalary(employeeToBeUpdated.getSalary());
				employee.setDepartment(employeeToBeUpdated.getDepartment());
			}
		}
		
		getAvailableList();
	}

	@Override
	public List<Employee> searchByFreeText(String searchText) {
		
		List<Employee> tempFreeText = new ArrayList<Employee>();
		for (Employee employee : employeeRepositpory) {
			if(employee.getId().toString().equalsIgnoreCase(searchText) ||
					employee.getName().equalsIgnoreCase(searchText) ||
					employee.getSalary().toString().equalsIgnoreCase(searchText) ||
					employee.getDepartment().equalsIgnoreCase(searchText));
			{
				tempFreeText.add(employee);
			}
			
		}		
		return tempFreeText;
	}

	@Override
	public List<Employee> sortEmployee(String sortOrder) {
		
		List<Employee> tempRepo = new ArrayList<Employee>();
		tempRepo.addAll(employeeRepositpory);
		
		if(sortOrder.equalsIgnoreCase("ID"))
		{
			Collections.sort(tempRepo, new IdComparator());
		}
		if(sortOrder.equalsIgnoreCase("Name"))
		{
			Collections.sort(tempRepo, new NameComparator());
		}
		
		else if(sortOrder.equalsIgnoreCase("Salary"))
		{
			Collections.sort(tempRepo, new SalaryComaparator());
		}
		else if(sortOrder.equalsIgnoreCase("Department"))
		{
			Collections.sort(tempRepo, new DepatmentCamparator());
		}
		else
		{
			System.out.println("Invalid sort order");
		}
		
		return employeeRepositpory;
	}

	@Override
	public List<Employee> duplicateOrNonDuplicateRecord(String choice) {
		
		List<Employee> nonDuplicateRepo = new ArrayList<Employee>();
		List<Employee> duplicateRepo = new ArrayList<Employee>();
		List<Integer> countRepo = new ArrayList<>();
		nonDuplicateRepo.addAll(employeeRepositpory);	
				
		for (int i=0; i<employeeRepositpory.size(); i++) 
		{
			int count = 1;
			for (int j=i+1; j<employeeRepositpory.size(); j++) 
			{
				if(employeeRepositpory.get(i).getName().equals(employeeRepositpory.get(j).getName()))
				{
					count++;				
				}
			}
			if(count > 1)
			{
				//System.out.println("\nThe Employee :"+employeeRepositpory.get(i)+"has occurred :"+count+" times");
				if(duplicateRepo.isEmpty())
				{
					duplicateRepo.add(employeeRepositpory.get(i));
					System.out.println(" has occurred : "+count+" times");
					countRepo.add(count);
				}
				else {
					if(duplicateRepo.contains(employeeRepositpory.get(i)))
					{	//System.out.println("already has it");
					}
					else
					{
						duplicateRepo.add(employeeRepositpory.get(i));
						System.out.println(" has occurred : "+count+" times");
						countRepo.add(count);
					}
				}
			}
			if(count < 1)
			{
				nonDuplicateRepo.add(employeeRepositpory.get(i));
			}
		}
		nonDuplicateRepo.removeAll(duplicateRepo);
		//System.out.println("Duplicate elements :"+duplicateRepo);
		//System.out.println("Non duplicate elements :"+nonDuplicateRepo+" and its size is:"+nonDuplicateRepo.size());
		this.duplicateEmpWithFreq(countRepo);
		
		if(choice.equalsIgnoreCase("Duplicate"))
			return duplicateRepo;
		if(choice.equalsIgnoreCase("Non Duplicate"))
			return nonDuplicateRepo;
		return null;
	}

	
	public List<Integer> duplicateEmpWithFreq(List<Integer> countRepo) {
		
		return countRepo;
	}
		/*List<String> list=new ArrayList();
		
		for(int i=0;i<employeeRepositpory.size();i++)
		{
			int count = 1;
			for(int j=i+1;j<employeeRepositpory.size();j++) {
				if(employeeRepositpory.get(i).getName().equalsIgnoreCase(employeeRepositpory.get(j).getName())) 
				{	
					count++;
				}
			}
			if(count > 0)
			{
					if(list.isEmpty())
					list.add(employeeRepositpory.get(i).getName()+" has occured : "+Integer.toString(count));
					else {
						if(list.contains(employeeRepositpory.get(i).getName()))
						{	//System.out.println("already has it");
						}
						else
							list.add(employeeRepositpory.get(i).getName()+"has occurred : "+Integer.toString(count));
				}
			}
		
		}
		return list;
	}*/

	
}
