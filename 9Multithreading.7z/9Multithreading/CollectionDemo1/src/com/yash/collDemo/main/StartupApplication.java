package com.yash.collDemo.main;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import com.yash.collDemo.service.IEmployeeService;
import com.yash.collDemo.util.*;
import com.yash.collDemo.model.*;
import com.yash.collDemo.model.*;

public class StartupApplication {

	public static void main(String[] args) {
		

		Scanner sc = new Scanner(System.in);/**Object of Scanner class to take input from console */
		String continueChoice = null;
		
		/**Reference of Employee class and object of EmployeeService class to access the services*/
		Employee employee=null;
		
		IEmployeeService employeeService = ServiceFactory.getEmployeeService();
		
		
		/**
		 * This Menu is for choosing the services that are provided
		 */
		
		do
		{
			ApplicationMenu.showApplicationMenu();
			
			int choice = sc.nextInt();
			switch(choice)
			{
				case 1:  employee = new Employee();/**Add Employees to the list*/	
									
							System.out.println("Enter Employee ID");
							employee.setId(sc.nextInt());
							sc.nextLine();
							System.out.println("Enter Employee Name");
							employee.setName(sc.nextLine());
							System.out.println("Enter Employee Salary");
							employee.setSalary(sc.nextInt());
							System.out.println("Enter Employee Department");
							employee.setDepartment(sc.next());
					
							employeeService.insert(employee);
							System.out.println("\n Record Inserted");
							break;
				
				case 2: System.out.println("\n Enter the ID of Employee");
						int id = sc.nextInt();
						System.out.println("\n Searching by ID");
						Employee empById = employeeService.getEmployee(id);
						System.out.println(empById);
						break; 
						
				case 3: System.out.println("\n All the employees are");
						List<Employee> employeeResultRepo= employeeService.listEmployee();
						for (Employee tempEmployee: employeeResultRepo) {
							System.out.println(tempEmployee);
						}
						break;
						
				case 4: System.out.println("\n Delete by ID");
						System.out.println("\n Enter the ID of Employee");
						int deleteById = sc.nextInt();
						employeeService.deleteById(deleteById);
						break;
						
				case 5: System.out.println("\n Delete Employee");
						employee = new Employee();	
						
						System.out.println("Enter Employee ID");
						employee.setId(sc.nextInt());

						employeeService.deleteByEmployee(employee);
					    break;
					    
				case 6: System.out.println("\n Enter Updation Details:");
						employee = new Employee();	
						
						System.out.println("Enter Employee ID");
						employee.setId(sc.nextInt());
						sc.nextLine();
						System.out.println("Enter Employee Name");
						employee.setName(sc.nextLine());
						System.out.println("Enter Employee Salary");
						employee.setSalary(sc.nextInt());
						System.out.println("Enter Employee Department");
						employee.setDepartment(sc.next());
		
						employeeService.updateEmployee(employee);
			    		break;
			    		
				case 7: System.out.println("\nEnter the what you want to search:");
						sc.nextLine();
						String searchText = sc.nextLine();
						List<Employee> employeeResultRepo1 = employeeService.searchByFreeText(searchText);
							for (Employee tempEmployee: employeeResultRepo1) {
								System.out.println(tempEmployee);
							}
						break;
						
				case 8:	System.out.println("\nEnter the sort order");
						sc.nextLine();
						String sortOrder = sc.nextLine();
						List<Employee> sortedEmployees = employeeService.sortEmployee(sortOrder);
						for (Employee sortedEmployee: sortedEmployees) {
							System.out.println(sortedEmployee);
						}
					
						break;
						
				case 9: System.out.println("\nShowing non duplicate records");
						List<Employee> nonDuplicateEmployees = employeeService.duplicateOrNonDuplicateRecord("non Duplicate");
						for (Employee nonDuplicateEmployee: nonDuplicateEmployees) {
							System.out.println(nonDuplicateEmployee);
						}
						break;
						
				case 10: System.out.println("\nShowing duplicate records");
						List<Employee> DuplicateEmployees = employeeService.duplicateOrNonDuplicateRecord("Duplicate");
						for (Employee DuplicateEmployee: DuplicateEmployees) {
							System.out.println(DuplicateEmployee);
						}
						break;	
							
				case 11:/*List<Integer> DuplicateWithFreq= employeeService.duplicateEmpWithFreq();
						
						for (int i=0;i<DuplicateWithFreq.size();i++) {
							System.out.println("The Employee :"+DuplicateWithFreq.get(i));
						}*/
						break;
				case 0: sc.close();
						System.out.println("\nThank you for visiting");
						System.exit(0);/**Exit from the system*/
						break;
						
				default:System.out.println("Invalid");/**All other choices are invalid*/
			}
			System.out.println("Do you want to continue: yes/no?");/**Choice to continue in the loop*/
			continueChoice = sc.next();
		}while(continueChoice.equalsIgnoreCase("yes")); 
	}
}
