package com.yash.collDemo.service;

import java.util.List;

import com.yash.collDemo.model.Employee;

public interface IEmployeeService {

	
	public void insert(Employee employee);
	public void deleteByEmployee(Employee employee);
	public void deleteById(Integer id);
	public Employee getEmployee(Integer id);
	public void updateEmployee(Employee employee);
	public List<Employee> listEmployee();
	public List<Employee> searchByFreeText(String searchText);
	public List<Employee> sortEmployee(String sortOrder);
	public List<Employee> duplicateOrNonDuplicateRecord(String choice);
	public List<Integer> duplicateEmpWithFreq(List<Integer> countRepo) ;
	
}
