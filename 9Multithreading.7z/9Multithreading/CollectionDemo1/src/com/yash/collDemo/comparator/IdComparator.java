package com.yash.collDemo.comparator;

import java.util.Comparator;

import com.yash.collDemo.model.Employee;

public class IdComparator implements Comparator<Employee>{

	@Override
	public int compare(Employee employee1, Employee employee2) {
		
		if(employee1.getId()>(employee2.getId()))
		{
			return 1;
		}
		if(employee1.getId()==(employee2.getId()))
		{
			return 0;
		}
		if(employee1.getId()<(employee2.getId()))
		{
			return -1;
		}
		return -2;
	}

	
}
