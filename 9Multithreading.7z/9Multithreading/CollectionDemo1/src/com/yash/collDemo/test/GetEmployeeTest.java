package com.yash.collDemo.test;

import com.yash.collDemo.model.Employee;
import com.yash.collDemo.service.IEmployeeService;
import com.yash.collDemo.serviceimpl.EmployeeServiceImpl;
import com.yash.collDemo.util.ServiceFactory;

public class GetEmployeeTest {

	public static void main(String[] args) {
		
		IEmployeeService empService = ServiceFactory.getEmployeeService();
		Employee employee = empService.getEmployee(101);
		System.out.println(employee);
	}
	
}
