package com.yash.collDemo.test;

import com.yash.collDemo.model.Employee;
import com.yash.collDemo.serviceimpl.EmployeeServiceImpl;

public class InsertEmployeetest {

	public static void main(String[] args) {
		
		EmployeeServiceImpl empService = new EmployeeServiceImpl();
		Employee employee = new Employee(101, "amit", 1200, "IT");
		empService.insert(employee);
		
	}
	
}
