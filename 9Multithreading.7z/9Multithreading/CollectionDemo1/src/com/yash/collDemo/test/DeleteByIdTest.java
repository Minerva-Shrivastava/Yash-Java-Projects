package com.yash.collDemo.test;

import com.yash.collDemo.model.Employee;
import com.yash.collDemo.serviceimpl.EmployeeServiceImpl;
import com.yash.collDemo.util.ServiceFactory;

public class DeleteByIdTest {

	public static void main(String[] args) {
		
	EmployeeServiceImpl empService = new EmployeeServiceImpl();
	Employee employee = new Employee(101, "Amit", 1200, "development");
	empService.deleteByEmployee(employee);
	
	}
}
