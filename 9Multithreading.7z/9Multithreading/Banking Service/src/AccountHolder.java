
public class AccountHolder implements Runnable{

	BankAccount account ;
	
	@Override
	public void run() {
		
		account.withdraw();

	}
}
