
public class BankAccount extends Thread{

	private String accHolderName;
	private double balance = 200;
	private double money = 50;
	
	public BankAccount(String name, double money) {
		this.accHolderName = name;
		this.money = money;
	}
	
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getAccHolderName() {
		return accHolderName;
	}
	public void setAccHolderName(String accHolderName) {
		this.accHolderName = accHolderName;
	}
	
	public void withdraw()
	{
		System.out.println(Thread.currentThread().getName()+"----Start");
		System.out.println("\n Account holder :"+Thread.currentThread().getName());
		System.out.println("\n Initial balance :"+this.balance);
		System.out.println("\n Money Withdrawn:"+money);
		
			if(this.balance < money)
			{
				System.out.println("\n Not enough balance");
			}
			else
			{
				this.balance -= money;
			}
		
		System.out.println("\n Updated balance :"+this.balance);
		System.out.println(Thread.currentThread().getName()+"----End");
	}
	
	@Override
	public void run() {
		synchronized (this) {
			this.withdraw();
		}
	}

	
}
