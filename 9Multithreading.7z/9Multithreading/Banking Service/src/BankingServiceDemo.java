import java.util.Scanner;

public class BankingServiceDemo {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println(Thread.currentThread().getName()+"----Start");
		
		AccountHolder person = new AccountHolder();
		Thread t1 = new Thread(person);
		Thread t2 = new Thread(person);
		
		t1.setName("Pankaj");
		t2.setName("Priyanka");
		
		t1.start();
		t2.start();
		
		sc.close();
		System.out.println(Thread.currentThread().getName()+"----End");
	}
}
