
public class MyThreadDemo {

	public static void main(String[] args) {
		
		System.out.println(Thread.currentThread().getName()+"--------Start");
		Thread t1 = new MyThread();
		t1.start();
		MyThread t2 = new MyThread();
		t2.start();
		
		/*MyThreadRunnable target3 = new MyThreadRunnable();
		MyThreadRunnable target4 = new MyThreadRunnable();
		*/
		/*
		t1.setName("Ishan");
		t2.setName("Ayushi");*/

		/*t1.start();
		t2.start();*/
		
		
		System.out.println(Thread.currentThread().getName()+"--------End");
	}
}
