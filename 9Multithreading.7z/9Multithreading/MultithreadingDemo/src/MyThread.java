
public class MyThread extends Thread{

	/*public MyThread() {
		this.run();
	}*/
	
	@Override
	public void run() {
		
		System.out.println(Thread.currentThread().getName()+"--------Start");
		String threadName = Thread.currentThread().getName();
		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		loopTask(threadName);
		System.out.println(Thread.currentThread().getName()+"--------End");
	}
	
	public void loopTask(String name)
	{
		for(int i = 1 ; i<=10 ; i++)
		{
			System.out.println(name+" : "+i);
		}
		
	}
	
}
