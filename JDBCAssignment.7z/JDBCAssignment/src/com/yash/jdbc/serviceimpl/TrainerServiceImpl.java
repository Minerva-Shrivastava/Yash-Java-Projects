package com.yash.jdbc.serviceimpl;

import com.yash.jdbc.service.TrainerService;

public class TrainerServiceImpl implements TrainerService{

	@Override
	public void listTrainees() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addCourse() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateCourse() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteCourse() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void listCourses() {
		// TODO Auto-generated method stub
		
	}

}
