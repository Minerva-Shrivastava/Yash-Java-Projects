package com.yash.jdbc.serviceimpl;

import com.yash.jdbc.service.TraineeService;
import com.yash.jdbc.utilities.TraineeMenu;

public class TraineeServiceImpl implements TraineeService{

	 	
	@Override
	public void listCourses() {
		
		
		
	}

	
	
	
}
