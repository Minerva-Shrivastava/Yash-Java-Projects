package com.yash.jdbc.enumeration;

public enum UserStatusEnum {

PENDING("Pending"), ACTIVE("Active"), INACTIVE("Inactive"), DELETED("Deleted");
	
	/**
	 * variable value and constructor
	 */
	private String value;
	private UserStatusEnum(String value) {
		this.value = value;
	}
	/**
	 * Getter method for value 
	 * @return value
	 */
	public String getValue() {
		
		return value;
		
	}
	
	
	/**
	 * Overriding the toString method to print all the constants
	 */
	@Override
	public String toString() {

		switch (this) {
		case ACTIVE:
				return " Status : "+this.getValue();
			
		case DELETED:
				return " Status : "+this.getValue();
			
		case INACTIVE:
				return " Status : "+this.getValue();
			
		case PENDING:
				return " Status : "+this.getValue();

		default:return " Invalid option";
			
		}
	}
}
