package com.yash.jdbc.enumeration;

public enum UserRoleEnum {

	ADMIN("admin"),TRAINER("trainer"),TRAINEE("trainee");
	
	private String value;
	
	private UserRoleEnum(String value) {
		this.value = value;
	}
	
	/**
	 * Getter method for value 
	 * @return value
	 */
	public String getValue() {
		return value;
	}
}
