package com.yash.jdbc.connection_factory;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;
import org.apache.log4j.Logger;



public class DBConnection {

	private static Logger logger = Logger.getLogger(DBConnection.class);
	
	public static Connection getConnection()
	{
		
		Connection connection = null ;
		try {
			
			FileReader readProp = new FileReader("db.properties");
			Properties prop = new Properties();
			prop.load(readProp);
			
			/** 1.Gathering database information */
			String driverClassName = prop.getProperty("DriverClassName");
			String url = prop.getProperty("Url");
			String userName = prop.getProperty("UserName");
			String password = prop.getProperty("Password");
			
			/** 2. Load driver or register driver*/
			Class c = Class.forName(driverClassName);
			c.newInstance();
			//logger.info("Class : "+ c);
			
			/** 3.Creating connection object*/
			connection = DriverManager.getConnection(url,userName,password);
			//logger.info("Connection : "+connection);
			
			//logger.info("Connection established to the database");
		
		} catch (Exception e) {
			
			logger.error(e);
		}
		
		return connection;
	}
}
