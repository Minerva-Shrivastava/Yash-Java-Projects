package com.yash.jdbc.utilities;

import java.util.Scanner;

import com.yash.jdbc.service.TraineeService;
import com.yash.jdbc.service.TrainerService;
import com.yash.jdbc.serviceimpl.TraineeServiceImpl;
import com.yash.jdbc.serviceimpl.TrainerServiceImpl;

public class TrainerMenu {

	
	public static void displayMenu()
	{
		Scanner sc = new Scanner(System.in);
		TrainerService trainerService = new TrainerServiceImpl();
		String continueChoice ;
		
		do {
			System.out.println("******Trainer Menu******");
			System.out.println(" 1. List all trainees"
					  + "\n 2. Add course"
					  + "\n 3. Update course"
					  + "\n 4. Delete course"
					  + "\n 5. List all courses");
			
			int choice = sc.nextInt();
			
			switch (choice) {
			case 1:
					trainerService.listTrainees();			
				break;
			
			case 2:
				trainerService.addCourse();			
			break;
			
			case 3:
				trainerService.updateCourse();			
			break;

			case 4:
				trainerService.deleteCourse();			
			break;
			
			case 5:
				trainerService.listCourses();			
			break;
			default:System.out.println("Invalid option");
					sc.close();
					System.exit(0);
				break;
			}
			
			System.out.println("Do you want to continue?yes/no");
			continueChoice = sc.next();
		}while(continueChoice.equalsIgnoreCase("yes"));
		
	}
}
