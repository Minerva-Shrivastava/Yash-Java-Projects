package com.yash.jdbc.main;

import java.util.Scanner;

import com.yash.jdbc.modal.User;
import com.yash.jdbc.service.AppService;
import com.yash.jdbc.serviceimpl.AppServiceImpl;

public class StartupApplication {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		AppService service = new AppServiceImpl();
		
		String continueChoice;
		do
		{
			System.out.println("*****Menu****");
			System.out.println("\n 1.Login"
							 + "\n 2.Register");
			
			int choice = sc.nextInt();
			
			switch (choice) {
			case 1:
 
				System.out.println("Enter user name : ");
				String loginUserName = sc.next();
				
				System.out.println("Enter password: ");
				String loginPass = sc.next();
				
				service.userLogin(loginUserName, loginPass);
				
				break;
				
			case 2:
				User newUser = new User();
				System.out.println("Enter your first name : ");
				String firstName = sc.next();
				newUser.setFirstName(firstName);
				System.out.println("Enter your last name : ");
				String lastName = sc.next();
				newUser.setLastName(lastName);
				System.out.println("Enter your email : ");
				sc.nextLine();
				String email = sc.nextLine();
				newUser.setEmail(email);
				System.out.println("Enter your contact : ");
				String contact = sc.next();
				newUser.setContact(contact);
				System.out.println("Enter your status : ");
				String status = sc.next();
				newUser.setStatus(status);
				System.out.println("Enter your role : ");
				String role = sc.next();
				newUser.setRole(role);
				System.out.println("Enter your userName : ");
				String userName = sc.next();
				newUser.setUserName(userName);
				System.out.println("Enter your password : ");
				String password = sc.next();
				newUser.setPassword(password);
				service.userRegistration(newUser);
				
				break;

			default:System.out.println("Invalid Option");
					sc.close();
					System.exit(0);
				break;
			}
			
			
			System.out.println("Do you want to continue?yes/no");
			continueChoice = sc.next();
		}while(continueChoice.equalsIgnoreCase("yes"));
		
	}
}
