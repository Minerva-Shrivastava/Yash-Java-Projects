package com.yash.jdbc.service;

public interface TrainerService {

	void listTrainees();

	void addCourse();

	void updateCourse();

	void deleteCourse();

	void listCourses();

}
