package com.yash.collcasestudy.model;

import com.yash.collcasestudy.exception.InsufficientBalanceException;

public class Customer {

	private String name, address, mobileNo;
	private double balance;
	
	public Customer() {
		this.mobileNo = this.generateMobileNumber();
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		if(balance < 0)
			throw new InsufficientBalanceException("\n Not enough balance");
		this.balance = balance;
	}
	
	public String generateMobileNumber(){
		Integer hash=super.hashCode();
		if(hash<0){
			hash=-hash; 
		}
		String hashnumber=Integer.toString(hash);
		if(hash%1000000000==hash)
		{
			double random=Math.random(); 
			int decimal=hashnumber.length();
			if(decimal<10){
				int difference=10-decimal;
				for(int i=0; i<difference; i++){
					random=random*10;
				}
			 
				int finalrandomnumber=(int)random;
				return hashnumber+finalrandomnumber;
			 
			}
		}
		return hashnumber;	 
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
}
