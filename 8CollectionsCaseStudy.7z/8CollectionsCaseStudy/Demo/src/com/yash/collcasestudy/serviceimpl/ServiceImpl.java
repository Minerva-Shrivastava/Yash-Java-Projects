package com.yash.collcasestudy.serviceimpl;

import java.util.HashMap;
import java.util.Map;

import com.sun.xml.internal.bind.v2.model.core.Element;
import com.yash.collcasestudy.model.Customer;
import com.yash.collcasestudy.service.CollCSService;

public class ServiceImpl implements CollCSService{

	private Map<String, Customer> customerRepository;
	
	public ServiceImpl() {
		customerRepository = new HashMap<String,Customer>();
	}
	
	@Override
	public void insert(Customer customer) {
		customerRepository.put(customer.getMobileNo(), customer);
		
	}

	@Override
	public void delete(Customer customer) {
		customerRepository.put(customer.getMobileNo(), customer);
		
	}

	@Override
	public String getMobileNoOfCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public double getBalance(Customer customer) {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public Element<String, Customer> Update(String mobileNo, Customer customer) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public com.sun.javafx.collections.MappingChange.Map<String, Customer> listDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public com.sun.javafx.collections.MappingChange.Map<String, Customer> recharge(Customer customer) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
