package com.yash.collcasestudy.main;

import java.util.Scanner;

import com.yash.collcasestudy.service.CollCSService;
import com.yash.collcasestudy.serviceimpl.ServiceImpl;

import javafx.concurrent.Service;
import sun.security.jca.ServiceId;

public class StartupApplication {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		String contchoice = null;
		CollCSService service = new ServiceImpl() ;
		do {
			System.out.println("********Menu*******");
			System.out.println("\n 1. Insert customer details"
							 + "\n 2. Delete customer details"
							 + "\n 3. Update customer details"
							 + "\n 4. List customer details"
							 + "\n 5. Get mobile number of Customer"
							 + "\n 6. Get customer details from mobile number"
							 + "\n 7. Get balance from mobile number"
							 + "\n 8. Recharge");
			
			int choice = 0;
			switch (choice) {
			case 1:
				
					break;

			default:
					break;
			}
			System.out.println("Do you want to continue /y/n");
			contchoice = sc.next();
		}while(contchoice.equalsIgnoreCase(contchoice));
		
	}
	
}
