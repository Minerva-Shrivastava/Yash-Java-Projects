package com.yash.collcasestudy.service;

import com.sun.javafx.collections.MappingChange.Map;
import com.sun.xml.internal.bind.v2.model.core.Element;
import com.yash.collcasestudy.model.Customer;

public interface CollCSService {

	public void insert(Customer customer);
	public void delete(Customer customer);
	public Element<String, Customer>Update(String mobileNo,Customer customer);
	public Map<String, Customer> listDetails();
	public String getMobileNoOfCustomer(Customer customer);
	public double getBalance(Customer customer);
	public Map<String,Customer> recharge(Customer customer);
}
